@echo off
title Content Analyzer & Humanizer Pro – V5.3

:: ============================================================
:: Get the directory where this batch file is located
:: ============================================================
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo ========================================
echo 🚀 Content Analyzer & Humanizer Pro
echo 📝 One-Click Launcher (Windows) v5.3
echo 🧠 Semantic-Aware Humanization
echo ========================================
echo.

:: ============================================================
:: Check for Python
:: ============================================================
set PYTHON_CMD=

:: Try python command
python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    echo ✅ Python found via "python"
    goto :found
)

:: Try py command (Python launcher on Windows)
py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    echo ✅ Python found via "py"
    goto :found
)

:: Try common installation paths
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

if exist "C:\Python312\python.exe" (
    set PYTHON_CMD="C:\Python312\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

if exist "C:\Python311\python.exe" (
    set PYTHON_CMD="C:\Python311\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

if exist "C:\Python310\python.exe" (
    set PYTHON_CMD="C:\Python310\python.exe"
    echo ✅ Python found at %PYTHON_CMD%
    goto :found
)

:: Python not found
echo ❌ Python not found!
echo.
echo Please install Python 3.8 or higher from:
echo https://www.python.org/downloads/
echo.
echo Make sure to check "Add Python to PATH" during installation.
echo.
pause
exit /b 1

:found
echo.
echo ✅ Required folders:
:: Ensure required folders exist
if not exist "templates" mkdir templates
if not exist "uploads" mkdir uploads
if not exist "processed" mkdir processed
echo    📁 templates, uploads, processed (created if missing)

echo.
echo 🚀 Starting server...
echo 📍 http://127.0.0.1:5000
echo ⏳ Please wait, browser will open automatically.
echo.

:: Run the launcher script (run.py will open browser)
%PYTHON_CMD% run.py

:: If run.py exits for any reason, keep window open
pause