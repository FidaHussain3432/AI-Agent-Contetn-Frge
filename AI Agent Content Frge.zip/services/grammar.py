# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/GRAMMAR.PY - Grammar Check Service
# V6.0-PHASE2
# ============================================================

try:
    from language_tool_python import LanguageTool
    lt = LanguageTool('en-US')
    GRAMMAR_AVAILABLE = True
except:
    lt = None
    GRAMMAR_AVAILABLE = False


def get_grammar_errors(text):
    """Check grammar and return errors with score."""
    if lt is None:
        return {'errors': [], 'error_count': 0, 'score': 100}

    try:
        matches = lt.check(text)
        errors = []
        for match in matches[:20]:
            errors.append({
                'message': match.message,
                'replacements': match.replacements[:3]
            })

        word_count = len(text.split())
        score = max(0, 100 - (len(errors) / max(1, word_count)) * 500) if word_count > 0 else 100

        return {
            'errors': errors,
            'error_count': len(errors),
            'score': round(min(100, score), 1)
        }
    except:
        return {'errors': [], 'error_count': 0, 'score': 100}


def fix_common_grammar(text):
    """Fix common grammar errors automatically."""
    if lt is None:
        return text

    try:
        matches = lt.check(text)
        matches = sorted(matches, key=lambda m: m.offset, reverse=True)
        fixed = text

        for match in matches:
            if not match.replacements:
                continue
            start = match.offset
            end = match.offset + match.errorLength
            original_fragment = fixed[start:end]
            suggestion = match.replacements[0]

            if original_fragment[:1].isupper() and suggestion:
                suggestion = suggestion[0].upper() + suggestion[1:]

            fixed = fixed[:start] + suggestion + fixed[end:]

        return fixed
    except Exception:
        return text