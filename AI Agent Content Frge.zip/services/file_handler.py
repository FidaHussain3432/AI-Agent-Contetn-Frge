# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/FILE_HANDLER.PY - File Processing Service
# V6.0-PHASE2
# ============================================================

import os
import re

from utils.logging_config import app_logger

# DOCX support
try:
    import docx
    from docx.oxml.ns import qn
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

# PDF support
try:
    import pdfplumber
    PDFPLUMBER_SUPPORT = True
except ImportError:
    PDFPLUMBER_SUPPORT = False

try:
    import fitz  # PyMuPDF
    PYMUPDF_SUPPORT = True
except ImportError:
    PYMUPDF_SUPPORT = False


def _run_contains_drawing(run):
    """Check if a run contains drawing elements."""
    return run._element.find(qn('w:drawing')) is not None or run._element.find(qn('w:pict')) is not None


def _set_paragraph_text_preserve_format(paragraph, new_text):
    """Set paragraph text while preserving formatting."""
    text_runs = [r for r in paragraph.runs if not _run_contains_drawing(r)]
    if not text_runs:
        return False
    text_runs[0].text = new_text
    for r in text_runs[1:]:
        r.text = ''
    return True


def _paragraph_is_processable(paragraph):
    """Check if paragraph has enough text to process."""
    text = paragraph.text.strip()
    if not text or len(text.split()) < 3:
        return False
    return True


def extract_text_from_docx(file_path):
    """Extract text from DOCX file."""
    try:
        doc = docx.Document(file_path)
        full_text = []

        for para in doc.paragraphs:
            if para.text.strip():
                full_text.append(para.text)

        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    if cell.text.strip():
                        row_text.append(cell.text.strip())
                if row_text:
                    full_text.append(" | ".join(row_text))

        return '\n'.join(full_text)
    except Exception as e:
        app_logger.error(f"DOCX extraction error: {e}")
        return f"Error reading DOCX: {e}"


def extract_text_from_pdf(file_path):
    """Extract text from PDF file."""
    if not PDFPLUMBER_SUPPORT:
        return "PDF extraction not available (pdfplumber missing)"

    try:
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

                tables = page.extract_tables()
                for table in tables:
                    for row in table:
                        if row:
                            text += " | ".join(str(cell) for cell in row if cell) + "\n"

        return text.strip() if text.strip() else "No text found in PDF."
    except Exception as e:
        app_logger.error(f"PDF extraction error: {e}")
        return f"Error extracting PDF: {e}"


def extract_text_from_txt(file_path):
    """Extract text from TXT file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except:
            app_logger.error("TXT extraction error")
            return "Error reading TXT file."


def process_docx_structure(input_path, output_path, humanize_func, max_loops_per_block=10, fast=False):
    """Process DOCX while preserving formatting."""
    if not DOCX_SUPPORT:
        raise RuntimeError("python-docx not installed")

    doc = docx.Document(input_path)
    stats = {'paragraphs_processed': 0, 'paragraphs_skipped': 0, 'cells_processed': 0}
    worst_ai, worst_plag = 0, 0

    def handle_paragraph(p):
        nonlocal worst_ai, worst_plag
        if not _paragraph_is_processable(p):
            stats['paragraphs_skipped'] += 1
            return

        result = humanize_func(p.text, max_loops=max_loops_per_block, fast=fast)
        changed = _set_paragraph_text_preserve_format(p, result['content'])

        if changed:
            stats['paragraphs_processed'] += 1
            worst_ai = max(worst_ai, result['ai_score'])
            worst_plag = max(worst_plag, result['plag_score'])

    def handle_table(table):
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    handle_paragraph(p)
                    stats['cells_processed'] += 1
                for nested in cell.tables:
                    handle_table(nested)

    for p in doc.paragraphs:
        handle_paragraph(p)
    for t in doc.tables:
        handle_table(t)

    doc.save(output_path)
    stats['worst_ai_score'] = worst_ai
    stats['worst_plagiarism_score'] = worst_plag
    return stats


def process_pdf_structure(input_path, output_path, humanize_func, max_loops_per_block=8, fast=False):
    """Process PDF while preserving formatting."""
    if not PYMUPDF_SUPPORT:
        raise RuntimeError("PyMuPDF not installed")

    doc = fitz.open(input_path)
    stats = {'blocks_processed': 0, 'blocks_skipped': 0, 'pages': len(doc)}
    worst_ai, worst_plag = 0, 0

    for page in doc:
        page_dict = page.get_text("dict")
        redact_jobs = []

        for block in page_dict.get("blocks", []):
            if block.get("type") != 0:
                continue

            block_text_parts = []
            spans_meta = []

            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if span["text"].strip():
                        block_text_parts.append(span["text"])
                        spans_meta.append(span)

            block_text = ' '.join(block_text_parts).strip()

            if len(block_text.split()) < 3:
                stats['blocks_skipped'] += 1
                continue

            result = humanize_func(block_text, max_loops=max_loops_per_block, fast=fast)
            new_text = result['content']
            worst_ai = max(worst_ai, result['ai_score'])
            worst_plag = max(worst_plag, result['plag_score'])

            template_span = spans_meta[0]
            rect = fitz.Rect(block["bbox"])
            fontsize = template_span["size"]
            color_int = template_span.get("color", 0)
            color = (
                ((color_int >> 16) & 255) / 255,
                ((color_int >> 8) & 255) / 255,
                (color_int & 255) / 255
            )

            redact_jobs.append((rect, new_text, fontsize, color))
            stats['blocks_processed'] += 1

        # Apply redactions
        for rect, _, _, _ in redact_jobs:
            page.add_redact_annot(rect, fill=(1, 1, 1))
        if redact_jobs:
            page.apply_redactions()

        # Insert new text
        for rect, new_text, fontsize, color in redact_jobs:
            size = fontsize
            while size > 5:
                overflow = page.insert_textbox(...)
                if overflow >= 0:
                    break
                size -= 0.5
                if size < 5:
                    size = 5
                    break

    doc.save(output_path)
    doc.close()
    stats['worst_ai_score'] = worst_ai
    stats['worst_plagiarism_score'] = worst_plag
    return stats