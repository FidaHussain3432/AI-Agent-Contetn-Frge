# ============================================================
# SERVICES/HUMANIZER.PY - Humanization Engine
# V6.0-PHASE3 - Upgraded with BERT WSD, spaCy Parsing, Discourse Markers, BERTScore
# ============================================================

import re
import random
import os
import warnings
from typing import List, Tuple, Optional, Dict, Set

import numpy as np
import torch
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.tag import pos_tag
from nltk.corpus import wordnet

from services.ai_detector import detect_ai_content
from services.plagiarism import check_plagiarism
from services.grammar import get_grammar_errors
from utils.cache import score_cache
from config import Config

# Suppress unnecessary warnings
warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# PHASE 3: ADVANCED NLP LIBRARIES (with graceful fallbacks)
# ============================================================

# --- spaCy for Dependency Parsing ---
SPACY_AVAILABLE = False
_nlp = None

def get_spacy_nlp():
    """Lazy-load spaCy model."""
    global _nlp, SPACY_AVAILABLE
    if _nlp is not None:
        return _nlp
    try:
        import spacy
        # Try medium model first, then small
        for model_name in ["en_core_web_md", "en_core_web_sm"]:
            try:
                _nlp = spacy.load(model_name)
                SPACY_AVAILABLE = True
                print(f"✅ spaCy loaded: {model_name}")
                return _nlp
            except OSError:
                continue
        # If no model found, try to download small model
        print("📥 Downloading spaCy model...")
        spacy.cli.download("en_core_web_sm")
        _nlp = spacy.load("en_core_web_sm")
        SPACY_AVAILABLE = True
        print("✅ spaCy loaded: en_core_web_sm")
        return _nlp
    except Exception as e:
        print(f"⚠️ spaCy not available: {e}")
        SPACY_AVAILABLE = False
        return None


# --- BERT for Contextual Embeddings & WSD ---
BERT_AVAILABLE = False
_bert_tokenizer = None
_bert_model = None

def compute_bertscore_similarity(original: str, candidate: str) -> float:
    """Compute BERTScore similarity between original and candidate text."""
    if not BERTSCORE_AVAILABLE:
        return compute_st_similarity(original, candidate)
    
    try:
        # Import directly from bert_score
        from bert_score import score as bert_score
        
        # BERTScore expects lists and returns (P, R, F1) tensors
        P, R, F1 = bert_score(
            [candidate],  # predictions
            [original],   # references
            lang='en',
            verbose=False,
            device='cpu',
            model_type='roberta-large'  # Optional: can use 'bert-base-uncased' for speed
        )
        
        # Use F1 score as similarity (convert tensor to float)
        return float(F1[0])
    
    except Exception as e:
        print(f"⚠️ BERTScore computation failed: {e}")
        # Fallback to sentence-transformers
        return compute_st_similarity(original, candidate)


# --- BERTScore for Semantic Coherence ---
BERTSCORE_AVAILABLE = False

def check_bertscore():
    """Check if bert-score is available."""
    global BERTSCORE_AVAILABLE
    try:
        from bert_score import score as bert_score_fn
        BERTSCORE_AVAILABLE = True
        return bert_score_fn
    except ImportError:
        return None


# --- Sentence-Transformers (existing) ---
ST_AVAILABLE = False
_st_model = None

def get_st_model():
    """Lazy-load sentence-transformers model."""
    global _st_model, ST_AVAILABLE
    if _st_model is not None:
        return _st_model
    try:
        from sentence_transformers import SentenceTransformer
        from sklearn.metrics.pairwise import cosine_similarity
        print("🧠 Loading sentence-transformers (all-MiniLM-L6-v2)...")
        _st_model = SentenceTransformer('all-MiniLM-L6-v2')
        ST_AVAILABLE = True
        print("✅ Sentence-transformers loaded")
        return _st_model
    except Exception as e:
        print(f"⚠️ sentence-transformers not available: {e}")
        return None


# ============================================================
# DISCOURSE MARKERS & SMART TRANSITIONS
# ============================================================

# Discourse markers for smart sentence splitting
DISCOURSE_MARKERS = {
    'contrast': ['however', 'nevertheless', 'nonetheless', 'conversely', 'on the contrary', 'in contrast'],
    'cause_effect': ['therefore', 'consequently', 'thus', 'hence', 'as a result', 'accordingly', 'so'],
    'addition': ['furthermore', 'moreover', 'in addition', 'besides', 'also', 'likewise'],
    'concession': ['although', 'though', 'even though', 'while', 'whereas', 'despite', 'in spite of'],
    'condition': ['if', 'unless', 'provided that', 'assuming that', 'given that'],
    'purpose': ['in order to', 'so that', 'for the purpose of', 'with the aim of'],
    'example': ['for example', 'for instance', 'such as', 'namely', 'specifically'],
    'summary': ['in conclusion', 'to summarize', 'in summary', 'overall', 'all in all'],
    'sequence': ['firstly', 'secondly', 'thirdly', 'finally', 'subsequently', 'then', 'next'],
}

# Flatten all markers for quick lookup
ALL_DISCOURSE_MARKERS = []
for category, markers in DISCOURSE_MARKERS.items():
    ALL_DISCOURSE_MARKERS.extend(markers)

# Smart transitions by context
SMART_TRANSITIONS = {
    'contrast': ['That said,', 'However,', 'On the flip side,', 'Yet,'],
    'cause_effect': ['As a result,', 'This means', 'Consequently,', 'So,'],
    'addition': ['Plus,', 'What’s more,', 'On top of that,', 'Also,'],
    'example': ['For instance,', 'Take', 'Consider', 'Like'],
    'emphasis': ['Importantly,', 'Notably,', 'Crucially,', 'Keep in mind that'],
    'clarification': ['To be clear,', 'In other words,', 'Simply put,', 'What this means is'],
    'concession': ['Admittedly,', 'While it’s true that', 'That being said,', 'Sure,'],
    'sequence': ['Next,', 'After that,', 'Then,', 'Moving on,'],
}

# Used transitions tracker (to avoid repetition)
_used_transitions: Dict[str, Set[str]] = {}


def pick_unique_transition(context: str) -> str:
    """Pick a unique transition for given context, avoiding repetition."""
    global _used_transitions
    
    if context not in SMART_TRANSITIONS:
        context = 'addition'  # default
    
    if context not in _used_transitions:
        _used_transitions[context] = set()
    
    available = [t for t in SMART_TRANSITIONS[context] if t not in _used_transitions[context]]
    
    if not available:
        _used_transitions[context].clear()
        available = SMART_TRANSITIONS[context]
    
    choice = random.choice(available)
    _used_transitions[context].add(choice)
    return choice


def get_discourse_context(text: str, position: int) -> str:
    """Detect discourse context at given position in text."""
    text_lower = text.lower()
    for category, markers in DISCOURSE_MARKERS.items():
        for marker in markers:
            if text_lower[position:position + len(marker)] == marker:
                return category
    return 'addition'


# ============================================================
# BERT-BASED WORD SENSE DISAMBIGUATION (WSD)
# ============================================================

def get_bert_contextual_embedding(word: str, sentence: str) -> Optional[np.ndarray]:
    """Get BERT contextual embedding for a word in sentence."""
    if not BERT_AVAILABLE:
        return None
    
    tokenizer, model = get_bert_model()
    if tokenizer is None or model is None:
        return None
    
    try:
        inputs = tokenizer(sentence, return_tensors="pt", padding=True, truncation=True, max_length=512)
        
        with torch.no_grad():
            outputs = model(**inputs)
        
        # Get token positions
        tokens = tokenizer.convert_ids_to_tokens(inputs['input_ids'][0])
        
        # Find word position (handle subword tokenization)
        word_tokens = tokenizer.tokenize(word.lower())
        word_ids = []
        for i, tok in enumerate(tokens):
            if tok in word_tokens or tok.replace('##', '') in word_tokens:
                word_ids.append(i)
        
        if not word_ids:
            return None
        
        # Average embeddings of word pieces
        embeddings = outputs.last_hidden_state[0, word_ids, :].numpy()
        return np.mean(embeddings, axis=0)
    
    except Exception as e:
        return None


def bert_wsd_synonym(word: str, pos_tag_str: str, sentence: str) -> Optional[str]:
    """Context-aware synonym using BERT embeddings + WordNet."""
    if len(word) < 3:
        return None
    
    # Get WordNet POS
    wn_pos = get_wordnet_pos(pos_tag_str) if pos_tag_str else None
    synsets = wordnet.synsets(word, pos=wn_pos) if wn_pos else wordnet.synsets(word)
    
    if not synsets:
        return None
    
    # Get BERT embedding for original word
    original_embedding = get_bert_contextual_embedding(word, sentence)
    
    candidates = []
    for syn in synsets:
        for lemma in syn.lemmas():
            candidate = lemma.name().replace('_', ' ')
            if candidate.lower() == word.lower():
                continue
            
            # If BERT available, compute semantic similarity
            if original_embedding is not None and BERT_AVAILABLE:
                candidate_embedding = get_bert_contextual_embedding(candidate, sentence.replace(word, candidate, 1))
                if candidate_embedding is not None:
                    similarity = np.dot(original_embedding, candidate_embedding) / (
                        np.linalg.norm(original_embedding) * np.linalg.norm(candidate_embedding)
                    )
                    candidates.append((candidate, similarity))
            else:
                # Fallback: use WordNet similarity
                try:
                    similarity = synsets[0].path_similarity(syn) or 0.5
                    candidates.append((candidate, similarity))
                except:
                    candidates.append((candidate, 0.5))
    
    if not candidates:
        return None
    
    # Sort by similarity (higher is better) and length (shorter preferred)
    candidates.sort(key=lambda x: (-x[1], len(x[0])))
    
    # Return top candidate that maintains context
    for candidate, score in candidates[:3]:
        # Basic POS check: if original was capitalized, capitalize candidate
        if word[0].isupper():
            candidate = candidate.capitalize()
        return candidate
    
    return None


# ============================================================
# spaCy DEPENDENCY PARSING FOR VOICE CHANGE
# ============================================================

def spacy_detect_passive(sentence: str) -> List[Tuple[str, str, str]]:
    """
    Detect passive voice using spaCy dependency parsing.
    Returns: [(subject, verb, agent), ...]
    """
    nlp = get_spacy_nlp()
    if nlp is None:
        return []  # Fallback to regex
    
    doc = nlp(sentence)
    passives = []
    
    for token in doc:
        # Look for passive auxiliary + past participle
        if token.dep_ == "nsubjpass" or token.dep_ == "nsubj:pass":
            subject = token.text
            
            # Find the main verb (head of passive subject)
            verb = token.head
            if verb.tag_ in ["VBN", "VBD"] or verb.dep_ == "ROOT":
                # Find agent (by-phrase)
                agent = None
                for child in verb.children:
                    if child.dep_ == "agent" or child.text.lower() == "by":
                        # Get the object of 'by'
                        for subchild in child.children:
                            if subchild.dep_ in ["pobj", "obj"]:
                                agent = subchild.text
                                break
                        if not agent and child.i + 1 < len(doc):
                            agent = doc[child.i + 1].text
                
                if agent:
                    passives.append((subject, verb.text, agent))
    
    return passives


def spacy_convert_passive_to_active(sentence: str) -> str:
    """Convert passive to active using spaCy dependency parsing."""
    passives = spacy_detect_passive(sentence)
    if not passives:
        return sentence  # No passive found
    
    new_sentence = sentence
    for subject, verb, agent in passives:
        # Simple conversion: Agent + verb + subject
        # Handle verb form change (past participle -> simple past)
        verb_base = verb
        if verb.endswith('ed'):
            verb_base = verb[:-2]  # crude stem
        
        active_form = f"{agent} {verb_base}ed {subject}"
        # Replace in sentence (simplified)
        passive_pattern = f"{subject} .*? {verb}.*? by {agent}"
        new_sentence = re.sub(passive_pattern, active_form, new_sentence, flags=re.IGNORECASE)
    
    return new_sentence


# ============================================================
# DISCOURSE-AWARE SENTENCE SPLITTING
# ============================================================

def find_discourse_split_points(sentence: str) -> List[int]:
    """Find optimal split points using discourse markers."""
    words = sentence.split()
    split_points = []
    
    for i, word in enumerate(words):
        word_clean = word.lower().strip(',.;:')
        
        # Check discourse markers
        for marker in ALL_DISCOURSE_MARKERS:
            marker_words = marker.split()
            if word_clean == marker_words[0]:
                # Check if full marker matches
                if i + len(marker_words) <= len(words):
                    match = ' '.join([w.lower().strip(',.;:') for w in words[i:i + len(marker_words)]])
                    if match == marker:
                        split_points.append(i)
                        break
        
        # Also check commas as weak split points
        if word.endswith(','):
            split_points.append(i)
    
    return split_points


def smart_split_sentence(sentence: str) -> str:
    """Split sentence at discourse markers for natural flow."""
    words = sentence.split()
    if len(words) < 12:
        return sentence
    
    split_points = find_discourse_split_points(sentence)
    
    if not split_points:
        return sentence
    
    # Pick middle split point for balance
    idx = split_points[len(split_points) // 2]
    
    first_part = ' '.join(words[:idx + 1]).rstrip(',.;:')
    second_part = ' '.join(words[idx + 1:])
    
    # Add smart transition based on discourse context
    context = get_discourse_context(sentence.lower(), idx)
    transition = pick_unique_transition(context)
    
    # Capitalize second part
    if second_part:
        second_part = second_part[0].upper() + second_part[1:]
    
    return f"{first_part}. {transition} {second_part}"


# ============================================================
# BERTScore FOR SEMANTIC COHERENCE
# ============================================================

def compute_bertscore_similarity(original: str, candidate: str) -> float:
    """Compute BERTScore similarity between original and candidate text."""
    if not BERTSCORE_AVAILABLE:
        return compute_st_similarity(original, candidate)
    
    try:
        from bert_score import score as bert_score_fn
        
        # BERTScore expects lists
        P, R, F1 = bert_score_fn(
            [candidate], [original],
            lang='en',
            verbose=False,
            device='cpu'
        )
        
        # Use F1 score as similarity
        return float(F1[0])
    
    except Exception as e:
        return compute_st_similarity(original, candidate)


def compute_st_similarity(original: str, candidate: str) -> float:
    """Fallback: Sentence-Transformers cosine similarity."""
    model = get_st_model()
    if model is None:
        return 1.0  # Assume perfect if no model
    
    try:
        from sklearn.metrics.pairwise import cosine_similarity
        emb = model.encode([original, candidate])
        sim = cosine_similarity([emb[0]], [emb[1]])[0][0]
        return float(sim)
    except Exception:
        return 1.0


def compute_document_similarity(orig_text: str, new_text: str) -> float:
    """Compute overall document similarity using best available method."""
    # Prefer BERTScore for documents
    if BERTSCORE_AVAILABLE:
        return compute_bertscore_similarity(orig_text, new_text)
    return compute_st_similarity(orig_text, new_text)


# ============================================================
# SMART TRANSITION SYSTEM
# ============================================================

def add_smart_transitions(text: str) -> str:
    """Add context-aware transitions between sentences."""
    sentences = safe_sent_tokenize(text)
    if len(sentences) < 2:
        return text
    
    new_sentences = [sentences[0]]
    
    for i in range(1, len(sentences)):
        prev_sent = sentences[i - 1].lower()
        curr_sent = sentences[i]
        
        # Detect relationship between sentences
        context = 'addition'  # default
        
        # Check for contrast indicators
        contrast_words = ['but', 'however', 'unlike', 'different', 'opposite']
        if any(w in prev_sent for w in contrast_words):
            context = 'contrast'
        
        # Check for cause-effect
        cause_words = ['because', 'since', 'due to', 'as a result']
        if any(w in prev_sent for w in cause_words):
            context = 'cause_effect'
        
        # Check for examples
        example_words = ['example', 'instance', 'such as', 'like']
        if any(w in prev_sent for w in example_words):
            context = 'example'
        
        # 30% chance to add transition (don't overdo it)
        if random.random() < 0.3 and not curr_sent.startswith(('However', 'Therefore', 'Moreover')):
            transition = pick_unique_transition(context)
            # Only add if sentence doesn't already start with transition
            curr_sent = f"{transition} {curr_sent[0].lower()}{curr_sent[1:]}"
        
        new_sentences.append(curr_sent)
    
    return ' '.join(new_sentences)


# ============================================================
# LEGACY / FALLBACK FUNCTIONS (kept for compatibility)
# ============================================================

def safe_sent_tokenize(text: str) -> List[str]:
    """Safe sentence tokenization with fallback."""
    try:
        return sent_tokenize(text)
    except:
        return re.split(r'(?<=[.!?])\s+', text)


def get_wordnet_pos(treebank_tag: str):
    """Convert treebank POS to WordNet POS."""
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


def get_context_synonym(word: str, pos_tag_str: Optional[str] = None, sentence: str = "") -> Optional[str]:
    """Get context-appropriate synonym using BERT WSD or WordNet fallback."""
    # Try BERT WSD first if available and sentence provided
    if BERT_AVAILABLE and sentence:
        bert_syn = bert_wsd_synonym(word, pos_tag_str, sentence)
        if bert_syn:
            return bert_syn
    
    # Fallback to WordNet
    if len(word) < 3:
        return None
    
    wn_pos = get_wordnet_pos(pos_tag_str) if pos_tag_str else None
    synsets = wordnet.synsets(word, pos=wn_pos) if wn_pos else wordnet.synsets(word)
    
    if not synsets:
        return None
    
    lemmas = set()
    for syn in synsets:
        for lemma in syn.lemmas():
            candidate = lemma.name().replace('_', ' ')
            if candidate.lower() != word.lower():
                lemmas.add(candidate)
    
    if not lemmas:
        return None
    
    return sorted(lemmas, key=lambda x: (len(x), x))[0]


def transform_synonym_replacement(text: str, used_tracker: Optional[Dict] = None) -> str:
    """Replace word with BERT-contextualized synonym."""
    if used_tracker is None:
        used_tracker = {}
    
    words = word_tokenize(text)
    
    try:
        tagged = pos_tag(words)
    except LookupError:
        return text
    
    candidates = []
    for i, (word, tag) in enumerate(tagged):
        if len(word) < 3 or word.lower() in {'the', 'a', 'an', 'and', 'or', 'but', 'for', 'nor', 'on', 'at', 'to', 'by'}:
            continue
        if tag.startswith(('NN', 'VB', 'JJ', 'RB')):
            # Pass full sentence for BERT WSD
            syn = get_context_synonym(word, tag, sentence=text)
            if syn and syn.lower() != word.lower():
                candidates.append((i, word, syn, tag))
    
    if not candidates:
        return text
    
    idx, orig, syn, tag = random.choice(candidates)
    key = f"{orig}_{tag}"
    
    if key not in used_tracker:
        used_tracker[key] = set()
    
    if syn in used_tracker[key]:
        return text
    
    used_tracker[key].add(syn)
    words[idx] = syn
    return ' '.join(words)


def transform_voice_change(text: str) -> str:
    """Convert passive to active using spaCy or regex fallback."""
    # Try spaCy first
    if SPACY_AVAILABLE:
        try:
            return spacy_convert_passive_to_active(text)
        except:
            pass
    
    # Fallback to regex
    passive_patterns = [
        (r'was\s+(\w+ed)\s+by\s+(\w+)', r'\2 \1'),
        (r'were\s+(\w+ed)\s+by\s+(\w+)', r'\2 \1'),
        (r'is\s+(\w+ed)\s+by\s+(\w+)', r'\2 \1'),
        (r'are\s+(\w+ed)\s+by\s+(\w+)', r'\2 \1'),
    ]
    
    new_text = text
    for pat, repl in passive_patterns:
        new_text = re.sub(pat, repl, new_text, flags=re.IGNORECASE)
    
    return new_text


def transform_split_sentence(text: str) -> str:
    """Split sentence using discourse markers."""
    return smart_split_sentence(text)


def generate_candidates(sentence: str, used_tracker: Optional[Dict] = None) -> List[Tuple[str, str]]:
    """Generate candidate paraphrases with Phase 3 upgrades."""
    if used_tracker is None:
        used_tracker = {}
    
    candidates = [(sentence, 'original')]
    
    # Synonym replacement (BERT WSD)
    for _ in range(3):
        syn_text = transform_synonym_replacement(sentence, used_tracker)
        if syn_text != sentence:
            candidates.append((syn_text, 'synonym'))
    
    # Voice change (spaCy)
    voice_text = transform_voice_change(sentence)
    if voice_text != sentence:
        candidates.append((voice_text, 'voice'))
    
    # Smart split (discourse markers)
    split_text = transform_split_sentence(sentence)
    if split_text != sentence:
        candidates.append((split_text, 'split'))
    
    # Smart transitions
    transition_text = add_smart_transitions(sentence)
    if transition_text != sentence:
        candidates.append((transition_text, 'transition'))
    
    # Remove duplicates
    seen = set()
    unique = []
    for cand, typ in candidates:
        if cand not in seen:
            seen.add(cand)
            unique.append((cand, typ))
    
    return unique


def compute_similarity(orig: str, cand: str) -> float:
    """Compute semantic similarity using best available method."""
    return compute_bertscore_similarity(orig, cand)


def remove_repetitive_patterns(text: str) -> str:
    """Collapse duplicate consecutive words/phrases."""
    text = re.sub(r'\b(\w+(?:\s+\w+){0,3})\s+\1\b', r'\1', text, flags=re.IGNORECASE)
    return text


def apply_humanization(text: str, intensity: str = 'medium', used_tracker: Optional[Dict] = None) -> str:
    """Apply Phase 3 semantic-aware humanization."""
    if used_tracker is None:
        used_tracker = {}
    
    sentences = safe_sent_tokenize(text)
    new_sentences = []
    
    max_candidates = {'light': 2, 'medium': 4, 'deep': 6}.get(intensity, 4)
    
    for sent in sentences:
        if len(sent.split()) < 4:
            new_sentences.append(sent)
            continue
        
        candidates = generate_candidates(sent, used_tracker)
        best_score = -1e9
        best_candidate = sent
        
        for cand, typ in candidates[:max_candidates]:
            sim = compute_similarity(sent, cand)
            if sim < Config.AI.SIMILARITY_THRESHOLD:
                continue
            
            # Use cached scores
            ai_heur = score_cache.cached_score(
                cand, detect_ai_content, 'heuristic_ai'
            )['ai_score']
            
            plag_heur = score_cache.cached_score(
                cand, check_plagiarism, 'plagiarism'
            )['score']
            
            # BERTScore bonus for high semantic similarity
            bert_bonus = 0.1 if sim > 0.95 else 0
            
            score = sim * 0.6 + bert_bonus - (ai_heur + plag_heur) * 0.02
            if score > best_score:
                best_score = score
                best_candidate = cand
        
        new_sentences.append(best_candidate)
    
    new_text = ' '.join(new_sentences)
    new_text = remove_repetitive_patterns(new_text)
    
    # Add smart transitions between sentences
    new_text = add_smart_transitions(new_text)
    
    return new_text


def auto_humanize_pipeline(content: str, max_loops: int = 100, fast: bool = False) -> Dict:
    """Apply progressive humanization with Phase 3 upgrades."""
    
    def ai_score_of(t: str) -> float:
        if fast:
            return score_cache.cached_score(t, detect_ai_content, 'heuristic_ai')['ai_score']
        return score_cache.cached_score(t, detect_ai_content, 'detect_ai')['ai_score']
    
    def plag_score_of(t: str) -> float:
        return score_cache.cached_score(t, check_plagiarism, 'plagiarism')['score']
    
    def grammar_score_of(t: str) -> float:
        return score_cache.cached_score(t, get_grammar_errors, 'grammar')['score']
    
    current_content = content
    history = []
    loop_count = 0
    used_tracker = {}
    stall_count = 0
    best_content = current_content
    best_ai = ai_score_of(current_content)
    best_plag = plag_score_of(current_content)
    best_grammar = grammar_score_of(current_content)
    original_content = content
    
    while loop_count < max_loops:
        loop_count += 1
        
        ai_score = ai_score_of(current_content)
        plag_score = plag_score_of(current_content)
        grammar_score = grammar_score_of(current_content)
        
        # Check if targets met
        if ai_score <= 5 and plag_score <= 5 and grammar_score >= 95:
            history.append({
                'loop': loop_count, 'ai_score': ai_score,
                'plagiarism': plag_score, 'grammar': grammar_score,
                'status': '✅ Complete!'
            })
            best_content = current_content
            break
        
        # Determine intensity
        if loop_count <= 20:
            intensity = 'light'
        elif loop_count <= 50:
            intensity = 'medium'
        else:
            intensity = 'deep'
        
        previous_content = current_content
        current_content = apply_humanization(current_content, intensity, used_tracker)
        
        # Global similarity check with BERTScore
        global_sim = compute_document_similarity(original_content, current_content)
        if global_sim < Config.AI.SIMILARITY_THRESHOLD:
            current_content = best_content
            history.append({
                'loop': loop_count, 'ai_score': ai_score,
                'plagiarism': plag_score, 'grammar': grammar_score,
                'status': '⚠️ Global similarity < 0.85 – reverted'
            })
            break
        
        # Evaluate new scores
        new_ai = ai_score_of(current_content)
        new_plag = plag_score_of(current_content)
        new_grammar = grammar_score_of(current_content)
        
        improved = (new_ai < best_ai) or (new_ai <= best_ai and new_plag <= best_plag)
        if improved:
            best_content, best_ai, best_plag, best_grammar = current_content, new_ai, new_plag, new_grammar
            stall_count = 0
        else:
            stall_count += 1
        
        history.append({
            'loop': loop_count, 'ai_score': ai_score,
            'plagiarism': plag_score, 'grammar': grammar_score,
            'status': '🔄 Humanizing...'
        })
        
        if current_content == previous_content or stall_count >= 6:
            history.append({
                'loop': loop_count, 'ai_score': best_ai,
                'plagiarism': best_plag, 'grammar': best_grammar,
                'status': 'ℹ️ Stopped - no further improvement possible'
            })
            break
    
    # Final scores
    final_ai = ai_score_of(best_content)
    final_plag = plag_score_of(best_content)
    final_grammar = grammar_score_of(best_content)
    converged = final_ai <= 5 and final_plag <= 5 and final_grammar >= 95
    
    score_cache.clear()
    
    return {
        'content': best_content,
        'ai_score': final_ai,
        'plag_score': final_plag,
        'grammar_score': final_grammar,
        'converged': converged,
        'history': history,
        'loops': loop_count,
        'phase3_features': {
            'bert_wsd': BERT_AVAILABLE,
            'spacy_parsing': SPACY_AVAILABLE,
            'bertscore': BERTSCORE_AVAILABLE,
            'discourse_markers': True,
            'smart_transitions': True
        }
    }