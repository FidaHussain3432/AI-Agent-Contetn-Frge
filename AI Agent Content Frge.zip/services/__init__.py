# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/__INIT__.PY - Service Layer Package
# V6.0-PHASE5 - Updated with plagiarism exports
# ============================================================

# Core services
from services.ai_detector import detect_ai_content
from services.plagiarism import check_plagiarism, check_plagiarism_fast

# Phase 4 services
from services.perplexity_scorer import (
    get_perplexity_features, 
    calculate_perplexity_windows,
    calculate_perplexity,
    perplexity_to_ai_score
)
from services.ensemble_voter import (
    EnsembleVoter, 
    create_default_ensemble,
    ModelVote
)

__all__ = [
    'detect_ai_content',
    'check_plagiarism',
    'check_plagiarism_fast',
    'get_perplexity_features',
    'calculate_perplexity_windows',
    'calculate_perplexity',
    'perplexity_to_ai_score',
    'EnsembleVoter',
    'create_default_ensemble',
    'ModelVote'
]