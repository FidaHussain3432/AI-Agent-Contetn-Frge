# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/READABILITY.PY - Readability Analysis Service
# V6.0-PHASE2
# ============================================================

from textstat import flesch_reading_ease, gunning_fog


def get_readability(text):
    """Calculate readability scores."""
    try:
        flesch = flesch_reading_ease(text)
        fog = gunning_fog(text)

        if flesch >= 90: level = "Very Easy (5th Grade)"
        elif flesch >= 80: level = "Easy (6th Grade)"
        elif flesch >= 70: level = "Fairly Easy (7th Grade)"
        elif flesch >= 60: level = "Plain English (8th-9th Grade)"
        elif flesch >= 50: level = "Fairly Difficult (10th-12th Grade)"
        elif flesch >= 30: level = "Difficult (College)"
        else: level = "Very Difficult (College Graduate)"

        return {
            'flesch_score': round(flesch, 1),
            'fog_score': round(fog, 1),
            'reading_level': level
        }
    except:
        return {'flesch_score': 0, 'fog_score': 0, 'reading_level': 'Unable to calculate'}


def split_long_sentence(text):
    """Split sentences longer than 15 words."""
    words = text.split()
    if len(words) > 15:
        split_points = []
        for i, w in enumerate(words):
            if w.lower() in ['and', 'but', 'or', 'so', 'because', 'although']:
                split_points.append(i)
            if w.endswith(','):
                split_points.append(i)

        if split_points:
            idx = split_points[len(split_points) // 2]
            first = ' '.join(words[:idx + 1])
            second = ' '.join(words[idx + 1:])
            return first + '. ' + second

    return text


def replace_complex_words(text):
    """Replace complex words with simpler alternatives."""
    complex_words = {
        'utilize': 'use', 'leverage': 'use', 'optimize': 'improve',
        'implement': 'use', 'demonstrate': 'show', 'indicate': 'show',
        'significant': 'big', 'substantial': 'big', 'considerable': 'big',
        'extensive': 'big', 'fundamental': 'basic',
        'essential': 'key', 'crucial': 'key', 'vital': 'key',
        'paramount': 'key', 'facilitate': 'help',
        'expedite': 'speed up', 'ameliorate': 'improve',
        'augment': 'increase', 'diminish': 'reduce',
        'mitigate': 'reduce', 'alleviate': 'reduce',
        'assess': 'check', 'evaluate': 'check',
        'analyze': 'look at', 'examine': 'look at',
        'scrutinize': 'look at', 'generate': 'create',
        'produce': 'make', 'construct': 'build',
        'formulate': 'create', 'design': 'plan',
        'devise': 'plan', 'conceive': 'think of',
        'envision': 'imagine', 'envisage': 'imagine',
        'comprehend': 'understand', 'ascertain': 'find out',
        'determine': 'find out', 'identify': 'find',
        'recognize': 'see', 'acknowledge': 'accept',
        'appreciate': 'understand', 'perceive': 'see',
        'discern': 'see', 'detect': 'find',
        'discover': 'find', 'uncover': 'find',
        'consequently': 'so', 'furthermore': 'also',
        'moreover': 'also', 'therefore': 'so',
        'hence': 'so', 'thus': 'so',
        'accordingly': 'so', 'subsequently': 'then',
        'nevertheless': 'but', 'nonetheless': 'but',
    }

    words = text.split()
    new_words = []

    for word in words:
        cleaned = word.lower().strip('.,!?;:"\'')
        if cleaned in complex_words:
            replacement = complex_words[cleaned]
            if word[0].isupper():
                replacement = replacement.capitalize()
            new_words.append(replacement)
        else:
            new_words.append(word)

    return ' '.join(new_words)