# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/PLAGIARISM.PY - Advanced Plagiarism Detection
# V6.0-PHASE5 - Web Search + Semantic Similarity + Source Attribution + Multilingual
# ============================================================

import re
import time
import hashlib
import requests
from collections import Counter
from typing import Dict, List, Tuple, Optional
from urllib.parse import quote_plus

from nltk.tokenize import sent_tokenize
from sentence_transformers import SentenceTransformer, util

from utils.logging_config import app_logger
from config import Config

# Global model cache
_embedding_model = None
_multilingual_model = None
_model_loading = False

# Constants
WEB_SEARCH_TIMEOUT = 10
MAX_WEB_RESULTS = 5
SEMANTIC_THRESHOLD = 0.75  # Similarity threshold for paraphrase detection
MIN_SENTENCE_LENGTH = 15  # Characters

# Static cliché list (retained as fallback)
COMMON_PHRASES = [
    "in today's world", "in this day and age", "at the end of the day",
    "when it comes to", "it is important to note", "it goes without saying",
    "in order to", "due to the fact that", "in conclusion", "to sum up",
    "on the other hand", "as a matter of fact", "needless to say",
    "last but not least", "first and foremost", "in the current era",
    "in modern times", "plays a vital role", "plays a crucial role",
    "has become increasingly", "there is no denying", "it is worth noting",
    "it should be noted", "it is worth mentioning", "it is essential to",
    "it is important to", "it is clear that", "it is evident that",
]


def _load_embedding_model():
    """Lazy-load sentence transformer for semantic similarity."""
    global _embedding_model, _model_loading

    if _embedding_model is not None:
        return _embedding_model

    if _model_loading:
        return None

    _model_loading = True
    try:
        app_logger.info("Loading Sentence-BERT model for plagiarism detection...")
        _embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        app_logger.info("Sentence-BERT model loaded!")
    except Exception as e:
        app_logger.error(f"Failed to load embedding model: {e}")
        _embedding_model = None
    finally:
        _model_loading = False

    return _embedding_model


def _load_multilingual_model():
    """Lazy-load multilingual model for cross-language detection."""
    global _multilingual_model

    if _multilingual_model is not None:
        return _multilingual_model

    try:
        app_logger.info("Loading multilingual Sentence-BERT model...")
        _multilingual_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
        app_logger.info("Multilingual model loaded!")
    except Exception as e:
        app_logger.warning(f"Failed to load multilingual model: {e}")
        _multilingual_model = None

    return _multilingual_model


# ============================================================
# WEB SEARCH INTEGRATION
# ============================================================

def _duckduckgo_search(query: str, max_results: int = MAX_WEB_RESULTS) -> List[Dict]:
    """
    Search DuckDuckGo for similar content.
    Free API — no key required.
    """
    try:
        # DuckDuckGo instant answer API
        url = f"https://duckduckgo.com/html/?q={quote_plus(query)}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }

        response = requests.get(url, headers=headers, timeout=WEB_SEARCH_TIMEOUT)

        if response.status_code != 200:
            return []

        # Parse results (simplified — extract titles and snippets)
        results = []
        # Look for result links
        import html
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(response.text, 'html.parser')
        result_elements = soup.find_all('div', class_='result')[:max_results]

        for elem in result_elements:
            title_elem = elem.find('a', class_='result__a')
            snippet_elem = elem.find('a', class_='result__snippet')

            if title_elem and snippet_elem:
                results.append({
                    'title': html.unescape(title_elem.get_text(strip=True)),
                    'snippet': html.unescape(snippet_elem.get_text(strip=True)),
                    'url': title_elem.get('href', '')
                })

        return results
    except Exception as e:
        app_logger.warning(f"Web search failed: {e}")
        return []


def _search_web_for_sentence(sentence: str) -> List[Dict]:
    """Search web for a specific sentence."""
    # Clean sentence for search
    clean_query = re.sub(r'[^\w\s]', '', sentence).strip()
    if len(clean_query) < 10:
        return []

    # Search first 100 chars
    query = clean_query[:100]
    return _duckduckgo_search(query, max_results=3)


# ============================================================
# SEMANTIC SIMILARITY
# ============================================================

def _calculate_semantic_similarity(sentences1: List[str], sentences2: List[str]) -> List[Tuple[int, int, float]]:
    """
    Calculate semantic similarity between two sets of sentences.
    Returns list of (idx1, idx2, similarity_score) tuples.
    """
    model = _load_embedding_model()
    if model is None or not sentences1 or not sentences2:
        return []

    try:
        embeddings1 = model.encode(sentences1, convert_to_tensor=True)
        embeddings2 = model.encode(sentences2, convert_to_tensor=True)

        # Cosine similarity matrix
        similarity_matrix = util.cos_sim(embeddings1, embeddings2)

        matches = []
        for i in range(len(sentences1)):
            for j in range(len(sentences2)):
                score = float(similarity_matrix[i][j])
                if score >= SEMANTIC_THRESHOLD:
                    matches.append((i, j, score))

        return matches
    except Exception as e:
        app_logger.warning(f"Semantic similarity failed: {e}")
        return []


def _find_paraphrased_content(text: str, web_results: List[Dict]) -> List[Dict]:
    """
    Find paraphrased content by comparing semantic similarity.
    """
    text_sentences = [s.strip() for s in sent_tokenize(text) if len(s.strip()) >= MIN_SENTENCE_LENGTH]

    if not text_sentences or not web_results:
        return []

    # Extract snippets from web results
    web_snippets = []
    for result in web_results:
        snippet = result.get('snippet', '')
        if snippet:
            web_snippets.append(snippet)

    if not web_snippets:
        return []

    # Calculate semantic similarity
    matches = _calculate_semantic_similarity(text_sentences, web_snippets)

    paraphrase_matches = []
    seen_indices = set()

    for idx1, idx2, score in matches:
        if idx1 in seen_indices:
            continue

        seen_indices.add(idx1)
        source_result = web_results[idx2] if idx2 < len(web_results) else {}

        paraphrase_matches.append({
            'sentence': text_sentences[idx1],
            'similarity': round(score, 3),
            'source_title': source_result.get('title', 'Unknown'),
            'source_url': source_result.get('url', ''),
            'match_type': 'semantic_paraphrase'
        })

    return paraphrase_matches


# ============================================================
# MULTILINGUAL SUPPORT
# ============================================================

def _detect_language(text: str) -> str:
    """
    Simple language detection based on character patterns.
    Returns: 'en', 'ur', 'hi', 'ar', or 'unknown'
    """
    # Urdu Unicode range: U+0600 to U+06FF
    urdu_chars = len(re.findall(r'[؀-ۿ]', text))
    # Hindi Unicode range: U+0900 to U+097F
    hindi_chars = len(re.findall(r'[ऀ-ॿ]', text))
    # Arabic Unicode range: U+0600 to U+06FF (overlaps with Urdu)
    # Chinese Unicode range: U+4E00 to U+9FFF
    chinese_chars = len(re.findall(r'[一-鿿]', text))

    total_chars = len(text.replace(' ', ''))
    if total_chars == 0:
        return 'unknown'

    if urdu_chars / total_chars > 0.3:
        return 'ur'
    elif hindi_chars / total_chars > 0.3:
        return 'hi'
    elif chinese_chars / total_chars > 0.3:
        return 'zh'
    elif urdu_chars / total_chars > 0.1:  # Arabic/Urdu overlap
        return 'ar'
    else:
        return 'en'


def _multilingual_similarity(text1: str, text2: str) -> float:
    """
    Calculate cross-lingual semantic similarity.
    """
    model = _load_multilingual_model()
    if model is None:
        return 0.0

    try:
        embeddings = model.encode([text1, text2], convert_to_tensor=True)
        similarity = util.cos_sim(embeddings[0], embeddings[1])
        return float(similarity)
    except Exception as e:
        app_logger.warning(f"Multilingual similarity failed: {e}")
        return 0.0


# ============================================================
# SOURCE ATTRIBUTION
# ============================================================

def _find_exact_matches(text: str, web_results: List[Dict]) -> List[Dict]:
    """Find exact or near-exact matches with web sources."""
    text_lower = text.lower()
    matches = []

    for result in web_results:
        snippet = result.get('snippet', '').lower()
        title = result.get('title', '').lower()
        url = result.get('url', '')

        if not snippet:
            continue

        # Check for exact phrase matches (5+ words)
        snippet_words = snippet.split()
        text_words = text_lower.split()

        for i in range(len(snippet_words) - 4):
            phrase = ' '.join(snippet_words[i:i+5])
            if phrase in text_lower and len(phrase) > 20:
                # Find position in original text
                start_idx = text_lower.find(phrase)
                context = text[max(0, start_idx-30):min(len(text), start_idx+len(phrase)+30)]

                matches.append({
                    'matched_text': context,
                    'source_title': result.get('title', 'Unknown'),
                    'source_url': url,
                    'match_type': 'exact_phrase',
                    'similarity': 1.0
                })
                break  # One match per result is enough

    return matches


# ============================================================
# MAIN PLAGIARISM CHECK
# ============================================================

def check_plagiarism(text: str, enable_web_search: bool = True) -> Dict:
    """
    Advanced plagiarism detection with web search, semantic similarity,
    source attribution, and multilingual support.

    Args:
        text: Content to check
        enable_web_search: Whether to search web (slower but more accurate)

    Returns:
        {
            'score': float (0-100),
            'status': str ('Low'/'Medium'/'High'),
            'engine': str,
            'matches': int,
            'sources': List[Dict],
            'semantic_matches': List[Dict],
            'language': str,
            'web_search_enabled': bool,
            'local_score': float,
            'web_score': float,
            'semantic_score': float
        }
    """
    start_time = time.time()
    lower_text = text.lower()
    word_count = max(1, len(text.split()))

    # Detect language
    detected_lang = _detect_language(text)

    # ========== LOCAL HEURISTIC (existing logic, enhanced) ==========
    cliche_hits = sum(lower_text.count(p) for p in COMMON_PHRASES)
    cliche_score = min(15, cliche_hits * 2)

    clean = re.sub(r'[^\w\s]', '', lower_text)
    tokens = clean.split()

    repetition_score = 0
    if len(tokens) >= 3:
        trigrams = [' '.join(tokens[i:i+3]) for i in range(len(tokens)-2)]
        trigram_counts = Counter(trigrams)
        repeated_trigrams = sum(1 for c in trigram_counts.values() if c > 1)
        repetition_score = min(10, repeated_trigrams * 1.0)

    unique_ratio = len(set(tokens)) / max(1, len(tokens))
    variety_score = 10 * (1 - unique_ratio) if unique_ratio < 0.5 else 0

    sentences = sent_tokenize(text)
    structure_penalty = 0
    if len(sentences) > 3:
        starters = [s.split()[0].lower() if s.split() else '' for s in sentences]
        starter_counts = Counter(starters)
        repeated_starters = sum(1 for c in starter_counts.values() if c > 2)
        structure_penalty = min(8, repeated_starters * 1.5)

    local_score = min(40, cliche_score + repetition_score + variety_score + structure_penalty)

    # ========== WEB SEARCH & SEMANTIC ==========
    web_score = 0
    semantic_score = 0
    all_sources = []
    semantic_matches = []
    web_search_enabled = False

    if enable_web_search and word_count > 20:
        web_search_enabled = True

        # Sample sentences for web search (check first, middle, last)
        sample_sentences = []
        if sentences:
            sample_sentences.append(sentences[0])  # First sentence
            if len(sentences) > 2:
                sample_sentences.append(sentences[len(sentences)//2])  # Middle
            if len(sentences) > 1:
                sample_sentences.append(sentences[-1])  # Last

        # Search web for sample sentences
        web_results = []
        for sentence in sample_sentences:
            if len(sentence.strip()) >= MIN_SENTENCE_LENGTH:
                results = _search_web_for_sentence(sentence)
                web_results.extend(results)
                time.sleep(0.5)  # Rate limiting

        # Find exact matches
        exact_matches = _find_exact_matches(text, web_results)
        all_sources.extend(exact_matches)

        # Find paraphrased content (semantic similarity)
        if len(sentences) > 1:
            paraphrase_matches = _find_paraphrased_content(text, web_results)
            semantic_matches.extend(paraphrase_matches)
            all_sources.extend(paraphrase_matches)

        # Calculate web score
        if exact_matches:
            web_score = min(30, len(exact_matches) * 10)

        if semantic_matches:
            semantic_score = min(25, len(semantic_matches) * 8)
            avg_similarity = sum(m['similarity'] for m in semantic_matches) / len(semantic_matches)
            semantic_score = min(25, semantic_score * avg_similarity)

    # ========== FINAL SCORE ==========
    plagiarism_score = min(100, round(local_score + web_score + semantic_score, 1))

    if plagiarism_score > 40:
        status = 'High'
    elif plagiarism_score > 20:
        status = 'Medium'
    else:
        status = 'Low'

    # Deduplicate sources
    seen_urls = set()
    unique_sources = []
    for source in all_sources:
        url = source.get('source_url', '')
        if url and url not in seen_urls:
            seen_urls.add(url)
            unique_sources.append(source)
        elif not url:
            unique_sources.append(source)

    processing_time = round(time.time() - start_time, 2)

    app_logger.info(
        f"Plagiarism check: score={plagiarism_score}, "
        f"local={local_score}, web={web_score}, semantic={semantic_score}, "
        f"sources={len(unique_sources)}, lang={detected_lang}, time={processing_time}s"
    )

    return {
        'score': plagiarism_score,
        'status': status,
        'engine': 'hybrid-web-semantic',
        'matches': len(unique_sources),
        'sources': unique_sources[:10],  # Top 10 sources
        'semantic_matches': semantic_matches[:5],
        'language': detected_lang,
        'web_search_enabled': web_search_enabled,
        'local_score': round(local_score, 1),
        'web_score': round(web_score, 1),
        'semantic_score': round(semantic_score, 1),
        'processing_time': processing_time
    }


def check_plagiarism_fast(text: str) -> Dict:
    """
    Fast plagiarism check without web search.
    Use for bulk processing or when internet is unavailable.
    """
    return check_plagiarism(text, enable_web_search=False)