# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/ENSEMBLE_VOTER.PY - Ensemble AI Detection
# V6.0-PHASE4 - Confidence Intervals + Uncertainty Bands
# ============================================================

import numpy as np
from typing import Dict, List
from dataclasses import dataclass, field
from utils.logging_config import app_logger


@dataclass
class ModelVote:
    """Single model's vote in the ensemble."""
    model_name: str
    ai_score: float
    confidence: float
    weight: float
    features: Dict = field(default_factory=dict)


class EnsembleVoter:
    """
    Ensemble voter combining multiple AI detection models.

    Features:
    - Weighted averaging
    - Confidence interval calculation (95%)
    - Uncertainty quantification
    - Model disagreement detection
    """

    def __init__(self):
        self.votes: List[ModelVote] = []

    def add_vote(self, model_name: str, ai_score: float, confidence: float = 1.0, 
                 weight: float = 1.0, features: Dict = None):
        """Add a model's vote to the ensemble."""
        ai_score = max(0.0, min(100.0, float(ai_score)))
        confidence = max(0.0, min(1.0, float(confidence)))
        weight = max(0.1, float(weight))

        self.votes.append(ModelVote(
            model_name=model_name,
            ai_score=ai_score,
            confidence=confidence,
            weight=weight,
            features=features or {}
        ))

    def compute_ensemble_result(self) -> Dict:
        """
        Compute final ensemble result with confidence intervals.
        """
        if not self.votes:
            return {
                'ai_score': 50.0,
                'human_score': 50.0,
                'confidence': 0.0,
                'uncertainty_band': [0, 100],
                'status': 'Unknown',
                'model_used': 'none',
                'model_breakdown': [],
                'disagreement_score': 1.0
            }

        # Weighted average
        weighted_scores = []
        total_weight = 0.0

        for vote in self.votes:
            effective_weight = vote.weight * vote.confidence
            weighted_scores.append(vote.ai_score * effective_weight)
            total_weight += effective_weight

        if total_weight == 0:
            total_weight = 1.0

        ensemble_ai_score = sum(weighted_scores) / total_weight

        # Variance calculation
        scores_array = np.array([v.ai_score for v in self.votes])
        weights_array = np.array([v.weight * v.confidence for v in self.votes])

        if len(scores_array) > 1 and total_weight > 0:
            weighted_mean = ensemble_ai_score
            variance = np.average((scores_array - weighted_mean) ** 2, weights=weights_array)
            std_dev = float(np.sqrt(variance))
        else:
            std_dev = 15.0

        # 95% Confidence interval
        margin_of_error = 1.96 * std_dev
        lower_bound = max(0, ensemble_ai_score - margin_of_error)
        upper_bound = min(100, ensemble_ai_score + margin_of_error)

        # Overall confidence
        avg_model_confidence = float(np.mean([v.confidence for v in self.votes]))

        # Disagreement score
        if len(scores_array) > 1:
            score_range = float(np.max(scores_array) - np.min(scores_array))
            disagreement = min(1.0, score_range / 100.0)
        else:
            disagreement = 0.0

        # Adjust confidence based on disagreement
        adjusted_confidence = avg_model_confidence * (1 - disagreement * 0.5)

        ai_score = round(ensemble_ai_score, 1)
        human_score = round(100 - ai_score, 1)

        # Status determination
        if ai_score > 70:
            status = 'AI'
        elif ai_score < 30:
            status = 'Human'
        elif ai_score >= 50:
            status = 'Likely AI'
        else:
            status = 'Likely Human'

        # Model breakdown
        breakdown = []
        for vote in self.votes:
            breakdown.append({
                'model': vote.model_name,
                'ai_score': vote.ai_score,
                'confidence': vote.confidence,
                'weight': vote.weight,
                'features': vote.features
            })

        return {
            'ai_score': ai_score,
            'human_score': human_score,
            'confidence': round(adjusted_confidence, 2),
            'uncertainty_band': [round(lower_bound, 1), round(upper_bound, 1)],
            'status': status,
            'model_used': 'ensemble',
            'model_breakdown': breakdown,
            'disagreement_score': round(disagreement, 2),
            'std_deviation': round(std_dev, 1)
        }

    def reset(self):
        """Clear all votes."""
        self.votes = []


def create_default_ensemble() -> EnsembleVoter:
    """Create a fresh ensemble voter instance."""
    return EnsembleVoter()