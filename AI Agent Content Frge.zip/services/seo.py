# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/SEO.PY - SEO Analysis Service
# V6.0-PHASE2
# ============================================================

import re
from collections import Counter


def get_seo_analysis(text):
    """Analyze SEO keywords and density."""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    words = text.split()

    stopwords = set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'])
    filtered_words = [w for w in words if w not in stopwords and len(w) > 2]

    if not filtered_words:
        return {'keywords': [], 'top_keyword': 'None', 'total_keywords': 0}

    word_freq = Counter(filtered_words)
    top_keywords = word_freq.most_common(10)
    total_words = len(filtered_words)

    keyword_data = []
    for word, count in top_keywords:
        density = (count / total_words) * 100
        keyword_data.append({
            'word': word,
            'count': count,
            'density': round(density, 2)
        })

    return {
        'keywords': keyword_data,
        'top_keyword': keyword_data[0]['word'] if keyword_data else 'None',
        'total_keywords': len(set(filtered_words)),
    }