# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/PERPLEXITY_SCORER.PY - Perplexity-Based AI Detection
# V6.0-PHASE4 - Production Ready
# ============================================================

import math
import torch
import numpy as np
from typing import Dict, List
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from utils.logging_config import app_logger

# Global model cache
_gpt2_model = None
_gpt2_tokenizer = None
_model_loading = False


def _load_gpt2_model():
    """Lazy-load GPT-2 model for perplexity calculation."""
    global _gpt2_model, _gpt2_tokenizer, _model_loading

    if _gpt2_model is not None:
        return _gpt2_model, _gpt2_tokenizer

    if _model_loading:
        return None, None

    _model_loading = True
    try:
        app_logger.info("Loading GPT-2 model for perplexity scoring...")
        _gpt2_tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
        _gpt2_model = GPT2LMHeadModel.from_pretrained('gpt2')
        _gpt2_model.eval()
        app_logger.info("GPT-2 model loaded for perplexity scoring!")
    except Exception as e:
        app_logger.error(f"Failed to load GPT-2: {e}")
        _gpt2_model = None
        _gpt2_tokenizer = None
    finally:
        _model_loading = False

    return _gpt2_model, _gpt2_tokenizer


def calculate_perplexity(text: str, max_length: int = 512) -> float:
    """
    Calculate perplexity of text using GPT-2.
    Lower perplexity = more likely AI-generated (GPT-like).
    Higher perplexity = more likely human-written.
    """
    model, tokenizer = _load_gpt2_model()

    if model is None or tokenizer is None:
        return -1.0

    try:
        encodings = tokenizer(
            text,
            return_tensors='pt',
            truncation=True,
            max_length=max_length,
            padding=True
        )

        input_ids = encodings['input_ids']

        with torch.no_grad():
            outputs = model(input_ids, labels=input_ids)
            loss = outputs.loss
            perplexity = math.exp(loss.item())

        return perplexity
    except Exception as e:
        app_logger.warning(f"Perplexity calculation failed: {e}")
        return -1.0


def calculate_perplexity_windows(text: str, window_size: int = 512, stride: int = 256) -> Dict:
    """
    Calculate perplexity using sliding windows for long documents.
    """
    model, tokenizer = _load_gpt2_model()

    if model is None or tokenizer is None:
        return {
            'avg_perplexity': -1, 
            'variance': 0, 
            'windows': [], 
            'status': 'model_unavailable'
        }

    try:
        full_tokens = tokenizer.encode(text, add_special_tokens=False)
    except Exception as e:
        app_logger.warning(f"Tokenization failed: {e}")
        return {
            'avg_perplexity': -1, 
            'variance': 0, 
            'windows': [], 
            'status': 'tokenization_failed'
        }

    if len(full_tokens) <= window_size:
        ppl = calculate_perplexity(text, max_length=window_size)
        return {
            'avg_perplexity': ppl,
            'variance': 0.0,
            'windows': [{'start': 0, 'end': len(full_tokens), 'perplexity': ppl}],
            'status': 'single_window'
        }

    window_scores = []
    start = 0

    while start < len(full_tokens):
        end = min(start + window_size, len(full_tokens))
        window_tokens = full_tokens[start:end]
        window_text = tokenizer.decode(window_tokens)

        ppl = calculate_perplexity(window_text, max_length=window_size)
        if ppl > 0:
            window_scores.append({
                'start': start,
                'end': end,
                'perplexity': ppl,
                'token_count': len(window_tokens)
            })

        if end >= len(full_tokens):
            break
        start += stride

    if not window_scores:
        return {
            'avg_perplexity': -1, 
            'variance': 0, 
            'windows': [], 
            'status': 'no_valid_windows'
        }

    perplexities = [w['perplexity'] for w in window_scores]
    avg_ppl = float(np.mean(perplexities))
    variance = float(np.var(perplexities))

    return {
        'avg_perplexity': avg_ppl,
        'variance': variance,
        'windows': window_scores,
        'status': 'sliding_window',
        'window_count': len(window_scores)
    }


def perplexity_to_ai_score(
    perplexity: float, 
    human_baseline: float = 80.0, 
    ai_baseline: float = 25.0
) -> float:
    """
    Convert perplexity to AI probability score (0-100).
    Lower perplexity = higher AI score.
    """
    if perplexity < 0:
        return 50.0

    perplexity = max(5.0, min(200.0, perplexity))

    if perplexity <= ai_baseline:
        return 95.0
    elif perplexity >= human_baseline:
        return 5.0
    else:
        ratio = (human_baseline - perplexity) / (human_baseline - ai_baseline)
        return round(5.0 + (ratio * 90.0), 1)


def get_perplexity_features(text: str) -> Dict:
    """
    Extract perplexity-based features for ensemble voting.
    """
    result = calculate_perplexity_windows(text)

    if result['avg_perplexity'] < 0:
        return {
            'ai_score': 50.0,
            'confidence': 0.0,
            'perplexity': -1,
            'variance': 0,
            'status': 'failed',
            'features': {}
        }

    ai_score = perplexity_to_ai_score(result['avg_perplexity'])
    variance = result['variance']

    if variance < 50:
        confidence = 0.85
    elif variance < 200:
        confidence = 0.65
    else:
        confidence = 0.40

    return {
        'ai_score': ai_score,
        'confidence': confidence,
        'perplexity': result['avg_perplexity'],
        'variance': variance,
        'status': result['status'],
        'window_count': result.get('window_count', 1),
        'features': {
            'perplexity_raw': result['avg_perplexity'],
            'perplexity_variance': variance,
            'window_count': result.get('window_count', 1)
        }
    }