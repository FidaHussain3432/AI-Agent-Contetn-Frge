# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/AI_DETECTOR.PY - Production-Ready AI Detection Engine
# V6.0-PHASE4 - Ensemble + Sliding Window + Perplexity + Confidence
# ============================================================

import threading
import time
import re
from typing import Dict
from transformers import pipeline
from utils.logging_config import app_logger
from config import Config

# Phase 4 imports
try:
    from services.perplexity_scorer import get_perplexity_features
    PERPLEXITY_AVAILABLE = True
except ImportError:
    PERPLEXITY_AVAILABLE = False
    app_logger.warning("Perplexity scorer not available")

try:
    from services.ensemble_voter import EnsembleVoter, create_default_ensemble
    ENSEMBLE_AVAILABLE = True
except ImportError:
    ENSEMBLE_AVAILABLE = False
    app_logger.warning("Ensemble voter not available")

# Global model cache
_roberta_detector = None
_roberta_loading = True

# Model config from Config
ROBERTA_MAX_LENGTH = Config.AI.MAX_ROBERTA_LENGTH
ROBERTA_STRIDE = Config.AI.ROBERTA_STRIDE


def load_ai_model():
    """Load RoBERTa AI detection model in background thread."""
    global _roberta_detector, _roberta_loading

    app_logger.info("Loading RoBERTa AI Detection Model...")
    try:
        _roberta_detector = pipeline(
            'text-classification',
            model='roberta-base-openai-detector',
            device=-1
        )
        app_logger.info("RoBERTa AI Detection Model Loaded Successfully!")
    except Exception as e:
        app_logger.error(f"RoBERTa loading failed: {e}")
        _roberta_detector = None
    finally:
        _roberta_loading = False


# Start background loading
threading.Thread(target=load_ai_model, daemon=True).start()


def _sliding_window_roberta(text: str, max_length: int = ROBERTA_MAX_LENGTH, 
                             stride: int = ROBERTA_STRIDE) -> Dict:
    """
    Process long documents using sliding window approach.
    """
    global _roberta_detector

    if _roberta_detector is None:
        return {
            'ai_score': 50.0, 
            'confidence': 0.0, 
            'window_count': 0, 
            'status': 'model_unavailable'
        }

    # Short text — single window
    if len(text) <= max_length:
        try:
            result = _roberta_detector(text[:max_length])[0]
            label = result['label']
            score = result['score']

            if 'real' in label.lower():
                human_score = score * 100
                ai_score = 100 - human_score
            else:
                ai_score = score * 100
                human_score = 100 - ai_score

            return {
                'ai_score': round(ai_score, 1),
                'confidence': round(score, 2),
                'window_count': 1,
                'status': 'single_window'
            }
        except Exception as e:
            app_logger.warning(f"Single window RoBERTa failed: {e}")
            return {
                'ai_score': 50.0, 
                'confidence': 0.0, 
                'window_count': 0, 
                'status': 'inference_failed'
            }

    # Sliding window for long documents
    windows = []
    start = 0

    while start < len(text):
        end = min(start + max_length, len(text))
        window_text = text[start:end]

        try:
            result = _roberta_detector(window_text)[0]
            label = result['label']
            score = result['score']

            if 'real' in label.lower():
                human_score = score * 100
                ai_score = 100 - human_score
            else:
                ai_score = score * 100
                human_score = 100 - ai_score

            windows.append({
                'start': start,
                'end': end,
                'ai_score': ai_score,
                'confidence': score,
                'label': label
            })
        except Exception as e:
            app_logger.warning(f"Window [{start}:{end}] failed: {e}")

        if end >= len(text):
            break
        start += stride

    if not windows:
        return {
            'ai_score': 50.0, 
            'confidence': 0.0, 
            'window_count': 0, 
            'status': 'all_windows_failed'
        }

    # Aggregate predictions
    total_weight = sum(w['confidence'] for w in windows)
    if total_weight == 0:
        total_weight = len(windows)
        for w in windows:
            w['confidence'] = 1.0

    weighted_ai_score = sum(w['ai_score'] * w['confidence'] for w in windows) / total_weight

    # Variance for uncertainty
    ai_scores = [w['ai_score'] for w in windows]
    variance = sum((s - weighted_ai_score) ** 2 for s in ai_scores) / len(ai_scores)
    std_dev = variance ** 0.5

    avg_confidence = sum(w['confidence'] for w in windows) / len(windows)
    variance_penalty = min(0.3, std_dev / 100)
    final_confidence = max(0.3, avg_confidence - variance_penalty)

    return {
        'ai_score': round(weighted_ai_score, 1),
        'confidence': round(final_confidence, 2),
        'window_count': len(windows),
        'status': 'sliding_window',
        'window_variance': round(std_dev, 1)
    }


def _heuristic_ai_score(text: str) -> Dict:
    """Enhanced heuristic scoring with sophisticated features."""
    sentences = [s.strip() for s in re.split(r'[.!?]+', text) if len(s.strip()) > 10]

    if len(sentences) < 3:
        return {
            'ai_score': 50.0,
            'confidence': 0.3,
            'features': {'reason': 'too_short'}
        }

    # Sentence length variance
    sentence_lengths = [len(s.split()) for s in sentences]
    avg_length = sum(sentence_lengths) / len(sentence_lengths)
    variance = sum((l - avg_length) ** 2 for l in sentence_lengths) / len(sentence_lengths)
    variance_score = min(20, max(0, (30 - variance) / 30 * 20))

    # Transition phrases
    ai_transitions = [
        'in conclusion', 'furthermore', 'moreover', 'therefore', 'consequently',
        'as a result', 'it is important', 'it should be noted', 'it is worth noting',
        'additionally', 'in addition', 'on the other hand', 'for example',
        'in other words', 'to summarize', 'in summary', 'firstly', 'secondly',
        'lastly', 'finally', 'overall', 'generally speaking'
    ]
    text_lower = text.lower()
    transition_count = sum(text_lower.count(phrase) for phrase in ai_transitions)
    transition_density = transition_count / len(sentences) if sentences else 0
    transition_score = min(20, transition_density * 15)

    # Lexical diversity
    words = re.findall(r'\b\w+\b', text_lower)
    if words:
        unique_ratio = len(set(words)) / len(words)
        diversity_score = max(0, (0.7 - unique_ratio) / 0.7 * 20) if unique_ratio < 0.7 else 0
    else:
        diversity_score = 0
        unique_ratio = 0

    # Repetitive patterns
    bigrams = []
    for i in range(len(words) - 1):
        bigrams.append(f"{words[i]} {words[i+1]}")

    if bigrams:
        unique_bigrams = len(set(bigrams))
        total_bigrams = len(bigrams)
        repetition_score = max(0, (1 - unique_bigrams / total_bigrams) * 15) if total_bigrams > 0 else 0
    else:
        repetition_score = 0

    # Average sentence length
    length_score = 0
    if 15 <= avg_length <= 25:
        length_score = 10

    # Final score
    ai_score = 30 + variance_score + transition_score + diversity_score + repetition_score + length_score
    ai_score = min(95, max(5, ai_score))

    word_count = len(words)
    if word_count > 200:
        confidence = 0.65
    elif word_count > 100:
        confidence = 0.55
    else:
        confidence = 0.40

    return {
        'ai_score': round(ai_score, 1),
        'confidence': round(confidence, 2),
        'features': {
            'sentence_variance': round(variance, 1),
            'avg_sentence_length': round(avg_length, 1),
            'transition_density': round(transition_density, 3),
            'lexical_diversity': round(unique_ratio, 3),
            'repetition_score': round(repetition_score, 1)
        }
    }


def detect_ai_content(text: str) -> Dict:
    """
    Production-ready AI detection with ensemble approach.

    Combines:
    1. RoBERTa with sliding window
    2. Perplexity-based scoring (GPT-2)
    3. Enhanced heuristic fallback

    Returns continuous score 0-100 with uncertainty bands.
    """
    global _roberta_detector, _roberta_loading

    # Wait for model loading
    wait_count = 0
    while _roberta_loading and wait_count < 10:
        time.sleep(0.2)
        wait_count += 1

    # Create ensemble
    if ENSEMBLE_AVAILABLE:
        ensemble = create_default_ensemble()
    else:
        ensemble = None

    # === Model 1: RoBERTa Sliding Window ===
    roberta_result = None
    if _roberta_detector is not None:
        try:
            roberta_result = _sliding_window_roberta(text)
            if ensemble:
                ensemble.add_vote(
                    model_name='roberta_sliding_window',
                    ai_score=roberta_result['ai_score'],
                    confidence=roberta_result['confidence'],
                    weight=Config.AI.ROBERTA_WEIGHT,
                    features={
                        'window_count': roberta_result.get('window_count', 1),
                        'window_variance': roberta_result.get('window_variance', 0)
                    }
                )
        except Exception as e:
            app_logger.error(f"RoBERTa ensemble vote failed: {e}")

    # === Model 2: Perplexity ===
    perplexity_result = None
    if PERPLEXITY_AVAILABLE:
        try:
            perplexity_result = get_perplexity_features(text)
            if ensemble and perplexity_result['status'] != 'failed':
                ensemble.add_vote(
                    model_name='perplexity_gpt2',
                    ai_score=perplexity_result['ai_score'],
                    confidence=perplexity_result['confidence'],
                    weight=Config.AI.PERPLEXITY_WEIGHT,
                    features=perplexity_result.get('features', {})
                )
        except Exception as e:
            app_logger.error(f"Perplexity ensemble vote failed: {e}")

    # === Model 3: Enhanced Heuristic ===
    heuristic_result = _heuristic_ai_score(text)
    if ensemble:
        ensemble.add_vote(
            model_name='heuristic_enhanced',
            ai_score=heuristic_result['ai_score'],
            confidence=heuristic_result['confidence'],
            weight=Config.AI.HEURISTIC_WEIGHT,
            features=heuristic_result.get('features', {})
        )

    # === Compute Ensemble ===
    if ensemble and len(ensemble.votes) > 0:
        result = ensemble.compute_ensemble_result()
    else:
        if roberta_result:
            result = {
                'ai_score': roberta_result['ai_score'],
                'human_score': round(100 - roberta_result['ai_score'], 1),
                'confidence': roberta_result['confidence'],
                'uncertainty_band': [
                    max(0, roberta_result['ai_score'] - 20),
                    min(100, roberta_result['ai_score'] + 20)
                ],
                'status': 'AI' if roberta_result['ai_score'] > 60 else 'Human' if roberta_result['ai_score'] < 40 else 'Mixed',
                'model_used': 'roberta_only',
                'model_breakdown': [roberta_result],
                'disagreement_score': 0.0
            }
        else:
            result = {
                'ai_score': heuristic_result['ai_score'],
                'human_score': round(100 - heuristic_result['ai_score'], 1),
                'confidence': heuristic_result['confidence'],
                'uncertainty_band': [0, 100],
                'status': 'AI' if heuristic_result['ai_score'] > 60 else 'Human' if heuristic_result['ai_score'] < 40 else 'Mixed',
                'model_used': 'heuristic_only',
                'model_breakdown': [heuristic_result],
                'disagreement_score': 0.0
            }

    # Add metadata
    result['text_length'] = len(text)
    result['word_count'] = len(text.split())
    result['analysis_timestamp'] = time.time()

    if 'model_breakdown' not in result:
        result['model_breakdown'] = []
    if 'disagreement_score' not in result:
        result['disagreement_score'] = 0.0

    app_logger.info(
        f"AI Detection: score={result['ai_score']}, "
        f"confidence={result.get('confidence', 0)}, "
        f"status={result['status']}, "
        f"models={result['model_used']}"
    )

    return result