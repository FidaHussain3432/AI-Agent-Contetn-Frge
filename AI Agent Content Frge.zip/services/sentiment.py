# -*- coding: utf-8 -*-
# ============================================================
# SERVICES/SENTIMENT.PY - Sentiment Analysis Service
# V6.0-PHASE2
# ============================================================

from textblob import TextBlob


def get_sentiment(text):
    """Analyze sentiment of text."""
    try:
        blob = TextBlob(text)
        polarity = blob.sentiment.polarity

        if polarity > 0.3:
            category = "Positive"
        elif polarity < -0.3:
            category = "Negative"
        else:
            category = "Neutral"

        return {
            'polarity': round(polarity, 3),
            'subjectivity': round(blob.sentiment.subjectivity, 3),
            'category': category
        }
    except:
        return {'polarity': 0, 'subjectivity': 0, 'category': 'Neutral'}