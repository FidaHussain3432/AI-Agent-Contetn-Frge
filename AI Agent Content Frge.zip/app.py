# ============================================================
# APP.PY - Main Application Entry Point
# V6.0-PHASE6 - Frontend Modernization + SSE Support
# ============================================================

import os
import sys
import locale

from flask import Flask, render_template, send_from_directory, jsonify, request, Response, stream_with_context
from flask_cors import CORS

from config import Config
from models.database import db, init_db
from routes import all_blueprints
from utils.logging_config import app_logger, security_logger

# Fix Windows Encoding
if sys.platform == 'win32':
    try:
        locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
    except:
        pass


def create_app(config_class=Config):
    """Application factory - creates and configures Flask app."""

    base_dir = Config.BASE_DIR

    app = Flask(
        __name__,
        template_folder=str(base_dir / 'templates'),
        static_folder='static',
        static_url_path='/static'
    )

    # Load configuration
    app.config.from_object(config_class)
    app.config['MAX_CONTENT_LENGTH'] = config_class.SECURITY.MAX_CONTENT_LENGTH

    # HF_TOKEN for Hugging Face
    if hasattr(config_class.AI, 'HF_TOKEN') and config_class.AI.HF_TOKEN:
        os.environ['HF_TOKEN'] = config_class.AI.HF_TOKEN
        app_logger.info("HF_TOKEN configured for Hugging Face")

    # Security: CORS
    CORS(app, resources={
        r"/api/*": {
            "origins": config_class.SECURITY.ALLOWED_ORIGINS,
            "methods": ["GET", "POST", "OPTIONS"],
            "allow_headers": ["Content-Type"]
        }
    })

    # Initialize database
    init_db(app)

    # Ensure runtime folders exist
    os.makedirs(config_class.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(config_class.PROCESSED_FOLDER, exist_ok=True)
    os.makedirs(config_class.TEMPLATES_FOLDER, exist_ok=True)
    os.makedirs(base_dir / 'static' / 'js' / 'modules', exist_ok=True)
    os.makedirs(base_dir / 'static' / 'css', exist_ok=True)
    os.makedirs(base_dir / 'static' / 'icons', exist_ok=True)

    # Register all blueprints
    for blueprint in all_blueprints:
        app.register_blueprint(blueprint)
        app_logger.info(f"Registered blueprint: {blueprint.name}")

    # ================================================
    # PHASE 6: SSE Endpoint for Real-time Progress
    # ================================================
    @app.route('/api/reduce-both-sse')
    def reduce_both_sse():
        """Server-Sent Events endpoint for real-time humanization progress."""
        try:
            from services.humanizer import apply_humanization, compute_document_similarity
            from services.ai_detector import detect_ai_content
            from services.plagiarism import check_plagiarism
            from services.grammar import get_grammar_errors

            content = request.args.get('content', '').strip()
            max_loops = int(request.args.get('max_loops', 100))

            if not content:
                def error_stream():
                    import json
                    yield f"data: {json.dumps({'event': 'error', 'message': 'No content provided'})}\n\n"
                return Response(error_stream(), mimetype='text/event-stream')

            def generate():
                import json
                current_content = content
                used_tracker = {}
                loop_count = 0
                stall_count = 0
                best_content = current_content
                best_ai = detect_ai_content(current_content)['ai_score']
                best_plag = check_plagiarism(current_content)['score']
                original_content = content

                while loop_count < max_loops:
                    loop_count += 1
                    ai_score = detect_ai_content(current_content)['ai_score']
                    plag_score = check_plagiarism(current_content)['score']
                    grammar_score = get_grammar_errors(current_content)['score']

                    yield f"data: {json.dumps({'event': 'progress', 'loop': loop_count, 'ai_score': ai_score, 'plagiarism': plag_score, 'grammar': grammar_score, 'status': 'processing'})}\n\n"

                    if ai_score <= 5 and plag_score <= 5 and grammar_score >= 95:
                        best_content = current_content
                        best_ai = ai_score
                        best_plag = plag_score
                        yield f"data: {json.dumps({'event': 'complete', 'loop': loop_count, 'ai_score': ai_score, 'plagiarism': plag_score, 'grammar': grammar_score, 'status': 'complete'})}\n\n"
                        break

                    # Intensity based on loop count
                    if loop_count <= 20:
                        intensity = 'light'
                    elif loop_count <= 50:
                        intensity = 'medium'
                    else:
                        intensity = 'deep'

                    previous_content = current_content
                    current_content = apply_humanization(current_content, intensity, used_tracker)

                    # Global similarity check
                    global_sim = compute_document_similarity(original_content, current_content)
                    if global_sim < Config.AI.SIMILARITY_THRESHOLD:
                        current_content = best_content
                        yield f"data: {json.dumps({'event': 'stopped', 'loop': loop_count, 'ai_score': best_ai, 'plagiarism': best_plag, 'grammar': grammar_score, 'status': 'stopped', 'reason': 'global similarity < 0.85'})}\n\n"
                        break

                    new_ai = detect_ai_content(current_content)['ai_score']
                    new_plag = check_plagiarism(current_content)['score']
                    improved = (new_ai < best_ai) or (new_ai <= best_ai and new_plag <= best_plag)

                    if improved:
                        best_content, best_ai, best_plag = current_content, new_ai, new_plag
                        stall_count = 0
                    else:
                        stall_count += 1

                    if current_content == previous_content or stall_count >= 6:
                        yield f"data: {json.dumps({'event': 'stopped', 'loop': loop_count, 'ai_score': best_ai, 'plagiarism': best_plag, 'grammar': grammar_score, 'status': 'stopped', 'reason': 'no further improvement'})}\n\n"
                        break

                # Final result
                final_ai = detect_ai_content(best_content)['ai_score']
                final_plag = check_plagiarism(best_content)['score']
                final_grammar = get_grammar_errors(best_content)['score']
                yield f"data: {json.dumps({'event': 'final', 'ai_score': final_ai, 'plagiarism': final_plag, 'grammar': final_grammar, 'content': best_content, 'loops': loop_count})}\n\n"

            return Response(stream_with_context(generate()), mimetype='text/event-stream')

        except Exception as e:
            app_logger.error(f"SSE error: {str(e)}")
            def error_stream():
                import json
                yield f"data: {json.dumps({'event': 'error', 'message': str(e)})}\n\n"
            return Response(error_stream(), mimetype='text/event-stream')

    # Static routes
    @app.route('/')
    def index():
        return render_template('index.html')

    # PWA manifest and service worker
    @app.route('/sw.js')
    def serve_sw():
        return send_from_directory('.', 'sw.js', mimetype='application/javascript')

    @app.route('/manifest.json')
    def serve_manifest():
        return jsonify({
            "name": "Content Analyzer & Humanizer Pro",
            "short_name": "ContentPro",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#0A0A1A",
            "theme_color": "#0A0A1A",
            "icons": [
                {"src": "/static/icons/icon-192x192.png", "sizes": "192x192", "type": "image/png"},
                {"src": "/static/icons/icon-512x512.png", "sizes": "512x512", "type": "image/png"}
            ]
        })

    # Security: Error handlers
    @app.errorhandler(404)
    def not_found(e):
        security_logger.info(f"404 error: {request.path}")
        return jsonify({'error': 'Route not found'}), 404

    @app.errorhandler(500)
    def server_error(e):
        app_logger.error(f"500 error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

    @app.errorhandler(413)
    def too_large(e):
        security_logger.warning(f"413 error: File too large")
        return jsonify({'error': 'File too large. Maximum 50MB allowed.'}), 413

    return app


# ============================================================
# NLTK DATA SETUP
# ============================================================
def ensure_nltk_data():
    """Download required NLTK data packages."""
    import nltk

    required_packages = [
        'punkt', 'punkt_tab', 'averaged_perceptron_tagger', 
        'wordnet', 'omw-1.4'
    ]

    for package in required_packages:
        try:
            nltk.data.find(
                f'tokenizers/{package}' if package in ['punkt', 'punkt_tab'] 
                else f'taggers/{package}' if package == 'averaged_perceptron_tagger'
                else f'corpora/{package}'
            )
        except LookupError:
            app_logger.info(f"Downloading NLTK package: {package}...")
            try:
                nltk.download(package, quiet=True)
                app_logger.info(f"Downloaded: {package}")
            except Exception as e:
                app_logger.warning(f"Failed to download {package}: {e}")

    try:
        nltk.data.find('taggers/averaged_perceptron_tagger_eng')
    except LookupError:
        app_logger.info("Downloading averaged_perceptron_tagger_eng...")
        try:
            nltk.download('averaged_perceptron_tagger_eng', quiet=True)
            app_logger.info("Downloaded: averaged_perceptron_tagger_eng")
        except Exception as e:
            app_logger.warning(f"Failed: {e}")


ensure_nltk_data()


# ============================================================
# MAIN ENTRY POINT
# ============================================================
if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Content Analyzer & Humanizer Pro V6.0-PHASE6")
    print("🔒 Security Hardened | Blueprint Architecture")
    print("🧠 AI Detection: Sliding Window + Ensemble + Confidence")
    print("📱 Frontend: Alpine.js | Modular JS | SSE | PWA")
    print("📝 Server Starting...")
    print(f"📍 http://localhost:{Config.APP.PORT}")
    print("📄 Supports: .TXT | .DOCX | .PDF")
    print("🧠 Clean Humanization – No Filler Phrases")
    print("🔧 Global Similarity Guard Enabled")
    print("🛡️ Input Sanitization Active")
    print("📡 SSE Real-time Progress Streaming")
    print("⚡ Press Ctrl+C to stop")
    print("=" * 50)

    app = create_app()
    app.run(
        debug=Config.APP.DEBUG,
        use_reloader=False,
        host=Config.APP.HOST,
        port=Config.APP.PORT
    )