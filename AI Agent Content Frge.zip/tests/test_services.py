# -*- coding: utf-8 -*-
# ============================================================
# TESTS/TEST_SERVICES.PY - Service Layer Unit Tests
# V7.0-PHASE7 - Testing & DevOps
# ============================================================

import pytest
import sys
from unittest.mock import patch, MagicMock, Mock

# Mock heavy dependencies before imports
sys.modules['transformers'] = MagicMock()
sys.modules['torch'] = MagicMock()
sys.modules['numpy'] = MagicMock()
sys.modules['sentence_transformers'] = MagicMock()
sys.modules['spacy'] = MagicMock()
sys.modules['bert_score'] = MagicMock()
sys.modules['nltk'] = MagicMock()
sys.modules['nltk.tokenize'] = MagicMock()
sys.modules['nltk.tag'] = MagicMock()
sys.modules['nltk.corpus'] = MagicMock()

from services.ai_detector import _heuristic_ai_score
from services.plagiarism import _detect_language, check_plagiarism_fast
from services.humanizer import safe_sent_tokenize, get_wordnet_pos

pytestmark = [pytest.mark.unit, pytest.mark.service]


class TestAIDetector:
    """Test AI Detection Service."""

    def test_heuristic_ai_score_short_text(self):
        """Test heuristic with too short text."""
        result = _heuristic_ai_score("Hi")
        assert result['ai_score'] == 50.0
        assert result['confidence'] == 0.3

    def test_heuristic_ai_score_normal_text(self):
        """Test heuristic with normal text."""
        text = "This is a test sentence. Another sentence here. And a third one for good measure."
        result = _heuristic_ai_score(text)
        assert 0 <= result['ai_score'] <= 100
        assert 0 <= result['confidence'] <= 1
        assert 'features' in result

    def test_heuristic_ai_score_ai_like_text(self):
        """Test heuristic with AI-like text."""
        text = """Furthermore, artificial intelligence is transforming industries.
        Moreover, machine learning enables data processing.
        Consequently, businesses adopt AI solutions.
        In conclusion, the future is AI-driven."""
        result = _heuristic_ai_score(text)
        assert result['ai_score'] > 30  # Should detect AI patterns

    def test_heuristic_features_structure(self):
        """Test that all expected features are present."""
        text = "This is a test. Another test sentence. Third sentence here."
        result = _heuristic_ai_score(text)
        features = result['features']
        assert 'sentence_variance' in features
        assert 'avg_sentence_length' in features
        assert 'transition_density' in features
        assert 'lexical_diversity' in features
        assert 'repetition_score' in features


class TestPlagiarismDetection:
    """Test Plagiarism Detection Service."""

    def test_detect_language_english(self):
        """Test English language detection."""
        result = _detect_language("This is English text.")
        assert result == 'en'

    def test_detect_language_urdu(self):
        """Test Urdu language detection."""
        text = "یہ اردو متن ہے"
        result = _detect_language(text)
        assert result == 'ur'

    def test_detect_language_hindi(self):
        """Test Hindi language detection."""
        text = "यह हिंदी पाठ है"
        result = _detect_language(text)
        assert result == 'hi'

    def test_detect_language_chinese(self):
        """Test Chinese language detection."""
        text = "这是中文文本"
        result = _detect_language(text)
        assert result == 'zh'

    def test_detect_language_empty(self):
        """Test empty text language detection."""
        result = _detect_language("")
        assert result == 'unknown'

    def test_check_plagiarism_fast_basic(self):
        """Test fast plagiarism check."""
        text = "This is a unique test text with no common phrases."
        result = check_plagiarism_fast(text)
        assert 'score' in result
        assert 'status' in result
        assert result['status'] in ['Low', 'Medium', 'High']
        assert 0 <= result['score'] <= 100

    def test_check_plagiarism_fast_with_cliches(self):
        """Test fast plagiarism with clichés."""
        text = "In today's world, artificial intelligence plays a vital role."
        result = check_plagiarism_fast(text)
        assert result['score'] > 0  # Should detect clichés

    def test_check_plagiarism_fast_repetition(self):
        """Test fast plagiarism with repetition."""
        text = "The cat sat on the mat. The cat sat on the mat. The cat sat on the mat."
        result = check_plagiarism_fast(text)
        assert result['score'] > 0  # Should detect repetition


class TestHumanizer:
    """Test Humanization Service."""

    def test_safe_sent_tokenize_normal(self):
        """Test sentence tokenization."""
        text = "First sentence. Second sentence! Third sentence?"
        result = safe_sent_tokenize(text)
        assert len(result) >= 2

    def test_safe_sent_tokenize_empty(self):
        """Test empty text tokenization."""
        result = safe_sent_tokenize("")
        assert result == [""] or result == []

    def test_get_wordnet_pos_adjective(self):
        """Test WordNet POS conversion for adjectives."""
        assert get_wordnet_pos('JJ') == 'a'

    def test_get_wordnet_pos_verb(self):
        """Test WordNet POS conversion for verbs."""
        assert get_wordnet_pos('VB') == 'v'

    def test_get_wordnet_pos_noun(self):
        """Test WordNet POS conversion for nouns."""
        assert get_wordnet_pos('NN') == 'n'

    def test_get_wordnet_pos_adverb(self):
        """Test WordNet POS conversion for adverbs."""
        assert get_wordnet_pos('RB') == 'r'

    def test_get_wordnet_pos_unknown(self):
        """Test WordNet POS conversion for unknown tags."""
        assert get_wordnet_pos('XYZ') is None


class TestEnsembleVoter:
    """Test Ensemble Voter (if available)."""

    def test_ensemble_creation(self):
        """Test ensemble voter creation."""
        try:
            from services.ensemble_voter import EnsembleVoter
            voter = EnsembleVoter()
            assert voter is not None
        except ImportError:
            pytest.skip("Ensemble voter not available")