# -*- coding: utf-8 -*-
# ============================================================
# TESTS/TEST_SECURITY.PY - Security Helper Unit Tests
# V7.0-PHASE7 - Testing & DevOps
# ============================================================

import os
import sys
import pytest
from unittest.mock import patch, MagicMock

# Mock config before importing security
sys.modules['config'] = MagicMock()
from utils.security import InputSanitizer, PathValidator

pytestmark = [pytest.mark.unit, pytest.mark.security]


class TestInputSanitizer:
    """Test InputSanitizer class methods."""

    def test_sanitize_filename_normal(self):
        """Test normal filename sanitization."""
        result = InputSanitizer.sanitize_filename('document.txt')
        assert result == 'document.txt'

    def test_sanitize_filename_path_traversal(self):
        """Test path traversal attack prevention."""
        result = InputSanitizer.sanitize_filename('../../../etc/passwd')
        assert result == 'passwd'
        assert '..' not in result
        assert '/' not in result

    def test_sanitize_filename_windows_traversal(self):
        """Test Windows path traversal prevention."""
        result = InputSanitizer.sanitize_filename('..\\..\\windows\\system32\\config\\sam')
        assert '..' not in result
        assert '\\' not in result

    def test_sanitize_filename_xss_attempt(self):
        """Test XSS in filename prevention."""
        result = InputSanitizer.sanitize_filename('file<script>alert(1)</script>.txt')
        assert '<' not in result
        assert '>' not in result

    def test_sanitize_filename_empty(self):
        """Test empty filename handling."""
        assert InputSanitizer.sanitize_filename('') is None
        assert InputSanitizer.sanitize_filename(None) is None

    def test_sanitize_filename_dangerous_names(self):
        """Test dangerous filenames."""
        assert InputSanitizer.sanitize_filename('.') is None
        assert InputSanitizer.sanitize_filename('..') is None

    def test_sanitize_filename_long_name(self):
        """Test long filename truncation."""
        long_name = 'a' * 300 + '.txt'
        result = InputSanitizer.sanitize_filename(long_name)
        assert len(result) <= 255

    def test_sanitize_filename_null_bytes(self):
        """Test null byte removal."""
        result = InputSanitizer.sanitize_filename('file\x00.txt')
        assert '\x00' not in result

    def test_validate_extension_allowed(self):
        """Test allowed extensions."""
        assert InputSanitizer.validate_extension('file.txt') is True
        assert InputSanitizer.validate_extension('file.docx') is True
        assert InputSanitizer.validate_extension('file.pdf') is True

    def test_validate_extension_disallowed(self):
        """Test disallowed extensions."""
        assert InputSanitizer.validate_extension('file.exe') is False
        assert InputSanitizer.validate_extension('file.py') is False
        assert InputSanitizer.validate_extension('file.sh') is False

    def test_validate_extension_no_extension(self):
        """Test file without extension."""
        assert InputSanitizer.validate_extension('file') is False

    def test_validate_mime_type_with_magic(self):
        """Test MIME type validation when magic is available."""
        with patch('utils.security.MAGIC_AVAILABLE', True):
            with patch('utils.security.magic.from_file') as mock_magic:
                mock_magic.return_value = 'text/plain'
                result = InputSanitizer.validate_mime_type('/tmp/test.txt', 'txt')
                assert result is True

    def test_validate_mime_type_mismatch(self):
        """Test MIME type mismatch detection."""
        with patch('utils.security.MAGIC_AVAILABLE', True):
            with patch('utils.security.magic.from_file') as mock_magic:
                mock_magic.return_value = 'application/pdf'
                result = InputSanitizer.validate_mime_type('/tmp/test.txt', 'txt')
                assert result is False

    def test_validate_mime_type_no_magic(self):
        """Test fallback when magic is not available."""
        with patch('utils.security.MAGIC_AVAILABLE', False):
            result = InputSanitizer.validate_mime_type('/tmp/test.txt', 'txt')
            assert result is True  # Fallback: trust extension

    def test_sanitize_text_content_xss(self):
        """Test XSS removal from text."""
        text = '<script>alert("xss")</script>Hello World'
        result = InputSanitizer.sanitize_text_content(text)
        assert '<script>' not in result

    def test_sanitize_text_content_long_text(self):
        """Test long text truncation."""
        long_text = 'word ' * 20000
        result = InputSanitizer.sanitize_text_content(long_text)
        words = result.split()
        assert len(words) <= 10000

    def test_sanitize_text_content_empty(self):
        """Test empty text handling."""
        assert InputSanitizer.sanitize_text_content('') == ''
        assert InputSanitizer.sanitize_text_content(None) == ''

    def test_generate_secure_filename(self):
        """Test secure filename generation."""
        result = InputSanitizer.generate_secure_filename('document.txt')
        assert result.endswith('.txt')
        assert len(result) > 10  # UUID + timestamp + extension

    def test_generate_secure_filename_no_extension(self):
        """Test secure filename without extension."""
        result = InputSanitizer.generate_secure_filename('document')
        assert result.endswith('.txt')  # Default extension

    def test_generate_secure_filename_empty(self):
        """Test empty filename."""
        assert InputSanitizer.generate_secure_filename('') is None


class TestPathValidator:
    """Test PathValidator class methods."""

    def test_is_safe_path_valid(self):
        """Test valid path within base."""
        base = '/app/uploads'
        target = '/app/uploads/file.txt'
        assert PathValidator.is_safe_path(base, target) is True

    def test_is_safe_path_traversal(self):
        """Test path traversal detection."""
        base = '/app/uploads'
        target = '/app/uploads/../../etc/passwd'
        assert PathValidator.is_safe_path(base, target) is False

    def test_is_safe_path_outside_base(self):
        """Test path outside base directory."""
        base = '/app/uploads'
        target = '/etc/passwd'
        assert PathValidator.is_safe_path(base, target) is False

    def test_is_safe_path_relative_traversal(self):
        """Test relative path traversal."""
        base = '/app/uploads'
        target = '/app/uploads/../config.py'
        assert PathValidator.is_safe_path(base, target) is False

    def test_is_safe_path_same_directory(self):
        """Test same directory path."""
        base = '/app/uploads'
        target = '/app/uploads'
        assert PathValidator.is_safe_path(base, target) is True

    def test_is_safe_path_exception_handling(self):
        """Test exception handling for invalid paths."""
        assert PathValidator.is_safe_path(None, '/test') is False