# -*- coding: utf-8 -*-
# ============================================================
# TESTS/TEST_MODELS.PY - Database Model Tests
# V7.0-PHASE7 - Testing & DevOps
# ============================================================

import pytest
from datetime import datetime

pytestmark = [pytest.mark.unit]


class TestAnalysisHistory:
    """Test AnalysisHistory model."""

    def test_model_creation(self, app_context):
        """Test creating an AnalysisHistory record."""
        from models.database import AnalysisHistory

        with app_context.app_context():
            history = AnalysisHistory(
                content_preview="Test content",
                word_count=100,
                char_count=500,
                plagiarism_score=15.0,
                ai_score=45.0,
                human_score=55.0,
                grammar_score=92.0,
                sentiment_category='Neutral',
                top_keyword='test'
            )
            assert history.content_preview == "Test content"
            assert history.word_count == 100
            assert history.plagiarism_score == 15.0

    def test_to_dict(self, app_context):
        """Test to_dict method."""
        from models.database import AnalysisHistory

        with app_context.app_context():
            history = AnalysisHistory(
                content_preview="Test content",
                word_count=100,
                plagiarism_score=15.0,
                ai_score=45.0
            )
            result = history.to_dict()
            assert 'id' in result
            assert 'content_preview' in result
            assert 'word_count' in result
            assert 'plagiarism_score' in result


class TestFileUpload:
    """Test FileUpload model."""

    def test_model_creation(self, app_context):
        """Test creating a FileUpload record."""
        from models.database import FileUpload

        with app_context.app_context():
            upload = FileUpload(
                job_id='abc123',
                original_filename='test.docx',
                secure_filename='secure_test.docx',
                file_type='docx',
                file_size=1024,
                status='pending'
            )
            assert upload.job_id == 'abc123'
            assert upload.original_filename == 'test.docx'

    def test_to_dict(self, app_context):
        """Test to_dict method."""
        from models.database import FileUpload

        with app_context.app_context():
            upload = FileUpload(
                job_id='abc123',
                original_filename='test.docx',
                status='completed'
            )
            result = upload.to_dict()
            assert 'job_id' in result
            assert 'original_filename' in result
            assert 'status' in result


class TestPlagiarismSource:
    """Test PlagiarismSource model."""

    def test_model_creation(self, app_context):
        """Test creating a PlagiarismSource record."""
        from models.database import PlagiarismSource

        with app_context.app_context():
            source = PlagiarismSource(
                analysis_id=1,
                matched_text="Matched text",
                source_title="Example Source",
                source_url="https://example.com",
                match_type='exact_phrase',
                similarity_score=0.95
            )
            assert source.source_title == "Example Source"
            assert source.similarity_score == 0.95

    def test_to_dict(self, app_context):
        """Test to_dict method."""
        from models.database import PlagiarismSource

        with app_context.app_context():
            source = PlagiarismSource(
                matched_text="Matched",
                source_title="Example",
                match_type='exact_phrase'
            )
            result = source.to_dict()
            assert 'matched_text' in result
            assert 'source_title' in result
            assert 'match_type' in result