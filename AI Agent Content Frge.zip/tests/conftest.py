# -*- coding: utf-8 -*-
# ============================================================
# TESTS/CONFTEST.PY - Pytest Fixtures & Configuration
# V7.0-PHASE7 - Testing & DevOps
# ============================================================

import os
import sys
import json
import tempfile
import pytest
from unittest.mock import MagicMock, patch, Mock
from io import BytesIO

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# ============================================================
# MOCK CONFIG (kyunki asli config.py upload nahi hua)
# ============================================================
class MockConfig:
    """Mock configuration for testing without real config.py"""

    class SECURITY:
        MAX_TEXT_LENGTH = 10000
        ALLOWED_EXTENSIONS = {'txt', 'docx', 'pdf'}
        ALLOWED_MIME_TYPES = {
            'txt': ['text/plain'],
            'docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'pdf': ['application/pdf']
        }

    class DATABASE:
        DATABASE_URL = 'sqlite:///:memory:'
        TRACK_MODIFICATIONS = False

    class APP:
        MAX_LOOPS_FILE_PROCESS = 10

    class AI:
        MAX_ROBERTA_LENGTH = 512
        ROBERTA_STRIDE = 256
        ROBERTA_WEIGHT = 0.5
        PERPLEXITY_WEIGHT = 0.3
        HEURISTIC_WEIGHT = 0.2
        SIMILARITY_THRESHOLD = 0.85

    UPLOAD_FOLDER = tempfile.mkdtemp(prefix='test_uploads_')
    PROCESSED_FOLDER = tempfile.mkdtemp(prefix='test_processed_')

# Patch config before importing app modules
sys.modules['config'] = MagicMock()
sys.modules['config'].Config = MockConfig

# ============================================================
# FLASK APP FIXTURE
# ============================================================

@pytest.fixture(scope='session')
def mock_app():
    """Create a mock Flask application for testing."""
    from flask import Flask
    from flask_sqlalchemy import SQLAlchemy

    app = Flask(__name__)
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = tempfile.mkdtemp(prefix='test_uploads_')
    app.config['PROCESSED_FOLDER'] = tempfile.mkdtemp(prefix='test_processed_')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

    db = SQLAlchemy(app)

    # Create tables
    with app.app_context():
        db.create_all()

    yield app

    # Cleanup
    with app.app_context():
        db.drop_all()


@pytest.fixture(scope='function')
def client(mock_app):
    """Create a test client for each test."""
    with mock_app.test_client() as client:
        yield client


@pytest.fixture(scope='function')
def app_context(mock_app):
    """Provide app context for tests."""
    with mock_app.app_context():
        yield mock_app


# ============================================================
# DATABASE FIXTURES
# ============================================================

@pytest.fixture(scope='function')
def db_session(mock_app):
    """Provide a database session with cleanup."""
    from flask_sqlalchemy import SQLAlchemy
    db = SQLAlchemy(mock_app)

    with mock_app.app_context():
        db.create_all()
        yield db.session
        db.session.rollback()
        db.session.remove()
        db.drop_all()


# ============================================================
# SAMPLE DATA FIXTURES
# ============================================================

@pytest.fixture
def sample_text():
    """Return sample text for testing."""
    return """Artificial intelligence has become increasingly important in today's world.
    Machine learning algorithms can process vast amounts of data efficiently.
    Natural language processing enables computers to understand human text.
    Deep learning models have achieved remarkable results in image recognition.
    Furthermore, AI systems are being deployed across various industries."""


@pytest.fixture
def sample_human_text():
    """Return sample human-like text for testing."""
    return """You know what? I was thinking about this whole AI thing the other day.
    Like, it's kinda crazy how fast everything's changing, right?
    My friend was telling me about some app that writes essays for students.
    I mean, sure, it's useful sometimes, but honestly? I still prefer doing things my own way.
    There's just something about putting your own thoughts down on paper, you know?"""


@pytest.fixture
def sample_ai_text():
    """Return sample AI-like text for testing."""
    return """Artificial intelligence is a transformative technology that is reshaping industries worldwide.
    Furthermore, machine learning algorithms enable organizations to process vast datasets efficiently.
    Moreover, natural language processing facilitates human-computer interaction.
    Consequently, businesses are increasingly adopting AI-driven solutions.
    In conclusion, the future of technology is inextricably linked to artificial intelligence."""


@pytest.fixture
def sample_urdu_text():
    """Return sample Urdu text for testing."""
    return "یہ ایک ٹیسٹ متن ہے۔ مصنوعی ذہانت بہت اہم ہے۔"


@pytest.fixture
def sample_long_text():
    """Return a longer text for testing."""
    paragraphs = []
    for i in range(20):
        paragraphs.append(
            f"Paragraph {i+1}: This is a test paragraph about artificial intelligence "
            f"and machine learning. The field has grown rapidly in recent years. "
            f"Researchers continue to make breakthrough discoveries. "
            f"Applications range from healthcare to finance to education."
        )
    return " ".join(paragraphs)


# ============================================================
# FILE FIXTURES
# ============================================================

@pytest.fixture
def sample_txt_file():
    """Create a sample text file for upload testing."""
    content = b"This is a test file content for upload testing."
    return BytesIO(content)


@pytest.fixture
def sample_docx_file():
    """Create a mock docx file for upload testing."""
    # Mock DOCX file header
    content = b'PK\x03\x04' + b'\x00' * 26 + b'word/document.xml'
    return BytesIO(content)


@pytest.fixture
def sample_pdf_file():
    """Create a mock PDF file for upload testing."""
    content = b'%PDF-1.4\n1 0 obj\n<<\n/Type /Catalog\n>>\nendobj\n'
    return BytesIO(content)


@pytest.fixture
def large_text():
    """Return text exceeding max length for boundary testing."""
    return "word " * 15000


# ============================================================
# MOCK FIXTURES
# ============================================================

@pytest.fixture
def mock_detect_ai():
    """Mock AI detection function."""
    with patch('services.ai_detector.detect_ai_content') as mock:
        mock.return_value = {
            'ai_score': 45.0,
            'human_score': 55.0,
            'confidence': 0.75,
            'status': 'Mixed',
            'model_used': 'heuristic_only',
            'model_breakdown': [],
            'disagreement_score': 0.0,
            'text_length': 100,
            'word_count': 20,
            'analysis_timestamp': 1234567890.0,
            'uncertainty_band': [25, 65]
        }
        yield mock


@pytest.fixture
def mock_check_plagiarism():
    """Mock plagiarism check function."""
    with patch('services.plagiarism.check_plagiarism') as mock:
        mock.return_value = {
            'score': 15.0,
            'status': 'Low',
            'engine': 'hybrid-web-semantic',
            'matches': 0,
            'sources': [],
            'semantic_matches': [],
            'language': 'en',
            'web_search_enabled': True,
            'local_score': 15.0,
            'web_score': 0.0,
            'semantic_score': 0.0,
            'processing_time': 1.5
        }
        yield mock


@pytest.fixture
def mock_grammar():
    """Mock grammar check function."""
    with patch('services.grammar.get_grammar_errors') as mock:
        mock.return_value = {
            'score': 92.0,
            'errors': [],
            'suggestions': []
        }
        yield mock


@pytest.fixture
def mock_readability():
    """Mock readability function."""
    with patch('services.readability.get_readability') as mock:
        mock.return_value = {
            'flesch_score': 65.0,
            'fog_score': 12.0,
            'grade_level': 'College'
        }
        yield mock


@pytest.fixture
def mock_sentiment():
    """Mock sentiment function."""
    with patch('services.sentiment.get_sentiment') as mock:
        mock.return_value = {
            'category': 'Neutral',
            'polarity': 0.1,
            'subjectivity': 0.5
        }
        yield mock


@pytest.fixture
def mock_seo():
    """Mock SEO function."""
    with patch('services.seo.get_seo_analysis') as mock:
        mock.return_value = {
            'keywords': [
                {'word': 'test', 'count': 5, 'density': 2.5},
                {'word': 'ai', 'count': 3, 'density': 1.5}
            ],
            'top_keyword': 'test',
            'word_count': 200
        }
        yield mock


@pytest.fixture
def mock_transformers():
    """Mock transformers pipeline for AI detection."""
    with patch('services.ai_detector.pipeline') as mock_pipeline:
        mock_detector = MagicMock()
        mock_detector.return_value = [{'label': 'LABEL_0', 'score': 0.55}]
        mock_pipeline.return_value = mock_detector
        yield mock_pipeline


@pytest.fixture
def mock_sentence_transformers():
    """Mock sentence-transformers for plagiarism."""
    with patch('services.plagiarism.SentenceTransformer') as mock:
        mock_model = MagicMock()
        mock_model.encode.return_value = MagicMock()
        mock.return_value = mock_model
        yield mock


@pytest.fixture
def mock_requests():
    """Mock requests for web search."""
    with patch('services.plagiarism.requests.get') as mock:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '<html><div class="result"><a class="result__a" href="https://example.com">Test Title</a><a class="result__snippet">This is a test snippet for matching.</a></div></html>'
        mock.return_value = mock_response
        yield mock


@pytest.fixture
def mock_nltk():
    """Mock NLTK functions."""
    with patch('services.plagiarism.sent_tokenize') as mock_sent, \
         patch('services.ai_detector.sent_tokenize') as mock_sent2:
        def tokenize_side_effect(text):
            return [s.strip() for s in text.split('.') if s.strip()]
        mock_sent.side_effect = tokenize_side_effect
        mock_sent2.side_effect = tokenize_side_effect
        yield


# ============================================================
# SECURITY FIXTURES
# ============================================================

@pytest.fixture
def malicious_filename():
    """Return malicious filenames for security testing."""
    return [
        '../../../etc/passwd',
        '..\\..\\windows\\system32\\config\\sam',
        'file<script>alert(1)</script>.txt',
        'normal_file.txt',
        '',
        '.',
        '..',
        'a' * 300 + '.txt',
        'file.exe',
        'file.txt.exe',
    ]


@pytest.fixture
def xss_payloads():
    """Return XSS payloads for security testing."""
    return [
        '<script>alert("xss")</script>',
        '<img src=x onerror=alert(1)>',
        'javascript:alert(1)',
        '<body onload=alert(1)>',
        'normal text without scripts',
    ]


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def create_test_json(data):
    """Helper to create JSON data for requests."""
    return json.dumps(data)


def assert_json_response(response, expected_status=200):
    """Helper to assert JSON response."""
    assert response.status_code == expected_status
    data = json.loads(response.data)
    return data