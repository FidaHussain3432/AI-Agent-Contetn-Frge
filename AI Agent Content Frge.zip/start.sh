#!/bin/bash
# ============================================================
# Content Analyzer & Humanizer Pro – V5.2
# One-Click Launcher (Linux / macOS)
# ============================================================

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================"
echo "🚀 Content Analyzer & Humanizer Pro"
echo "📝 One-Click Launcher (Unix) v5.2"
echo "========================================"
echo ""

# Check for Python 3
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
    echo "✅ Python found via 'python3'"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
    echo "✅ Python found via 'python'"
else
    echo "❌ Python not found!"
    echo ""
    echo "Please install Python 3.8 or higher from:"
    echo "  - https://www.python.org/downloads/"
    echo "  - Or use your package manager: sudo apt install python3"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo ""
echo "✅ Required folders:"
# Ensure required folders exist
mkdir -p templates uploads processed
echo "   📁 templates, uploads, processed (created if missing)"

echo ""
echo "🚀 Starting server..."
echo "📍 http://127.0.0.1:5000"
echo "⏳ Please wait, browser will open automatically."
echo ""

# Run the launcher script (run.py will open browser)
$PYTHON_CMD run.py

# If run.py exits, keep terminal open (unless user presses Enter)
read -p "Press Enter to close..."