# ============================================================
# RUN.PY - One-Click Launcher (V7.0-PHASE7)
# Updated for Python 3.12 + Full ML Stack + Testing & DevOps
# ============================================================

import subprocess
import sys
import os
import webbrowser
import time
import threading
import locale
import shutil
from pathlib import Path

# ============================================================
# FIX: Auto-detect project directory (CRITICAL for Windows)
# ============================================================

def get_project_directory():
    """
    Find the project directory containing app.py, config.py, etc.
    Priority:
    1. Directory where this script (run.py) is located
    2. Current working directory (fallback)
    """
    # Method 1: Get directory of this script file
    script_dir = Path(__file__).resolve().parent

    # Check if all required files are here
    if (script_dir / 'app.py').exists() and (script_dir / 'config.py').exists():
        return str(script_dir)

    # Method 2: Check current working directory
    cwd = Path.cwd()
    if (cwd / 'app.py').exists() and (cwd / 'config.py').exists():
        return str(cwd)

    # Method 3: Check if user passed directory as argument
    if len(sys.argv) > 1 and not sys.argv[1].startswith('--'):
        arg_dir = Path(sys.argv[1]).resolve()
        if arg_dir.exists() and (arg_dir / 'app.py').exists():
            return str(arg_dir)

    # Return script directory anyway (most reliable)
    return str(script_dir)


# Set project directory globally
PROJECT_DIR = get_project_directory()

# Change to project directory immediately
os.chdir(PROJECT_DIR)

print(f"📁 Project Directory: {PROJECT_DIR}")
print(f"📁 Current Working Directory: {os.getcwd()}")
print()


# Fix encoding for Windows
if sys.platform == 'win32':
    try:
        locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
    except:
        pass


# ============================================================
# COLORS FOR TERMINAL OUTPUT
# ============================================================
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'


def print_banner():
    """Print beautiful banner"""
    banner = f"""
{Colors.CYAN}{'='*60}
{Colors.HEADER}🚀 Content Analyzer & Humanizer Pro – V7.0-PHASE7
{Colors.BLUE}📝 One-Click Launcher · Blueprint Architecture · Full ML Stack
{Colors.CYAN}{'='*60}{Colors.END}
    """
    print(banner)


def print_step(step, message):
    """Print step with formatting"""
    print(f"{Colors.GREEN}✅ [{step}] {message}{Colors.END}")


def print_error(message, suggestion=None):
    """Print error message with optional suggestion"""
    print(f"{Colors.FAIL}❌ ERROR: {message}{Colors.END}")
    if suggestion:
        print(f"{Colors.DIM}💡 {suggestion}{Colors.END}")


def print_warning(message):
    """Print warning message"""
    print(f"{Colors.WARNING}⚠️ {message}{Colors.END}")


def print_info(message):
    """Print info message"""
    print(f"{Colors.BLUE}ℹ️ {message}{Colors.END}")


def print_success(message):
    """Print success message"""
    print(f"{Colors.GREEN}🎉 {message}{Colors.END}")


# ============================================================
# STEP 1: CHECK PYTHON
# ============================================================
def check_python():
    """Check if Python is installed and version is >= 3.8"""
    print_step("1", "Checking Python installation...")

    try:
        result = subprocess.check_output(
            [sys.executable, '--version'], 
            stderr=subprocess.STDOUT
        ).decode()
        version_str = result.strip()
        print(f"   ✅ {version_str}")

        import re
        match = re.search(r'(\d+)\.(\d+)', version_str)
        if match:
            major, minor = int(match.group(1)), int(match.group(2))
            if major < 3 or (major == 3 and minor < 8):
                print_warning(f"Python {major}.{minor} detected. Recommended: Python 3.8+")
                print_info("Some features may not work optimally. Consider upgrading.")
            elif major == 3 and minor >= 12:
                print_success(f"Python {major}.{minor} detected - Excellent! Full ML stack supported.")
        return True
    except Exception:
        print_error("Python not found! Please install Python 3.8 or higher.")
        print_info("Download from: https://www.python.org/downloads/")
        return False


# ============================================================
# STEP 2: CHECK REQUIRED FILES & FOLDER STRUCTURE
# ============================================================
def check_required_files():
    """Verify project structure for Phase 6/7 architecture"""
    print_step("2", "Checking architecture...")
    print(f"   📁 Scanning directory: {os.getcwd()}")

    # Core files
    core_files = ['app.py', 'config.py', 'run.py']
    # Blueprint routes
    route_files = [
        'routes/__init__.py',
        'routes/analyze.py',
        'routes/humanize.py',
        'routes/file_process.py',
        'routes/status.py'
    ]
    # Services
    service_files = [
        'services/__init__.py',
        'services/ai_detector.py',
        'services/plagiarism.py',
        'services/humanizer.py',
        'services/grammar.py',
        'services/readability.py',
        'services/sentiment.py',
        'services/seo.py',
        'services/file_handler.py'
    ]
    # Models & Utils
    model_files = ['models/__init__.py', 'models/database.py']
    util_files = [
        'utils/__init__.py',
        'utils/security.py',
        'utils/cache.py',
        'utils/logging_config.py'
    ]
    # Frontend (Phase 6+ structure)
    frontend_files = [
        'templates/index.html',
        'static/css/style.css',
        'static/js/main.js'
    ]
    # Phase 7 files
    phase7_files = [
        'pytest.ini',
        'tests/__init__.py',
        'tests/conftest.py'
    ]

    all_required = (
        core_files + route_files + service_files + 
        model_files + util_files + frontend_files + phase7_files
    )

    missing = []
    found = []

    for file in all_required:
        if os.path.exists(file):
            found.append(file)
        else:
            print(f"   ❌ {file} missing!")
            missing.append(file)

    if missing:
        print_error(f"Missing {len(missing)} files!")
        print_info("Ensure all Phase 6/7 files are in place.")
        print_info(f"Expected location: {os.getcwd()}")
        return False

    print_success(f"All {len(found)} required files found!")
    return True


# ============================================================
# STEP 3: INSTALL / UPDATE DEPENDENCIES
# ============================================================
def is_package_installed(package):
    """Check if a Python package is installed"""
    try:
        subprocess.check_call(
            [sys.executable, '-m', 'pip', 'show', package],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except:
        return False


def install_dependencies():
    """Install ALL required packages - NOTHING SKIPPED"""
    print_step("3", "Checking & installing dependencies...")
    print("   ⏳ This may take 5-10 minutes depending on your internet speed.")
    print("   🐢 Heavy packages (torch, transformers) will take time.")

    # Core packages
    core_packages = [
        'Flask', 'flask-cors', 'flask-sqlalchemy', 'sqlalchemy', 'alembic',
        'nltk', 'textstat', 'textblob', 'language-tool-python',
        'python-magic', 'bleach', 'python-dotenv'
    ]

    # ML / AI packages (FULL STACK - NOTHING SKIPPED)
    ml_packages = [
        'transformers', 'torch', 'accelerate',
        'sentence-transformers', 'scikit-learn'
    ]

    # Phase 3 packages (FULL - spaCy included)
    phase3_packages = [
        'spacy==3.7.2',
        'bert-score==0.3.13'
    ]

    # File processing
    file_packages = [
        'pdfplumber', 'python-docx', 'PyMuPDF', 'numpy'
    ]

    # Phase 7 packages
    phase7_packages = [
        'pytest', 'pytest-cov', 'pytest-mock', 'pytest-xdist',
        'gunicorn', 'prometheus-flask-exporter'
    ]

    all_packages = core_packages + ml_packages + phase3_packages + file_packages + phase7_packages
    installed = 0
    skipped = 0
    failed = []

    for package in all_packages:
        pkg_name = package.split('==')[0]  # Remove version specifier for check
        if is_package_installed(pkg_name):
            print(f"   ⏭️  {package} (already installed)")
            skipped += 1
            continue

        print(f"   📦 Installing {package}...")
        try:
            subprocess.check_call(
                [sys.executable, '-m', 'pip', 'install', package, '--quiet'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print(f"   ✅ {package}")
            installed += 1
        except KeyboardInterrupt:
            print(f"   ⚠️ Installation interrupted by user")
            failed.append(package)
            break
        except Exception as e:
            print(f"   ⚠️ Could not install {package}: {str(e)[:50]}")
            failed.append(package)

    # Special warnings
    if 'sentence-transformers' in failed:
        print_warning("sentence-transformers failed. Semantic similarity disabled.")
    if 'PyMuPDF' in failed:
        print_warning("PyMuPDF failed. PDF formatting preservation disabled.")
    if 'transformers' in failed:
        print_warning("transformers failed. AI detection will use heuristic fallback.")
    if 'spacy' in failed:
        print_warning("spaCy failed. Advanced dependency parsing disabled.")
        print_info("Retry: pip install spacy==3.7.2")
    if 'bert-score' in failed:
        print_warning("bert-score failed. BERTScore coherence check disabled.")

    print_success(f"Packages: {installed} installed, {skipped} skipped, {len(failed)} failed")
    return len(failed) <= 4  # Allow some failures


# ============================================================
# STEP 4: DOWNLOAD NLTK DATA
# ============================================================
def download_nltk_data():
    """Download required NLTK data"""
    print_step("4", "Downloading NLTK data...")

    try:
        import nltk
        packages = [
            'punkt', 'punkt_tab', 'averaged_perceptron_tagger',
            'wordnet', 'omw-1.4'
        ]

        for pkg in packages:
            try:
                nltk.data.find(
                    f'tokenizers/{pkg}' if pkg in ['punkt', 'punkt_tab'] 
                    else f'taggers/{pkg}' if pkg == 'averaged_perceptron_tagger'
                    else f'corpora/{pkg}'
                )
                print(f"   ⏭️  {pkg} (already downloaded)")
            except LookupError:
                print(f"   📥 Downloading {pkg}...")
                nltk.download(pkg, quiet=True)
                print(f"   ✅ {pkg}")

        print("   ✅ NLTK data ready!")
        return True
    except Exception as e:
        print_warning(f"NLTK data download issue: {e}")
        return False


# ============================================================
# STEP 5: DOWNLOAD spaCy MODEL
# ============================================================
def download_spacy_model():
    """Download spaCy English model if not present."""
    print_step("5", "Checking spaCy English model...")

    try:
        import spacy

        # Check if model already installed
        try:
            nlp = spacy.load("en_core_web_sm")
            print("   ⏭️  en_core_web_sm (already installed)")
            return True
        except OSError:
            pass

        # Try medium model
        try:
            nlp = spacy.load("en_core_web_md")
            print("   ⏭️  en_core_web_md (already installed)")
            return True
        except OSError:
            pass

        # Download small model
        print("   📥 Downloading en_core_web_sm (this may take 1-2 minutes)...")
        subprocess.check_call(
            [sys.executable, '-m', 'spacy', 'download', 'en_core_web_sm'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.STDOUT
        )
        print("   ✅ en_core_web_sm installed successfully!")
        return True

    except ImportError:
        print_warning("spaCy not installed. Skipping model download.")
        print_info("Install spaCy first: pip install spacy==3.7.2")
        return False
    except Exception as e:
        print_warning(f"spaCy model download failed: {e}")
        print_info("You can install manually: python -m spacy download en_core_web_sm")
        return False


# ============================================================
# STEP 6: SETUP FOLDERS
# ============================================================
def setup_folders():
    """Create required runtime folders"""
    print_step("6", "Setting up runtime folders...")

    folders = ['templates', 'uploads', 'processed', 'logs']
    for folder in folders:
        if not os.path.exists(folder):
            os.makedirs(folder)
            print(f"   📁 Created: {folder}")
        else:
            print(f"   📁 Found: {folder}")

    return True


# ============================================================
# STEP 7: CHECK ML PACKAGES
# ============================================================
def check_ml_packages():
    """Check if ML packages are installed"""
    print_step("7", "Checking ML/AI packages...")

    ml_packages = {
        'sentence-transformers': 'Semantic similarity & meaning preservation',
        'torch': 'PyTorch backend for AI detection',
        'transformers': 'RoBERTa AI detection model',
        'spacy': 'Dependency parsing (Phase 3)',
        'bert-score': 'BERTScore coherence (Phase 3)'
    }

    all_ok = True
    for pkg, desc in ml_packages.items():
        if is_package_installed(pkg):
            print(f"   ✅ {pkg} – {desc}")
        else:
            print(f"   ⚠️ {pkg} – {desc} (not installed)")
            all_ok = False

    if not all_ok:
        print_warning("Some ML packages missing. App will use fallback methods.")
        print_info("Install manually: pip install sentence-transformers torch transformers spacy bert-score")

    return all_ok


# ============================================================
# STEP 8: RUN TESTS (PHASE 7)
# ============================================================
def run_tests():
    """Run pytest test suite."""
    print_step("TEST", "Running test suite...")
    try:
        import pytest
        result = subprocess.run(
            [sys.executable, '-m', 'pytest', 'tests/', '-v'],
            capture_output=False,
            text=True
        )
        return result.returncode == 0
    except ImportError:
        print_warning("pytest not installed. Install with: pip install pytest")
        return False
    except Exception as e:
        print_error(f"Test execution failed: {e}")
        return False


def run_tests_coverage():
    """Run tests with coverage report."""
    print_step("TEST", "Running tests with coverage...")
    try:
        result = subprocess.run(
            [sys.executable, '-m', 'pytest', 'tests/', '-v', '--cov=.', '--cov-report=html'],
            capture_output=False,
            text=True
        )
        return result.returncode == 0
    except Exception as e:
        print_error(f"Coverage test failed: {e}")
        return False


# ============================================================
# STEP 9: START FLASK SERVER
# ============================================================
def start_server():
    """Start Flask server using app factory"""
    print_step("9", "Starting Flask server...")
    print(f"\n{Colors.GREEN}🚀 Server starting at: http://127.0.0.1:5000{Colors.END}")
    print(f"{Colors.BLUE}⏳ Waiting for server to initialize...{Colors.END}\n")

    # Open browser after delay
    def open_browser():
        time.sleep(4)
        try:
            webbrowser.open('http://127.0.0.1:5000')
            print(f"\n{Colors.CYAN}🌐 Browser opened automatically!{Colors.END}")
        except:
            print(f"\n{Colors.WARNING}⚠️ Could not open browser automatically.{Colors.END}")
            print(f"{Colors.GREEN}📝 Please open: http://127.0.0.1:5000{Colors.END}")

    threading.Thread(target=open_browser, daemon=True).start()

    # Start server using app factory
    try:
        # Import from project directory
        sys.path.insert(0, PROJECT_DIR)
        from app import create_app

        app = create_app()
        app.run(
            debug=False,
            use_reloader=False,
            host='0.0.0.0',
            port=5000
        )
    except KeyboardInterrupt:
        print(f"\n{Colors.WARNING}⚠️ Server stopped by user{Colors.END}")
    except Exception as e:
        print_error(f"Failed to start server: {e}")
        import traceback
        traceback.print_exc()
        print_info("Try running manually: python app.py")
        input("\nPress Enter to exit...")


# ============================================================
# MAIN FUNCTION
# ============================================================
def main():
    """Main launcher function"""

    # Show available flags
    if '--help' in sys.argv or '-h' in sys.argv:
        print(f"{Colors.CYAN}Usage: python run.py [options]{Colors.END}")
        print(f"{Colors.BLUE}Options:{Colors.END}")
        print(f"  --test        Run test suite")
        print(f"  --coverage    Run tests with coverage report")
        print(f"  --help        Show this help message")
        print()
        print(f"{Colors.GREEN}Examples:{Colors.END}")
        print(f"  python run.py          # Full setup + start server")
        print(f"  python run.py --test   # Run tests only")
        return

    # Check for test mode
    if '--test' in sys.argv:
        run_tests()
        return

    if '--coverage' in sys.argv:
        run_tests_coverage()
        return

    print_banner()

    # Show directory info
    print(f"{Colors.BLUE}📁 Project Directory: {PROJECT_DIR}{Colors.END}")
    print(f"{Colors.BLUE}📁 Working Directory: {os.getcwd()}{Colors.END}")
    print()

    # Check Python
    if not check_python():
        input("\nPress Enter to exit...")
        return

    # Check files
    if not check_required_files():
        print_error("Files not found in expected location!")
        print_info(f"Please ensure all files are in: {PROJECT_DIR}")
        print_info("Or run: python run.py <path_to_project_folder>")
        input("\nPress Enter to exit...")
        return

    # Install dependencies
    install_dependencies()

    # Download NLTK
    download_nltk_data()

    # Download spaCy model
    download_spacy_model()

    # Setup folders
    setup_folders()

    # Check ML
    check_ml_packages()

    # Success message
    print(f"\n{Colors.GREEN}{'='*60}")
    print("🎉 PHASE 7 SETUP COMPLETE!")
    print("📝 Blueprint Architecture Ready")
    print("🔬 Testing Suite Ready")
    print("🐳 Docker Support Enabled")
    print("📊 Monitoring Ready")
    print("🧠 BERT WSD Enabled")
    print("🔗 spaCy Dependency Parsing Enabled")
    print("📊 BERTScore Coherence Check Enabled")
    print("💬 Smart Transitions Enabled")
    print("🔒 Security hardening active")
    print(f"{'='*60}{Colors.END}\n")

    # Start server
    start_server()


# ============================================================
# RUN
# ============================================================
if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Colors.WARNING}⚠️ Setup cancelled by user{Colors.END}")
        input("\nPress Enter to exit...")
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        print_info("Please check that all files are in the correct directory.")
        input("\nEnter to exit...")