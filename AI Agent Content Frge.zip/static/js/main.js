// ================================================
// MAIN.JS - Application Entry Point
// V6.0-PHASE6 - Modular Architecture with Alpine.js
// Features: ES6 Modules | Alpine.js Reactive UI | SSE | PWA
// ================================================

import { initStateStore } from './modules/state.js';
import { API, SecurityHelpers, safeGet, safeNumber } from './modules/api.js';
import { Toast, Popup, initParticles, initScrollReveal, initMobileMenu, initKeyboardShortcuts, UIHelpers, exportPDF, exportTXT } from './modules/ui.js';
import { ChartManager } from './modules/charts.js';
import { SSEManager } from './modules/sse.js';

// ================================================
// ALPINE.JS APP INITIALIZATION
// ================================================

document.addEventListener('alpine:init', () => {
    console.log('🚀 Alpine.js initializing...');

    // Initialize global state store
    initStateStore();

    // Register main app component
    Alpine.data('app', () => ({
        // Theme & Navigation
        theme: 'dark',
        scrolled: false,
        mobileOpen: false,

        init() {
            this.theme = localStorage.getItem('theme') || 'dark';
            document.documentElement.setAttribute('data-theme', this.theme);

            // Scroll listener for header
            window.addEventListener('scroll', () => {
                this.scrolled = window.scrollY > 50;
            });

            // Load saved content
            this.$store.appState.loadFromLocal();

            // Initialize particles
            initParticles();

            // Initialize scroll reveal
            setTimeout(() => initScrollReveal(), 100);

            // Check server status
            API.checkStatus().then(data => {
                if (data?.ai_available) Toast.success('AI Model Ready!');
            });

            console.log('✅ App initialized!');
        },

        toggleTheme() {
            this.theme = this.theme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', this.theme);
            localStorage.setItem('theme', this.theme);
        },

        // Content Management
        get content() { return this.$store.appState.content; },
        set content(val) { this.$store.appState.setContent(val); },

        get wordCount() { return this.$store.appState.wordCount; },
        get isOverLimit() { return this.$store.appState.isOverLimit; },

        saveContent() {
            this.$store.appState.saveToLocal();
        },

        clearContent() {
            this.$store.appState.clearContent();
            Toast.info('Content cleared');
        },

        // Feature Focus
        get featureFocus() { return this.$store.appState.featureFocus; },
        get features() { return this.$store.appState.features; },

        setFeatureFocus(id) {
            this.$store.appState.setFeatureFocus(id);
        },

        // Analysis State
        get isAnalyzing() { return this.$store.appState.isAnalyzing; },
        get isProcessing() { return this.$store.appState.isProcessing; },
        get showResults() { return this.$store.appState.showResults; },
        get showLoading() { return this.$store.appState.showLoading; },
        get loadingProgress() { return this.$store.appState.loadingProgress; },
        get loadingLabel() { return this.$store.appState.loadingLabel; },
        get canAnalyze() { return this.$store.appState.canAnalyze; },

        // Results
        get results() { return this.$store.appState.results; },
        get hasResults() { return this.$store.appState.hasResults; },
        get originalContent() { return this.$store.appState.originalContent; },
        get humanizedContent() { return this.$store.appState.humanizedContent; },
        get reduceStatus() { return this.$store.appState.reduceStatus; },

        // Format Upload
        get formatFile() { return this.$store.appState.formatFile; },

        // ================================================
        // FILE UPLOAD (Drag & Drop)
        // ================================================
        handleDragOver(e) {
            e.preventDefault();
            e.currentTarget.classList.add('dragover');
        },

        handleDragLeave(e) {
            e.preventDefault();
            e.currentTarget.classList.remove('dragover');
        },

        handleDrop(e) {
            e.preventDefault();
            e.currentTarget.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                this.handleFileUpload({ target: { files: [e.dataTransfer.files[0]] } });
            }
        },

        async handleFileUpload(e) {
            const file = e.target.files[0];
            if (!file) return;

            const typeCheck = SecurityHelpers.validateFileType(file);
            if (!typeCheck.valid) {
                Popup.warning('Invalid File', typeCheck.error);
                return;
            }

            const sizeCheck = SecurityHelpers.validateFileSize(file);
            if (!sizeCheck.valid) {
                Popup.warning('File Too Large', sizeCheck.error);
                return;
            }

            // Show loading in upload area
            const uploadArea = document.getElementById('uploadArea');
            if (uploadArea) {
                uploadArea.innerHTML = `
                    <div class="upload-loading">
                        <i class="fas fa-spinner fa-spin" style="font-size: 48px; color: var(--primary);"></i>
                        <h3>Uploading ${SecurityHelpers.sanitizeText(file.name)}...</h3>
                        <p>Please wait...</p>
                    </div>
                `;
            }

            try {
                const data = await API.uploadFile(file);
                if (data.success) {
                    this.content = SecurityHelpers.sanitizeText(data.content);
                    this.$store.appState.originalContent = this.content;
                    Toast.success(`File uploaded! (${data.word_count} words)`);

                    // Reset upload area
                    this.resetUploadArea();

                    // Auto-analyze
                    setTimeout(() => this.startAnalysis(), 500);
                } else {
                    throw new Error(data.error || 'Upload failed');
                }
            } catch (error) {
                Popup.error('Upload Error', SecurityHelpers.sanitizeText(error.message));
                this.resetUploadArea();
            }
        },

        resetUploadArea() {
            const uploadArea = document.getElementById('uploadArea');
            if (!uploadArea) return;

            uploadArea.innerHTML = `
                <div class="upload-content">
                    <div class="upload-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                    <h3>Drag & Drop Your File</h3>
                    <p>or click to browse</p>
                    <span class="upload-formats">Supports: .txt, .docx, .pdf</span>
                    <input type="file" id="fileInput" accept=".txt,.docx,.pdf" hidden />
                    <button class="btn btn-primary browse-btn" onclick="document.getElementById('fileInput').click()">
                        <i class="fas fa-folder-open"></i> Browse Files
                    </button>
                </div>
            `;

            // Re-attach listener
            const fileInput = document.getElementById('fileInput');
            if (fileInput) {
                fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
            }
        },

        // ================================================
        // ANALYSIS
        // ================================================
        async startAnalysis() {
            const content = this.content?.trim();

            if (!content) {
                Popup.warning('Empty Content', 'Please paste some content or upload a file.');
                return;
            }

            const lengthCheck = SecurityHelpers.validateContentLength(content);
            if (!lengthCheck.valid) {
                Popup.error('Too Many Words', lengthCheck.error);
                return;
            }

            this.$store.appState.isAnalyzing = true;
            this.$store.appState.setLoading(true, 5, 'Preparing content...');
            this.$store.appState.originalContent = content;

            try {
                const data = await API.analyze(content);

                if (data.success) {
                    this.$store.appState.setResults(data.results);
                    this.$store.appState.setLoading(false);

                    // Initialize charts
                    setTimeout(() => {
                        ChartManager.initAll(data.results);
                    }, 100);

                    Toast.success('Analysis complete!');

                    // Scroll to results
                    setTimeout(() => {
                        const resultsSection = document.getElementById('results');
                        if (resultsSection) resultsSection.scrollIntoView({ behavior: 'smooth' });
                    }, 300);
                } else {
                    throw new Error(data.error || 'Analysis failed');
                }
            } catch (error) {
                Popup.error('Analysis Error', SecurityHelpers.sanitizeText(error.message));
                this.$store.appState.setLoading(false);
            } finally {
                this.$store.appState.isAnalyzing = false;
            }
        },

        // ================================================
        // HUMANIZATION
        // ================================================
        async startReduceBoth() {
            const content = this.content?.trim();
            if (!content) {
                Popup.warning('No Content', 'Please analyze content first.');
                return;
            }

            if (this.isProcessing) {
                Popup.info('Already Running', 'A process is already in progress.');
                return;
            }

            this.$store.appState.isProcessing = true;
            this.$store.appState.reduceStatus = {
                show: true,
                status: 'Starting...',
                loop: 0,
                ai: 0,
                plagiarism: 0,
                grammar: 0
            };

            try {
                // Try SSE first, fallback to legacy stream
                const callbacks = {
                    onProgress: (data) => {
                        this.$store.appState.reduceStatus = {
                            show: true,
                            status: `Processing... Loop ${data.loop}`,
                            loop: data.loop,
                            ai: data.ai_score,
                            plagiarism: data.plagiarism,
                            grammar: data.grammar
                        };
                    },
                    onComplete: (data) => {
                        this.$store.appState.reduceStatus = {
                            show: true,
                            status: data.ai_score <= 5 && data.plagiarism <= 5 ? 'Complete! Targets achieved!' : 'Stopped',
                            loop: data.loop || 0,
                            ai: data.ai_score || 0,
                            plagiarism: data.plagiarism || 0,
                            grammar: data.grammar || 0
                        };

                        if (data.content) {
                            this.$store.appState.humanizedContent = data.content;
                            this.$store.appState.isHumanized = true;
                            this.$store.appState.content = data.content;
                        }

                        if (data.ai_score <= 5 && data.plagiarism <= 5) {
                            Popup.success('Complete!', `AI: ${data.ai_score}% | Plagiarism: ${data.plagiarism}% | Grammar: ${data.grammar}%`);
                        } else {
                            Popup.warning('Partial', `AI: ${data.ai_score}% | Plagiarism: ${data.plagiarism}% | Grammar: ${data.grammar}%`);
                        }
                    },
                    onError: (error) => {
                        Popup.error('Error', error.message || 'Stream failed');
                    }
                };

                // Use SSE for real-time updates
                await SSEManager.connectReduceBoth(content, 100, callbacks);

            } catch (error) {
                console.warn('SSE failed, trying legacy stream:', error);
                // Fallback to legacy fetch-based streaming
                try {
                    const { streamReduceBothLegacy } = await import('./modules/sse.js');
                    await streamReduceBothLegacy(content, callbacks);
                } catch (fallbackError) {
                    Popup.error('Error', SecurityHelpers.sanitizeText(fallbackError.message));
                }
            } finally {
                this.$store.appState.isProcessing = false;
            }
        },

        async startAutoHumanize() {
            const content = this.content?.trim();
            if (!content) {
                Popup.warning('No Content', 'Please analyze content first.');
                return;
            }

            if (this.isProcessing) {
                Popup.info('Already Running', 'A process is already in progress.');
                return;
            }

            this.$store.appState.isProcessing = true;
            this.$store.appState.reduceStatus = {
                show: true,
                status: 'Humanizing...',
                loop: 0,
                ai: 0,
                plagiarism: 0,
                grammar: 0
            };

            try {
                const data = await API.humanizeAuto(content, 100);

                if (data.success) {
                    this.$store.appState.humanizedContent = data.humanized_content;
                    this.$store.appState.isHumanized = true;
                    this.$store.appState.content = data.humanized_content;
                    this.$store.appState.autoHistory = data.history || [];

                    const final = data.final_scores || {};
                    this.$store.appState.reduceStatus = {
                        show: true,
                        status: final.status || 'Done',
                        loop: data.total_loops || 0,
                        ai: final.ai_score || 0,
                        plagiarism: final.plagiarism || 0,
                        grammar: final.grammar || 0
                    };

                    if (final.status === 'Complete!') {
                        Popup.success('Humanization Complete!', 
                            `AI: ${final.ai_score}% | Plagiarism: ${final.plagiarism}% | Grammar: ${final.grammar}%`);
                    } else {
                        Popup.warning('Needs Improvement', 
                            `AI: ${final.ai_score}% | Plagiarism: ${final.plagiarism}% | Grammar: ${final.grammar}%`);
                    }
                } else {
                    throw new Error(data.error || 'Humanization failed');
                }
            } catch (error) {
                Popup.error('Error', SecurityHelpers.sanitizeText(error.message));
            } finally {
                this.$store.appState.isProcessing = false;
            }
        },

        // ================================================
        // FORMAT UPLOAD (DOCX/PDF)
        // ================================================
        handleFormatUpload(e, type) {
            const file = e.target.files[0];
            if (!file) return;

            const ext = file.name.split('.').pop().toLowerCase();
            if (ext !== type) {
                Popup.warning('Invalid File', `Please upload a .${type} file.`);
                e.target.value = '';
                return;
            }

            this.$store.appState.formatFile = file;
            this.$store.appState.formatType = type;
            Toast.info(`Uploaded ${SecurityHelpers.sanitizeText(file.name)}`);
        },

        async downloadHumanizedFile() {
            const file = this.$store.appState.formatFile;
            if (!file) {
                Popup.warning('No File', 'Please upload a DOCX or PDF file first.');
                return;
            }

            this.$store.appState.isProcessing = true;
            Toast.info(`Processing ${SecurityHelpers.sanitizeText(file.name)}...`);

            try {
                const data = await API.processFileKeepStyle(file);
                if (data.success) {
                    const downloadUrl = API.getDownloadUrl(data.job_id, data.download_name);
                    window.open(downloadUrl, '_blank');
                    Popup.success('Download Started!', `Your humanized file is being downloaded.`);
                } else {
                    throw new Error(data.error || 'Processing failed');
                }
            } catch (error) {
                Popup.error('Error', SecurityHelpers.sanitizeText(error.message));
            } finally {
                this.$store.appState.isProcessing = false;
            }
        },

        // ================================================
        // COPY & EXPORT
        // ================================================
        copyHumanized() {
            const content = this.$store.appState.humanizedContent;
            if (!content) {
                Popup.warning('No Content', 'Please humanize the content first.');
                return;
            }

            navigator.clipboard.writeText(content)
                .then(() => Toast.success('Copied to clipboard!'))
                .catch(() => {
                    const textarea = document.createElement('textarea');
                    textarea.value = content;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    Toast.success('Copied to clipboard!');
                });
        },

        exportPDF() {
            exportPDF(
                this.content,
                this.results,
                this.humanizedContent,
                this.$store.appState.autoHistory
            );
        },

        exportTXT() {
            exportTXT(
                this.content,
                this.results,
                this.humanizedContent,
                this.$store.appState.autoHistory
            );
        }
    }));

    // Mobile Menu Component
    Alpine.data('mobileMenu', () => ({
        open: false,
        toggle() { this.open = !this.open; },
        close() { this.open = false; }
    }));

    // Drag Drop Component
    Alpine.data('dragDrop', () => ({
        dragging: false,
        handleDragOver(e) { e.preventDefault(); this.dragging = true; },
        handleDragLeave(e) { e.preventDefault(); this.dragging = false; }
    }));

    // Scroll Reveal Component
    Alpine.data('scrollReveal', () => ({
        visible: false,
        init() {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.visible = true;
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            observer.observe(this.$el);
        }
    }));

    console.log('✅ Alpine.js components registered!');
});

// ================================================
// DOM READY INITIALIZATION
// ================================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Content Analyzer & Humanizer Pro v6.0-PHASE6 loaded!');
    console.log('📦 Modular JS | Alpine.js | SSE | PWA Ready');
    console.log('💡 Ctrl+Enter (Analyze) | Ctrl+Shift+R (Reduce Both) | Escape (Clear)');

    // Initialize keyboard shortcuts
    initKeyboardShortcuts();

    // Initialize mobile menu
    initMobileMenu();

    // Register Service Worker for PWA
    registerServiceWorker();
});

// ================================================
// SERVICE WORKER REGISTRATION (PWA)
// ================================================
async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/sw.js');
            console.log('✅ Service Worker registered:', registration.scope);

            // Listen for updates
            registration.addEventListener('updatefound', () => {
                const newWorker = registration.installing;
                newWorker.addEventListener('statechange', () => {
                    if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                        Toast.info('Update available! Refresh to update.');
                    }
                });
            });
        } catch (error) {
            console.warn('⚠️ Service Worker registration failed:', error);
        }
    }
}

// ================================================
// PWA INSTALL PROMPT
// ================================================
let deferredPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    console.log('📲 PWA install prompt available');
});

export function promptInstall() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                Toast.success('App installed!');
            }
            deferredPrompt = null;
        });
    }
}