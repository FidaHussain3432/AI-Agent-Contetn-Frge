// ================================================
// MODULES/UI.JS - UI Components & Alpine.js Logic
// V6.0-PHASE6 - Reactive UI with Alpine.js
// ================================================

import { API, SecurityHelpers, safeGet, safeNumber } from './api.js';
import { ChartManager } from './charts.js';
import { SSEManager } from './sse.js';

/**
 * Toast Notification System
 */
export const Toast = {
    container: null,

    getContainer() {
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'toastContainer';
            this.container.style.cssText = `
                position: fixed; bottom: 24px; right: 24px;
                z-index: 10001; display: flex; flex-direction: column;
                gap: 8px; max-width: 400px;
            `;
            document.body.appendChild(this.container);
        }
        return this.container;
    },

    show(message, type = 'info', duration = 3000) {
        const container = this.getContainer();
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        const safeMessage = SecurityHelpers.sanitizeText(message);
        toast.innerHTML = `<i class="fas ${this.getIcon(type)}"></i><span>${safeMessage}</span>`;
        container.appendChild(toast);
        requestAnimationFrame(() => toast.classList.add('active'));
        setTimeout(() => {
            toast.classList.remove('active');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    getIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[type] || icons.info;
    },

    success(msg) { this.show(msg, 'success'); },
    error(msg) { this.show(msg, 'error', 5000); },
    warning(msg) { this.show(msg, 'warning', 4000); },
    info(msg) { this.show(msg, 'info'); }
};

/**
 * Popup/Modal System
 */
export const Popup = {
    show(options) {
        const { type, title, message, duration = 4000, onConfirm, onCancel } = options;
        const existing = document.querySelector('.custom-popup-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.className = 'custom-popup-overlay';
        const safeTitle = SecurityHelpers.sanitizeText(title || 'Notice');
        const safeMessage = SecurityHelpers.sanitizeText(message || '');

        overlay.innerHTML = `
            <div class="custom-popup ${type}">
                <div class="popup-icon"><i class="fas ${this.getIcon(type)}"></i></div>
                <div class="popup-content">
                    <h3 class="popup-title">${safeTitle}</h3>
                    <p class="popup-message">${safeMessage}</p>
                </div>
                <div class="popup-actions">
                    ${onCancel ? `<button class="popup-btn cancel" id="popupCancel">Cancel</button>` : ''}
                    ${onConfirm ? `<button class="popup-btn confirm" id="popupConfirm">OK</button>` : ''}
                    ${!onConfirm && !onCancel ? `<button class="popup-btn confirm" id="popupClose">OK</button>` : ''}
                </div>
                <button class="popup-close" id="popupX">&times;</button>
            </div>
        `;
        document.body.appendChild(overlay);

        // Event listeners
        const closeBtn = overlay.querySelector('#popupClose, #popupX');
        if (closeBtn) closeBtn.addEventListener('click', () => this.close());

        const confirmBtn = overlay.querySelector('#popupConfirm');
        if (confirmBtn) confirmBtn.addEventListener('click', () => { onConfirm?.(); this.close(); });

        const cancelBtn = overlay.querySelector('#popupCancel');
        if (cancelBtn) cancelBtn.addEventListener('click', () => { onCancel?.(); this.close(); });

        if (!onConfirm && !onCancel && duration > 0) {
            setTimeout(() => this.close(), duration);
        }
        requestAnimationFrame(() => overlay.classList.add('active'));
    },

    getIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle',
            loading: 'fa-spinner fa-spin'
        };
        return icons[type] || icons.info;
    },

    close() {
        const overlay = document.querySelector('.custom-popup-overlay');
        if (overlay) {
            overlay.classList.remove('active');
            setTimeout(() => overlay.remove(), 300);
        }
    },

    success(title, msg, dur) { this.show({ type: 'success', title, message: msg, duration: dur || 3000 }); },
    error(title, msg, dur) { this.show({ type: 'error', title, message: msg, duration: dur || 5000 }); },
    warning(title, msg, dur) { this.show({ type: 'warning', title, message: msg, duration: dur || 4000 }); },
    info(title, msg, dur) { this.show({ type: 'info', title, message: msg, duration: dur || 3000 }); },
    confirmAction(title, msg, onConfirm, onCancel) {
        this.show({ type: 'warning', title, message: msg, onConfirm, onCancel, duration: 0 });
    }
};

/**
 * Particle Animation System
 */
export function initParticles() {
    const particles = document.getElementById('particles');
    if (!particles) return;

    particles.innerHTML = '';
    const count = 50;
    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.cssText = `
            position: absolute;
            width: ${Math.random() * 4 + 2}px;
            height: ${Math.random() * 4 + 2}px;
            background: rgba(108,99,255,${Math.random() * 0.5 + 0.1});
            border-radius: 50%;
            top: ${Math.random() * 100}%;
            left: ${Math.random() * 100}%;
            animation: float ${Math.random() * 10 + 5}s ease-in-out infinite;
            animation-delay: ${Math.random() * 5}s;
        `;
        particles.appendChild(p);
    }
}

/**
 * Scroll Reveal Animation
 */
export function initScrollReveal() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.lazy-section, .feature-card, .summary-card, .chart-box').forEach(el => {
        el.classList.add('scroll-hidden');
        observer.observe(el);
    });
}

/**
 * Mobile Menu Handler
 */
export function initMobileMenu() {
    const mobileBtn = document.querySelector('.mobile-menu');
    const navLinks = document.querySelector('.nav-links');

    if (mobileBtn && navLinks) {
        mobileBtn.addEventListener('click', () => {
            navLinks.classList.toggle('open');
            const icon = mobileBtn.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            }
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
                const icon = mobileBtn.querySelector('i');
                if (icon) { icon.classList.add('fa-bars'); icon.classList.remove('fa-times'); }
            });
        });
    }
}

/**
 * Keyboard Shortcuts
 */
export function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Ctrl+Enter = Analyze
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            const analyzeBtn = document.querySelector('.analyze-btn');
            if (analyzeBtn && !analyzeBtn.disabled) analyzeBtn.click();
        }
        // Escape = Clear
        if (e.key === 'Escape') {
            const clearBtn = document.querySelector('.btn-clear');
            if (clearBtn) clearBtn.click();
        }
        // Ctrl+Shift+R = Reduce Both
        if (e.ctrlKey && e.shiftKey && e.key === 'R') {
            e.preventDefault();
            const reduceBtn = document.querySelector('.btn-reduce-both');
            if (reduceBtn && !reduceBtn.disabled) reduceBtn.click();
        }
    });
}

/**
 * UI Update Helpers
 */
export const UIHelpers = {
    updateElement(el, value) {
        if (el) el.textContent = value;
    },

    updateRing(element, percent, color) {
        if (!element) return;
        const circumference = 339.292;
        const offset = circumference - (percent / 100) * circumference;
        element.style.strokeDashoffset = offset;
        element.style.stroke = color;
    },

    updateStatus(element, score, good, medium, bad) {
        if (!element) return;
        element.className = 'card-status';
        if (score < 30 && good) {
            element.textContent = good;
            element.classList.add('success');
        } else if (score < 60 && medium) {
            element.textContent = medium;
            element.classList.add('warning');
        } else {
            element.textContent = bad;
            element.classList.add('danger');
        }
    },

    animateNumber(element, target, suffix = '') {
        if (!element) return;
        let current = 0;
        const increment = Math.max(1, Math.ceil(target / 30));
        const interval = setInterval(() => {
            current += increment;
            if (current >= target) { current = target; clearInterval(interval); }
            element.textContent = Math.floor(current) + suffix;
        }, 30);
    },

    getScoreColor(score, type) {
        switch (type) {
            case 'plagiarism': return score < 10 ? '#00C853' : '#FF6B6B';
            case 'ai': return score < 30 ? '#00C853' : '#FF6B6B';
            case 'human': return score > 70 ? '#00C853' : '#FFD93D';
            case 'grammar': return score > 80 ? '#00C853' : '#FF6B6B';
            default: return '#6C63FF';
        }
    }
};

/**
 * Export handlers
 */
export function exportPDF(content, results, humanizedContent, autoHistory) {
    if (!content) {
        Popup.warning('No Content', 'Please analyze content first.');
        return;
    }

    const reportContent = `
CONTENT ANALYSIS REPORT
=======================

Original Content: ${content.substring(0, 500)}...

Analysis Results:
- Plagiarism: ${safeGet(results, 'plagiarism.score', 'N/A')}%
- AI Score: ${safeGet(results, 'ai_detection.ai_score', 'N/A')}%
- Human Score: ${safeGet(results, 'ai_detection.human_score', 'N/A')}%
- Grammar Score: ${safeGet(results, 'grammar.score', 'N/A')}%
- Readability (Flesch): ${safeGet(results, 'readability.flesch_score', 'N/A')}
- Sentiment: ${safeGet(results, 'sentiment.category', 'N/A')}
- Word Count: ${safeGet(results, 'word_stats.word_count', 'N/A')}

${humanizedContent ? '\nHumanized Content:\n' + humanizedContent : '\nNot humanized yet.'}

${autoHistory.length > 0 ? '\n\nHumanization History:\n' + autoHistory.map(h => 
    `Loop ${h.loop}: AI ${h.ai_score}% | Plagiarism ${h.plagiarism}% | Grammar ${h.grammar}% - ${h.status}`
).join('\n') : ''}
    `;

    const win = window.open('', '_blank');
    if (win) {
        win.document.write(`
            <html><head><title>Content Analysis Report</title></head>
            <body><pre style="font-family:'Inter',sans-serif;padding:40px;white-space:pre-wrap;word-wrap:break-word;max-width:800px;margin:0 auto;">${SecurityHelpers.sanitizeText(reportContent)}</pre>
            <script>setTimeout(()=>{window.print();window.close();},500);<\/script>
            </body></html>
        `);
        win.document.close();
        Toast.success('📄 PDF report generated!');
    }
}

export function exportTXT(content, results, humanizedContent, autoHistory) {
    if (!content) {
        Popup.warning('No Content', 'Please analyze content first.');
        return;
    }

    const reportContent = `Content Analysis Report
======================

Original Content:
${content.substring(0, 1000)}...

Analysis Results:
- Plagiarism: ${safeGet(results, 'plagiarism.score', 'N/A')}%
- AI Score: ${safeGet(results, 'ai_detection.ai_score', 'N/A')}%
- Human Score: ${safeGet(results, 'ai_detection.human_score', 'N/A')}%
- Grammar Score: ${safeGet(results, 'grammar.score', 'N/A')}%
- Word Count: ${safeGet(results, 'word_stats.word_count', 'N/A')}
- Character Count: ${safeGet(results, 'word_stats.char_count', 'N/A')}
- Paragraphs: ${safeGet(results, 'word_stats.paragraph_count', 'N/A')}
- Sentences: ${safeGet(results, 'word_stats.sentence_count', 'N/A')}
- Reading Time: ${safeGet(results, 'word_stats.reading_time', 'N/A')} min
- Readability (Flesch): ${safeGet(results, 'readability.flesch_score', 'N/A')}
- Readability (Fog): ${safeGet(results, 'readability.fog_score', 'N/A')}
- Sentiment: ${safeGet(results, 'sentiment.category', 'N/A')}
- Top Keyword: ${safeGet(results, 'seo.top_keyword', 'N/A')}

Grammar Suggestions:
${(safeGet(results, 'grammar.errors', [])).length > 0 
    ? safeGet(results, 'grammar.errors', []).map(e => '- ' + (e.message || e)).join('\n') 
    : 'No errors found.'}

${humanizedContent ? '\nHumanized Content:\n' + humanizedContent : '\nNot humanized yet.'}

${autoHistory.length > 0 ? '\n\nHumanization History:\n' + autoHistory.map(h => 
    `Loop ${h.loop}: AI ${h.ai_score}% | Plagiarism ${h.plagiarism}% | Grammar ${h.grammar}% - ${h.status}`
).join('\n') : ''}
    `;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'content-analysis-report.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    Toast.success('📄 TXT report downloaded!');
}

export { Toast as toast, Popup as popup };