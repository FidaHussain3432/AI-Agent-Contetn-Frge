// ================================================
// MODULES/CHARTS.JS - Chart.js Integration
// V6.0-PHASE6 - Modular Chart Management
// ================================================

import { safeGet, safeNumber } from './api.js';

/**
 * Chart Manager - handles all Chart.js instances
 */
export const ChartManager = {
    instances: {},

    destroyAll() {
        Object.values(this.instances).forEach(chart => {
            if (chart) { try { chart.destroy(); } catch {} }
        });
        this.instances = {};
    },

    initReadabilityChart(canvasId, results) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const flesch = safeNumber(safeGet(results, 'readability.flesch_score'));
        const fog = safeNumber(safeGet(results, 'readability.fog_score'));
        const humanScore = safeNumber(safeGet(results, 'ai_detection.human_score'));
        const grammarScore = safeNumber(safeGet(results, 'grammar.score'));
        const sentiment = safeGet(results, 'sentiment.category', 'Neutral');

        this.instances.readability = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Flesch', 'Fog', 'Human Score', 'Grammar', 'Sentiment'],
                datasets: [{
                    label: 'Content Quality',
                    data: [
                        flesch / 100 * 100,
                        (14 - fog) / 14 * 100,
                        humanScore,
                        grammarScore,
                        sentiment === 'Positive' ? 90 : sentiment === 'Neutral' ? 50 : 30
                    ],
                    backgroundColor: 'rgba(108,99,255,0.2)',
                    borderColor: '#6C63FF',
                    borderWidth: 2,
                    pointBackgroundColor: '#6C63FF',
                    pointBorderColor: '#FFFFFF',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    r: {
                        min: 0, max: 100,
                        ticks: { stepSize: 20, color: '#6A6A8A', backdropColor: 'transparent' },
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        angleLines: { color: 'rgba(255,255,255,0.05)' },
                        pointLabels: { color: '#B0B0C8', font: { size: 12 } }
                    }
                },
                plugins: { legend: { labels: { color: '#B0B0C8' } } }
            }
        });
    },

    initSentimentChart(canvasId, results) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const sentiment = safeGet(results, 'sentiment.category', 'Neutral');
        const data = {
            Positive: sentiment === 'Positive' ? 70 : 20,
            Neutral: sentiment === 'Neutral' ? 70 : 20,
            Negative: sentiment === 'Negative' ? 70 : 20,
        };

        this.instances.sentiment = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Positive', 'Neutral', 'Negative'],
                datasets: [{
                    data: [data.Positive, data.Neutral, data.Negative],
                    backgroundColor: ['#00C853', '#FFD93D', '#FF6B6B'],
                    borderColor: '#1A1A2E',
                    borderWidth: 2,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#B0B0C8', padding: 12, font: { size: 12 } }
                    }
                }
            }
        });
    },

    initSEOChart(canvasId, results) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const keywords = safeGet(results, 'seo.keywords', []);
        if (!keywords || keywords.length === 0) return;

        const ctx = canvas.getContext('2d');
        const top5 = keywords.slice(0, 5);

        this.instances.seo = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: top5.map(k => String(k.word || '')),
                datasets: [{
                    label: 'Keyword Density (%)',
                    data: top5.map(k => safeNumber(k.density)),
                    backgroundColor: [
                        'rgba(108,99,255,0.8)',
                        'rgba(0,212,255,0.8)',
                        'rgba(0,200,83,0.8)',
                        'rgba(255,107,107,0.8)',
                        'rgba(255,217,61,0.8)',
                    ],
                    borderColor: '#1A1A2E',
                    borderWidth: 2,
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#B0B0C8' } },
                    y: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#B0B0C8', stepSize: 10 }, max: 35 }
                },
                plugins: { legend: { labels: { color: '#B0B0C8' } } }
            }
        });
    },

    initAll(results) {
        this.destroyAll();
        this.initReadabilityChart('readabilityChart', results);
        this.initSentimentChart('sentimentChart', results);
        this.initSEOChart('seoChart', results);
    }
};