// ================================================
// MODULES/API.JS - API Communication Layer
// V6.0-PHASE6 - Secure API with SSE Support
// ================================================

const API_BASE = window.location.origin + '/api';

/**
 * Security Helpers - XSS Prevention & Input Validation
 */
export const SecurityHelpers = {
    sanitizeText(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#x27;');
    },

    validateFileType(file) {
        if (!file) return { valid: false, error: 'No file selected' };
        const validExtensions = ['.txt', '.docx', '.pdf'];
        const fileName = file.name.toLowerCase();
        const ext = '.' + fileName.split('.').pop();
        if (!validExtensions.includes(ext)) {
            return { valid: false, error: `Invalid file type. Allowed: ${validExtensions.join(', ')}` };
        }
        return { valid: true, ext };
    },

    validateFileSize(file, maxMB = 50) {
        const maxSize = maxMB * 1024 * 1024;
        if (file.size > maxSize) {
            return { valid: false, error: `File too large. Max: ${maxMB}MB` };
        }
        return { valid: true };
    },

    safeJsonParse(text) {
        try { return JSON.parse(text); }
        catch (e) { console.error('JSON parse error:', e); return null; }
    },

    validateContentLength(text, maxWords = 25000) {
        const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
        if (wordCount > maxWords) {
            return { valid: false, error: `Content exceeds ${maxWords} words limit` };
        }
        return { valid: true, wordCount };
    }
};

/**
 * Safe data access helpers
 */
export function safeGet(obj, path, fallback = '') {
    try {
        const keys = path.split('.');
        let result = obj;
        for (const key of keys) {
            if (result === null || result === undefined) return fallback;
            result = result[key];
        }
        return result === undefined || result === null ? fallback : result;
    } catch { return fallback; }
}

export function safeNumber(value, fallback = 0) {
    const num = parseFloat(value);
    return isNaN(num) ? fallback : num;
}

export function safeString(value, fallback = '') {
    return value === null || value === undefined ? fallback : String(value);
}

/**
 * Core API methods
 */
export const API = {
    async checkStatus() {
        try {
            const response = await fetch(`${API_BASE}/status`);
            if (response.ok) {
                const data = await response.json();
                console.log('✅ Server Status:', data);
                return data;
            }
        } catch (e) {
            console.warn('⚠️ Server not running');
        }
        return null;
    },

    async uploadFile(file) {
        const typeCheck = SecurityHelpers.validateFileType(file);
        if (!typeCheck.valid) throw new Error(typeCheck.error);

        const sizeCheck = SecurityHelpers.validateFileSize(file);
        if (!sizeCheck.valid) throw new Error(sizeCheck.error);

        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${API_BASE}/upload`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    async analyze(content) {
        const lengthCheck = SecurityHelpers.validateContentLength(content);
        if (!lengthCheck.valid) throw new Error(lengthCheck.error);

        const response = await fetch(`${API_BASE}/analyze`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content })
        });

        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    async humanizeAuto(content, maxLoops = 100) {
        const response = await fetch(`${API_BASE}/humanize-auto`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, max_loops: maxLoops })
        });

        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    /**
     * Server-Sent Events for real-time progress
     * @param {string} endpoint - API endpoint
     * @param {Object} payload - Request body
     * @param {Object} callbacks - { onProgress, onComplete, onError, onStopped }
     */
    streamReduceBoth(content, maxLoops = 100, callbacks = {}) {
        const { onProgress, onComplete, onError, onStopped } = callbacks;

        return new Promise((resolve, reject) => {
            const eventSource = new EventSource(
                `${API_BASE}/reduce-both-sse?content=${encodeURIComponent(content)}&max_loops=${maxLoops}`
            );

            eventSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);

                    switch (data.event) {
                        case 'progress':
                            onProgress?.(data);
                            break;
                        case 'complete':
                            onComplete?.(data);
                            eventSource.close();
                            resolve(data);
                            break;
                        case 'stopped':
                            onStopped?.(data);
                            eventSource.close();
                            resolve(data);
                            break;
                        case 'final':
                            onComplete?.(data);
                            eventSource.close();
                            resolve(data);
                            break;
                        case 'error':
                            onError?.(data);
                            eventSource.close();
                            reject(new Error(data.message || 'Stream error'));
                            break;
                    }
                } catch (e) {
                    console.warn('SSE parse error:', e);
                }
            };

            eventSource.onerror = (error) => {
                console.error('SSE connection error:', error);
                onError?.({ event: 'error', message: 'Connection lost' });
                eventSource.close();
                reject(new Error('SSE connection failed'));
            };

            // Timeout after 10 minutes
            setTimeout(() => {
                eventSource.close();
                reject(new Error('SSE timeout'));
            }, 600000);
        });
    },

    async fixGrammar(content, maxLoops = 10) {
        const response = await fetch(`${API_BASE}/fix-grammar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, max_loops: maxLoops })
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    async improveReadability(content, maxLoops = 10) {
        const response = await fetch(`${API_BASE}/improve-readability`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, max_loops: maxLoops })
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    async optimizeSEO(content) {
        const response = await fetch(`${API_BASE}/optimize-seo`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content })
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    async processFileKeepStyle(file) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${API_BASE}/process-file-keep-style`, {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    },

    getDownloadUrl(jobId, fileName) {
        return `${API_BASE}/download-processed/${jobId}/${fileName}`;
    }
};