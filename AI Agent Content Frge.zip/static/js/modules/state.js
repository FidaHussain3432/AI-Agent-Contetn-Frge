// ================================================
// MODULES/STATE.JS - Global State Management
// V6.0-PHASE6 - Alpine.js Store Pattern
// ================================================

import { SecurityHelpers } from './api.js';

/**
 * Initialize Alpine.js store for global state management
 * This replaces the old global STATE object
 */
export function initStateStore() {
    if (typeof Alpine === 'undefined') {
        console.error('❌ Alpine.js not loaded!');
        return;
    }

    Alpine.store('appState', {
        // Content State
        content: '',
        originalContent: '',
        humanizedContent: '',
        fileName: '',
        fileSize: 0,

        // UI State
        isAnalyzing: false,
        isProcessing: false,
        isHumanized: false,
        showResults: false,
        showLoading: false,
        loadingProgress: 0,
        loadingLabel: 'Initializing...',

        // Results
        results: null,
        analysisResults: null,
        autoHistory: [],
        usedTracker: {},

        // Theme
        theme: 'dark',
        scrolled: false,
        mobileOpen: false,

        // Feature Focus
        featureFocus: null,

        // Format Upload
        formatFile: null,
        formatType: null,

        // Reduce Status
        reduceStatus: {
            show: false,
            status: '',
            loop: 0,
            ai: 0,
            plagiarism: 0,
            grammar: 0
        },

        // Word Count
        get wordCount() {
            return this.content.trim() ? this.content.trim().split(/\s+/).length : 0;
        },

        get isOverLimit() {
            return this.wordCount > 20000;
        },

        get canAnalyze() {
            return this.content.trim().length > 0 && !this.isAnalyzing && this.wordCount <= 25000;
        },

        get hasResults() {
            return this.results !== null;
        },

        // Actions
        setContent(value) {
            this.content = value;
            this.saveToLocal();
        },

        clearContent() {
            this.content = '';
            this.originalContent = '';
            this.humanizedContent = '';
            this.isHumanized = false;
            this.showResults = false;
            this.results = null;
            this.analysisResults = null;
            this.autoHistory = [];
            this.usedTracker = {};
            this.formatFile = null;
            this.formatType = null;
            this.reduceStatus = { show: false, status: '', loop: 0, ai: 0, plagiarism: 0, grammar: 0 };
            localStorage.removeItem('contentpro_content');
        },

        saveToLocal() {
            try {
                localStorage.setItem('contentpro_content', this.content);
            } catch (e) {
                console.warn('LocalStorage full');
            }
        },

        loadFromLocal() {
            try {
                const saved = localStorage.getItem('contentpro_content');
                if (saved) this.content = saved;
            } catch (e) {
                console.warn('LocalStorage error');
            }
        },

        setResults(data) {
            this.results = data;
            this.analysisResults = data;
            this.showResults = true;
        },

        setLoading(show, progress = 0, label = '') {
            this.showLoading = show;
            this.loadingProgress = progress;
            this.loadingLabel = label;
        },

        setTheme(theme) {
            this.theme = theme;
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
        },

        toggleTheme() {
            this.setTheme(this.theme === 'dark' ? 'light' : 'dark');
        },

        initTheme() {
            const saved = localStorage.getItem('theme') || 'dark';
            this.setTheme(saved);
        },

        setFeatureFocus(id) {
            const features = [
                { id: 'plagiarism', title: 'Plagiarism Detection', subtitle: 'Check content originality against web sources.', icon: 'fa-copy', iconClass: 'plagiarism', badge: 'Phase 5', description: 'Semantic + Web Search' },
                { id: 'ai', title: 'AI Detection', subtitle: 'Detect AI-generated content with ensemble scoring.', icon: 'fa-robot', iconClass: 'ai', badge: 'Phase 4', description: 'RoBERTa + Perplexity' },
                { id: 'humanize', title: 'Auto Humanize', subtitle: 'Transform AI content to natural human writing.', icon: 'fa-user-edit', iconClass: 'human', badge: 'Phase 3', description: 'Context-aware rewriting' },
                { id: 'grammar', title: 'Grammar Check', subtitle: 'Fix grammar, spelling, and style issues.', icon: 'fa-spell-check', iconClass: 'grammar', badge: 'Ready', description: 'Advanced NLP' },
                { id: 'readability', title: 'Readability', subtitle: 'Flesch & Fog index analysis.', icon: 'fa-book-open', iconClass: 'readability', badge: 'Ready', description: 'Score & Suggestions' },
                { id: 'sentiment', title: 'Sentiment', subtitle: 'Analyze emotional tone of content.', icon: 'fa-smile', iconClass: 'sentiment', badge: 'Ready', description: 'Positive/Neutral/Negative' },
                { id: 'seo', title: 'SEO Keywords', subtitle: 'Extract and optimize keywords.', icon: 'fa-search', iconClass: 'seo', badge: 'Ready', description: 'Density Analysis' },
                { id: 'export', title: 'Export Reports', subtitle: 'Download PDF & TXT reports.', icon: 'fa-download', iconClass: 'export', badge: 'Ready', description: 'Formatted Output' }
            ];
            this.featureFocus = features.find(f => f.id === id) || null;
        },

        get features() {
            return [
                { id: 'plagiarism', title: 'Plagiarism Detection', description: 'Semantic + Web Search integration for deep originality checks.', icon: 'fa-copy', iconClass: 'plagiarism', badge: 'Phase 5' },
                { id: 'ai', title: 'AI Detection', description: 'Ensemble scoring with RoBERTa + Perplexity + Confidence intervals.', icon: 'fa-robot', iconClass: 'ai', badge: 'Phase 4' },
                { id: 'humanize', title: 'Auto Humanize', description: 'Context-aware rewriting with formatting preservation.', icon: 'fa-user-edit', iconClass: 'human', badge: 'Phase 3' },
                { id: 'grammar', title: 'Grammar Check', description: 'Advanced NLP-based grammar and style correction.', icon: 'fa-spell-check', iconClass: 'grammar', badge: 'Ready' },
                { id: 'readability', title: 'Readability', description: 'Flesch & Fog index with improvement suggestions.', icon: 'fa-book-open', iconClass: 'readability', badge: 'Ready' },
                { id: 'sentiment', title: 'Sentiment', description: 'Emotional tone analysis: Positive, Neutral, Negative.', icon: 'fa-smile', iconClass: 'sentiment', badge: 'Ready' },
                { id: 'seo', title: 'SEO Keywords', description: 'Keyword extraction and density optimization.', icon: 'fa-search', iconClass: 'seo', badge: 'Ready' },
                { id: 'export', title: 'Export Reports', description: 'Download formatted PDF & TXT analysis reports.', icon: 'fa-download', iconClass: 'export', badge: 'Ready' }
            ];
        }
    });
}

/**
 * Legacy STATE object for backward compatibility during migration
 * Delegates to Alpine store when available
 */
export const STATE = new Proxy({}, {
    get(target, prop) {
        const store = Alpine?.store?.('appState');
        if (store && prop in store) return store[prop];
        return target[prop];
    },
    set(target, prop, value) {
        const store = Alpine?.store?.('appState');
        if (store && prop in store) store[prop] = value;
        else target[prop] = value;
        return true;
    }
});