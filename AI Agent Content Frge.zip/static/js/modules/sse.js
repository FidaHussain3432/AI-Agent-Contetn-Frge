// ================================================
// MODULES/SSE.JS - Server-Sent Events Handler
// V6.0-PHASE6 - Real-time Progress Streaming
// ================================================

import { Toast, Popup } from './ui.js';
import { API } from './api.js';

/**
 * SSE Manager - handles real-time progress updates
 */
export const SSEManager = {
    eventSource: null,
    isConnected: false,
    reconnectAttempts: 0,
    maxReconnectAttempts: 3,

    /**
     * Connect to SSE endpoint for reduce-both streaming
     */
    connectReduceBoth(content, maxLoops = 100, callbacks = {}) {
        const { onProgress, onComplete, onError, onStopped } = callbacks;

        return new Promise((resolve, reject) => {
            // Close existing connection
            this.disconnect();

            const params = new URLSearchParams({
                content: content,
                max_loops: String(maxLoops)
            });

            const url = `${window.location.origin}/api/reduce-both-sse?${params.toString()}`;

            this.eventSource = new EventSource(url);
            this.isConnected = true;
            this.reconnectAttempts = 0;

            this.eventSource.onopen = () => {
                console.log('✅ SSE Connected');
                this.isConnected = true;
            };

            this.eventSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleEvent(data, onProgress, onComplete, onStopped, resolve);
                } catch (e) {
                    console.warn('SSE parse error:', e);
                }
            };

            this.eventSource.onerror = (error) => {
                console.error('SSE Error:', error);
                this.isConnected = false;

                if (this.reconnectAttempts < this.maxReconnectAttempts) {
                    this.reconnectAttempts++;
                    console.log(`🔄 SSE Reconnecting... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
                    setTimeout(() => {
                        this.connectReduceBoth(content, maxLoops, callbacks);
                    }, 2000 * this.reconnectAttempts);
                } else {
                    onError?.({ event: 'error', message: 'Connection lost after retries' });
                    this.disconnect();
                    reject(new Error('SSE connection failed'));
                }
            };

            // Timeout after 10 minutes
            setTimeout(() => {
                if (this.isConnected) {
                    this.disconnect();
                    reject(new Error('SSE timeout'));
                }
            }, 600000);
        });
    },

    handleEvent(data, onProgress, onComplete, onStopped, resolve) {
        switch (data.event) {
            case 'progress':
                onProgress?.(data);
                break;
            case 'complete':
                onComplete?.(data);
                this.disconnect();
                resolve(data);
                break;
            case 'stopped':
                onStopped?.(data);
                this.disconnect();
                resolve(data);
                break;
            case 'final':
                onComplete?.(data);
                this.disconnect();
                resolve(data);
                break;
            case 'error':
                this.disconnect();
                Toast.error(data.message || 'Stream error occurred');
                break;
        }
    },

    disconnect() {
        if (this.eventSource) {
            this.eventSource.close();
            this.eventSource = null;
        }
        this.isConnected = false;
    },

    /**
     * Update Alpine store with progress data
     */
    updateStoreProgress(data) {
        const store = Alpine?.store?.('appState');
        if (!store) return;

        store.reduceStatus = {
            show: true,
            status: `Processing... Loop ${data.loop}`,
            loop: data.loop,
            ai: data.ai_score || 0,
            plagiarism: data.plagiarism || 0,
            grammar: data.grammar || 0
        };
    },

    /**
     * Update Alpine store on completion
     */
    updateStoreComplete(data) {
        const store = Alpine?.store?.('appState');
        if (!store) return;

        store.reduceStatus = {
            show: true,
            status: data.ai_score <= 5 && data.plagiarism <= 5 ? 'Complete! Targets achieved!' : 'Stopped',
            loop: data.loop || 0,
            ai: data.ai_score || 0,
            plagiarism: data.plagiarism || 0,
            grammar: data.grammar || 0
        };

        if (data.content) {
            store.humanizedContent = data.content;
            store.isHumanized = true;
            store.content = data.content;
        }
    }
};

/**
 * Legacy stream handler for fetch-based streaming (fallback)
 */
export async function streamReduceBothLegacy(content, callbacks = {}) {
    const { onProgress, onComplete, onError } = callbacks;

    try {
        const response = await fetch(`${window.location.origin}/api/reduce-both-stream`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, max_loops: 100 })
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n\n');
            buffer = lines.pop();

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.event === 'progress') onProgress?.(data);
                        else if (data.event === 'complete') { onComplete?.(data); return data; }
                        else if (data.event === 'final') { onComplete?.(data); return data; }
                        else if (data.event === 'stopped') { onComplete?.(data); return data; }
                    } catch (e) {
                        console.warn('Stream parse error:', e);
                    }
                }
            }
        }
    } catch (error) {
        onError?.(error);
        throw error;
    }
}