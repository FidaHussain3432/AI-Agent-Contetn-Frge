# -*- coding: utf-8 -*-
# ============================================================
# ROUTES/ANALYZE.PY - Analysis API Endpoints
# V6.0-PHASE5 - Plagiarism Source Attribution + Multilingual Support
# ============================================================

import math
import re
import json
from flask import Blueprint, request, jsonify

from models.database import db, AnalysisHistory, PlagiarismSource
from services.ai_detector import detect_ai_content
from services.plagiarism import check_plagiarism
from services.grammar import get_grammar_errors
from services.readability import get_readability
from services.sentiment import get_sentiment
from services.seo import get_seo_analysis
from utils.security import InputSanitizer
from utils.logging_config import app_logger, security_logger
from config import Config
from collections import Counter

analyze_bp = Blueprint('analyze', __name__, url_prefix='/api')


def get_word_stats(text):
    """Calculate word statistics."""
    words = text.split()
    chars = len(text)
    sentences = len(re.findall(r'[.!?]+', text))
    paragraphs = len([p for p in text.split('\n\n') if p.strip()])
    avg_word_len = sum(len(w) for w in words) / len(words) if words else 0
    reading_time = max(1, len(words) / 200)

    return {
        'word_count': len(words),
        'char_count': chars,
        'sentence_count': max(1, sentences),
        'paragraph_count': max(1, paragraphs),
        'avg_word_length': round(avg_word_len, 1),
        'reading_time': math.ceil(reading_time),
    }


@analyze_bp.route('/analyze', methods=['POST'])
def analyze_content():
    """
    Analyze content and return all metrics.
    PHASE 5: Plagiarism sources saved to database with attribution.
    """
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        enable_web_search = data.get('enable_web_search', True) if isinstance(data, dict) else True

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        word_count = len(content.split())
        if word_count > Config.SECURITY.MAX_TEXT_LENGTH:
            security_logger.warning(f"Content exceeds limit: {word_count} words")
            return jsonify({'error': f'Content exceeds {Config.SECURITY.MAX_TEXT_LENGTH} words limit'}), 400

        app_logger.info(f"Analysis started: {word_count} words")

        # Run all analyses
        ai_detection = detect_ai_content(content)
        plagiarism = check_plagiarism(content, enable_web_search=enable_web_search)

        results = {
            'word_stats': get_word_stats(content),
            'readability': get_readability(content),
            'sentiment': get_sentiment(content),
            'seo': get_seo_analysis(content),
            'grammar': get_grammar_errors(content),
            'plagiarism': plagiarism,
            'ai_detection': ai_detection,
        }

        # Save to database with Phase 5 plagiarism sources
        try:
            history = AnalysisHistory(
                content_preview=content[:500],
                word_count=word_count,
                char_count=results['word_stats']['char_count'],
                plagiarism_score=results['plagiarism']['score'],
                plagiarism_sources=json.dumps(results['plagiarism'].get('sources', [])[:5]),
                plagiarism_language=results['plagiarism'].get('language', 'en'),
                plagiarism_engine=results['plagiarism'].get('engine', 'local'),
                ai_score=results['ai_detection']['ai_score'],
                human_score=results['ai_detection']['human_score'],
                grammar_score=results['grammar']['score'],
                flesch_score=results['readability']['flesch_score'],
                fog_score=results['readability']['fog_score'],
                sentiment_category=results['sentiment']['category'],
                top_keyword=results['seo']['top_keyword']
            )
            db.session.add(history)
            db.session.flush()  # Get history.id without committing

            # === PHASE 5: Save individual plagiarism sources ===
            for source in results['plagiarism'].get('sources', [])[:10]:
                plagiarism_source = PlagiarismSource(
                    analysis_id=history.id,
                    matched_text=source.get('matched_text', source.get('sentence', ''))[:500],
                    source_title=source.get('source_title', 'Unknown')[:500],
                    source_url=source.get('source_url', '')[:1000],
                    match_type=source.get('match_type', 'unknown'),
                    similarity_score=source.get('similarity', 0.0)
                )
                db.session.add(plagiarism_source)

            db.session.commit()
            app_logger.info(f"Analysis saved with {len(results['plagiarism'].get('sources', []))} plagiarism sources")

        except Exception as e:
            db.session.rollback()
            app_logger.warning(f"Failed to save history: {e}")

        app_logger.info("Analysis completed successfully")
        return jsonify({'success': True, 'results': results})

    except Exception as e:
        app_logger.error(f"Analysis error: {str(e)}")
        return jsonify({'error': 'Analysis processing failed'}), 500


# ============================================================
# PHASE 5: NEW PLAGIARISM-SPECIFIC ENDPOINTS
# ============================================================

@analyze_bp.route('/analyze/plagiarism-detailed', methods=['POST'])
def analyze_plagiarism_detailed():
    """
    Detailed plagiarism analysis with full source attribution.

    Returns:
    - All matched sources with URLs
    - Semantic similarity scores
    - Language detection
    - Processing breakdown (local/web/semantic)
    """
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        enable_web_search = data.get('enable_web_search', True) if isinstance(data, dict) else True

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        word_count = len(content.split())
        if word_count > Config.SECURITY.MAX_TEXT_LENGTH:
            return jsonify({'error': f'Content exceeds {Config.SECURITY.MAX_TEXT_LENGTH} words limit'}), 400

        result = check_plagiarism(content, enable_web_search=enable_web_search)

        # Add interpretation
        interpretation = _get_plagiarism_interpretation(result)
        result['interpretation'] = interpretation

        return jsonify({
            'success': True,
            'plagiarism': result,
            'word_count': word_count,
            'language': result.get('language', 'en')
        })

    except Exception as e:
        app_logger.error(f"Detailed plagiarism analysis error: {str(e)}")
        return jsonify({'error': 'Analysis failed'}), 500


@analyze_bp.route('/analyze/plagiarism-fast', methods=['POST'])
def analyze_plagiarism_fast():
    """
    Fast plagiarism check without web search.
    Use for bulk processing or offline mode.
    """
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        from services.plagiarism import check_plagiarism_fast
        result = check_plagiarism_fast(content)

        return jsonify({
            'success': True,
            'plagiarism': result,
            'mode': 'fast (no web search)'
        })

    except Exception as e:
        app_logger.error(f"Fast plagiarism error: {str(e)}")
        return jsonify({'error': 'Analysis failed'}), 500


def _get_plagiarism_interpretation(result: dict) -> str:
    """Generate human-readable interpretation of plagiarism results."""
    score = result.get('score', 0)
    status = result.get('status', 'Low')
    sources = result.get('sources', [])
    language = result.get('language', 'en')
    engine = result.get('engine', 'local')

    parts = []

    # Main verdict
    if status == 'High':
        parts.append(f"⚠️ High plagiarism risk detected ({score}%)")
    elif status == 'Medium':
        parts.append(f"⚡ Moderate plagiarism risk ({score}%)")
    else:
        parts.append(f"✅ Low plagiarism risk ({score}%)")

    # Sources
    if sources:
        parts.append(f"Found {len(sources)} potential source(s).")

        exact_matches = sum(1 for s in sources if s.get('match_type') == 'exact_phrase')
        semantic_matches = sum(1 for s in sources if s.get('match_type') == 'semantic_paraphrase')

        if exact_matches:
            parts.append(f"{exact_matches} exact phrase match(es).")
        if semantic_matches:
            parts.append(f"{semantic_matches} paraphrased content match(es).")

    # Language
    lang_names = {'en': 'English', 'ur': 'Urdu', 'hi': 'Hindi', 'ar': 'Arabic', 'zh': 'Chinese'}
    detected_lang = lang_names.get(language, language.upper())
    parts.append(f"Detected language: {detected_lang}.")

    # Engine info
    if 'web' in engine:
        parts.append("Web search was used for verification.")

    return " ".join(parts)


# ============================================================
# EXISTING ENDPOINTS (unchanged)
# ============================================================

@analyze_bp.route('/fix-grammar', methods=['POST'])
def fix_grammar():
    """Fix grammar errors automatically."""
    try:
        from services.grammar import fix_common_grammar

        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', 10) if isinstance(data, dict) else 10

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        current_content = content
        history = []
        loop_count = 0

        while loop_count < max_loops:
            loop_count += 1
            current_score = get_grammar_errors(current_content)['score']
            if current_score >= 95:
                history.append({'loop': loop_count, 'score': current_score, 'status': '✅ Complete!'})
                break
            current_content = fix_common_grammar(current_content)
            new_score = get_grammar_errors(current_content)['score']
            history.append({'loop': loop_count, 'score': new_score, 'status': '🔄 Fixing...'})

        final_score = get_grammar_errors(current_content)['score']

        return jsonify({
            'success': True,
            'fixed_content': current_content,
            'new_score': final_score,
            'history': history,
            'total_loops': loop_count,
            'status': '✅ Complete!' if final_score >= 95 else '⚠️ Needs more work'
        })

    except Exception as e:
        app_logger.error(f"Fix grammar error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500


@analyze_bp.route('/improve-readability', methods=['POST'])
def improve_readability():
    """Improve readability scores."""
    try:
        from services.readability import split_long_sentence, replace_complex_words

        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', 10) if isinstance(data, dict) else 10

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        current_content = content
        history = []
        loop_count = 0
        best_flesch = 0
        best_content = current_content

        while loop_count < max_loops:
            loop_count += 1
            current = get_readability(current_content)
            flesch = current.get('flesch_score', 0)
            fog = current.get('fog_score', 0)

            if flesch > best_flesch:
                best_flesch = flesch
                best_content = current_content

            if flesch >= 70:
                history.append({'loop': loop_count, 'flesch': flesch, 'fog': fog, 'status': '✅ Complete!'})
                break

            current_content = split_long_sentence(current_content)
            current_content = replace_complex_words(current_content)
            history.append({'loop': loop_count, 'flesch': flesch, 'fog': fog, 'status': '🔄 Improving...'})

        final = get_readability(best_content)

        return jsonify({
            'success': True,
            'improved_content': best_content,
            'new_flesch': final.get('flesch_score', 0),
            'new_fog': final.get('fog_score', 0),
            'history': history,
            'total_loops': loop_count,
            'status': '✅ Complete!' if final.get('flesch_score', 0) >= 70 else '⚠️ Needs more work'
        })

    except Exception as e:
        app_logger.error(f"Improve readability error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500


@analyze_bp.route('/optimize-seo', methods=['POST'])
def optimize_seo():
    """Optimize SEO suggestions."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        seo_data = get_seo_analysis(content)
        keywords = seo_data.get('keywords', [])
        top_keyword = seo_data.get('top_keyword', 'None')
        suggestions = []

        if keywords:
            for kw in keywords[:3]:
                density = kw.get('density', 0)
                word = kw.get('word', '')
                if density < 2:
                    suggestions.append(f"Increase usage of '{word}' (currently {density}%)")
                elif density > 8:
                    suggestions.append(f"Reduce usage of '{word}' (currently {density}%) - risk of keyword stuffing")

        if not keywords or len(keywords) < 3:
            words = re.sub(r'[^\w\s]', '', content.lower()).split()
            stopwords = set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'])
            filtered = [w for w in words if w not in stopwords and len(w) > 3]
            if filtered:
                freq = Counter(filtered)
                potential = freq.most_common(5)
                for word, count in potential:
                    suggestions.append(f"Consider adding more context around '{word}' (appears {count} times)")

        if not suggestions:
            suggestions.append("Your SEO looks good! Maintain current keyword strategy.")

        return jsonify({
            'success': True,
            'optimized_content': content,
            'top_keyword': top_keyword,
            'suggestions': suggestions,
            'keyword_count': len(keywords)
        })

    except Exception as e:
        app_logger.error(f"Optimize SEO error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500


# ============================================================
# PHASE 4: AI DETECTION DETAILED ENDPOINT (retained)
# ============================================================

@analyze_bp.route('/analyze/ai-detailed', methods=['POST'])
def analyze_ai_detailed():
    """Detailed AI detection with full model breakdown."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        word_count = len(content.split())
        if word_count > Config.SECURITY.MAX_TEXT_LENGTH:
            return jsonify({'error': f'Content exceeds {Config.SECURITY.MAX_TEXT_LENGTH} words limit'}), 400

        result = detect_ai_content(content)
        interpretation = _get_ai_interpretation(result)
        result['interpretation'] = interpretation

        return jsonify({
            'success': True,
            'ai_detection': result,
            'word_count': word_count
        })

    except Exception as e:
        app_logger.error(f"Detailed AI analysis error: {str(e)}")
        return jsonify({'error': 'Analysis failed'}), 500


def _get_ai_interpretation(result: dict) -> str:
    """Generate human-readable interpretation of AI detection results."""
    ai_score = result.get('ai_score', 50)
    confidence = result.get('confidence', 0)
    uncertainty = result.get('uncertainty_band', [0, 100])
    status = result.get('status', 'Unknown')
    disagreement = result.get('disagreement_score', 0)

    parts = []

    if status == 'AI':
        parts.append(f"⚠️ AI-generated content detected ({ai_score}% probability)")
    elif status == 'Human':
        parts.append(f"✅ Likely human-written ({100-ai_score}% human probability)")
    elif status == 'Likely AI':
        parts.append(f"⚡ Possibly AI-generated ({ai_score}% probability)")
    else:
        parts.append(f"🤔 Likely human-written ({100-ai_score}% probability)")

    if confidence >= 0.8:
        parts.append("High confidence in this assessment.")
    elif confidence >= 0.5:
        parts.append("Moderate confidence — some uncertainty remains.")
    else:
        parts.append("Low confidence — results are inconclusive.")

    parts.append(f"Score range: {uncertainty[0]}% - {uncertainty[1]}%")

    if disagreement > 0.3:
        parts.append("⚠️ Models disagree significantly — text may be partially AI-edited.")

    breakdown = result.get('model_breakdown', [])
    if breakdown:
        model_names = [b.get('model', 'unknown') for b in breakdown]
        parts.append(f"Models used: {', '.join(model_names)}")

    return " ".join(parts)