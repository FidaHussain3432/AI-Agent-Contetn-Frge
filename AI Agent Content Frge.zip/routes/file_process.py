# ============================================================
# ROUTES/FILE_PROCESS.PY - File Upload & Processing Endpoints
# V6.0-PHASE2 - Blueprint Version
# ============================================================

import os
import re
import uuid
from flask import Blueprint, request, jsonify, send_from_directory

from config import Config
from models.database import db, FileUpload
from services.file_handler import (
    extract_text_from_txt,
    extract_text_from_docx,
    extract_text_from_pdf,
    process_docx_structure,
    process_pdf_structure,
    DOCX_SUPPORT,
    PDFPLUMBER_SUPPORT,
    PYMUPDF_SUPPORT
)
from services.humanizer import auto_humanize_pipeline
from utils.security import InputSanitizer, PathValidator
from utils.logging_config import app_logger, security_logger

file_bp = Blueprint('file', __name__, url_prefix='/api')


@file_bp.route('/upload', methods=['POST'])
def upload_file():
    """Upload file, validate security, extract text and return."""
    try:
        if 'file' not in request.files:
            security_logger.warning("Upload attempt with no file")
            return jsonify({'error': 'No file uploaded'}), 400

        file = request.files['file']
        if file.filename == '':
            security_logger.warning("Upload attempt with empty filename")
            return jsonify({'error': 'No file selected'}), 400

        # Sanitize filename
        original_filename = InputSanitizer.sanitize_filename(file.filename)
        if not original_filename:
            security_logger.warning("Filename sanitization failed")
            return jsonify({'error': 'Invalid filename'}), 400

        # Validate extension
        if not InputSanitizer.validate_extension(original_filename):
            security_logger.warning(f"Invalid extension: {original_filename}")
            return jsonify({'error': 'Unsupported file type'}), 400

        ext = original_filename.rsplit('.', 1)[1].lower()

        # Generate secure filename
        secure_name = InputSanitizer.generate_secure_filename(original_filename)
        upload_folder = Config.UPLOAD_FOLDER
        os.makedirs(upload_folder, exist_ok=True)
        file_path = os.path.join(upload_folder, secure_name)

        # Save file
        file.save(file_path)
        app_logger.info(f"File saved: {secure_name} (original: {original_filename})")

        # Validate MIME type
        if not InputSanitizer.validate_mime_type(file_path, ext):
            os.remove(file_path)
            security_logger.warning(f"MIME type mismatch for {secure_name}")
            return jsonify({'error': 'File content does not match extension'}), 400

        # Extract text based on file type
        if ext == 'txt':
            text = extract_text_from_txt(file_path)
        elif ext == 'docx':
            text = extract_text_from_docx(file_path) if DOCX_SUPPORT else "DOCX support not available"
        else:  # pdf
            text = extract_text_from_pdf(file_path)

        # Clean up uploaded file
        try:
            os.remove(file_path)
        except Exception as e:
            app_logger.warning(f"Failed to remove upload {secure_name}: {e}")

        # Validate extracted content
        if text and len(text.strip()) > 0:
            safe_text = InputSanitizer.sanitize_text_content(text)
            word_count = len(safe_text.split())
            app_logger.info(f"Text extracted successfully: {word_count} words")

            return jsonify({
                'success': True,
                'content': safe_text,
                'word_count': word_count,
                'file_name': original_filename,
                'file_type': ext
            })
        else:
            app_logger.warning("No text extracted from file")
            return jsonify({'error': 'Could not extract text from file.'}), 400

    except Exception as e:
        app_logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Upload processing failed'}), 500


@file_bp.route('/process-file-keep-style', methods=['POST'])
def process_file_keep_style():
    """Humanize DOCX/PDF while preserving original formatting."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        original_filename = InputSanitizer.sanitize_filename(file.filename)
        if not original_filename:
            return jsonify({'error': 'Invalid filename'}), 400

        ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else ''

        if ext not in ('docx', 'pdf'):
            return jsonify({'error': 'Style-preserving mode supports .docx and .pdf only.'}), 400

        # Generate secure filename and job ID
        secure_name = InputSanitizer.generate_secure_filename(original_filename)
        job_id = uuid.uuid4().hex

        upload_folder = Config.UPLOAD_FOLDER
        processed_folder = Config.PROCESSED_FOLDER
        os.makedirs(upload_folder, exist_ok=True)
        os.makedirs(processed_folder, exist_ok=True)

        input_path = os.path.join(upload_folder, f"{job_id}_{secure_name}")
        output_name = f"{os.path.splitext(original_filename)[0]}_humanized.{ext}"
        output_path = os.path.join(processed_folder, f"{job_id}_{output_name}")

        file.save(input_path)
        app_logger.info(f"Style-preserving upload: {secure_name} (job: {job_id})")

        # Process based on file type
        if ext == 'docx':
            if not DOCX_SUPPORT:
                os.remove(input_path)
                return jsonify({'error': 'python-docx not installed'}), 500
            stats = process_docx_structure(
                input_path, output_path,
                humanize_func=auto_humanize_pipeline,
                max_loops_per_block=Config.APP.MAX_LOOPS_FILE_PROCESS,
                fast=False
            )
        else:  # pdf
            if not PYMUPDF_SUPPORT:
                os.remove(input_path)
                return jsonify({'error': 'PyMuPDF not installed'}), 500
            stats = process_pdf_structure(
                input_path, output_path,
                humanize_func=auto_humanize_pipeline,
                max_loops_per_block=8,
                fast=False
            )

        # Clean up input file
        try:
            os.remove(input_path)
        except Exception as e:
            app_logger.warning(f"Failed to remove input {input_path}: {e}")

        # Save to database
        try:
            file_record = FileUpload(
                job_id=job_id,
                original_filename=original_filename,
                secure_filename=secure_name,
                file_type=ext,
                file_size=os.path.getsize(output_path) if os.path.exists(output_path) else 0,
                status='completed',
                processed_filename=output_name
            )
            db.session.add(file_record)
            db.session.commit()
        except Exception as e:
            app_logger.warning(f"Failed to save file record: {e}")

        return jsonify({
            'success': True,
            'job_id': job_id,
            'download_name': output_name,
            'file_type': ext,
            'stats': stats,
            'note': 'Formatting preserved.'
        })

    except Exception as e:
        app_logger.error(f"Process file error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500


@file_bp.route('/download-processed/<job_id>/<path:filename>', methods=['GET'])
def download_processed(job_id, filename):
    """Securely download processed file with path traversal protection."""
    try:
        # Sanitize inputs
        safe_job_id = re.sub(r'[^a-f0-9]', '', job_id)[:32]
        safe_filename = InputSanitizer.sanitize_filename(filename)

        if not safe_job_id or not safe_filename:
            return jsonify({'error': 'Invalid parameters'}), 400

        stored_name = f"{safe_job_id}_{safe_filename}"
        processed_folder = Config.PROCESSED_FOLDER
        file_path = os.path.join(processed_folder, stored_name)

        # Security: ensure path is within processed folder
        if not PathValidator.is_safe_path(processed_folder, file_path):
            security_logger.warning(f"Path traversal attempt: {filename}")
            return jsonify({'error': 'Invalid file path'}), 403

        if not os.path.exists(file_path):
            return jsonify({'error': 'File not found'}), 404

        return send_from_directory(
            processed_folder,
            stored_name,
            as_attachment=True,
            download_name=safe_filename
        )

    except Exception as e:
        app_logger.error(f"Download error: {str(e)}")
        return jsonify({'error': 'Download failed'}), 500