# -*- coding: utf-8 -*-
# ============================================================
# ROUTES/STATUS.PY - Status & Health Check Endpoints
# V7.0-PHASE7 - Fixed for correct ai_detector variable names
# ============================================================

from flask import Blueprint, jsonify

from services.ai_detector import _roberta_detector, _roberta_loading
from services.plagiarism import _embedding_model, _multilingual_model
from utils.logging_config import app_logger

status_bp = Blueprint('status', __name__, url_prefix='/api')


@status_bp.route('/health', methods=['GET'])
def health_check():
    """Basic health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'service': 'content-analyzer',
        'version': '7.0-PHASE7'
    })


@status_bp.route('/status', methods=['GET'])
def system_status():
    """Detailed system status with model loading states."""
    app_logger.info("Status check requested")

    # Check AI model status
    ai_model_ready = _roberta_detector is not None
    ai_model_loading = _roberta_loading

    # Check embedding model status
    embedding_ready = _embedding_model is not None
    multilingual_ready = _multilingual_model is not None

    # Overall status
    models_ready = ai_model_ready and embedding_ready

    return jsonify({
        'success': True,
        'status': {
            'api': 'running',
            'ai_detection': {
                'model': 'roberta-base-openai-detector',
                'loaded': ai_model_ready,
                'loading': ai_model_loading,
                'status': 'ready' if ai_model_ready else 'loading' if ai_model_loading else 'unavailable'
            },
            'plagiarism': {
                'embedding_model': 'all-MiniLM-L6-v2',
                'loaded': embedding_ready,
                'multilingual_loaded': multilingual_ready,
                'status': 'ready' if embedding_ready else 'unavailable'
            },
            'overall': 'ready' if models_ready else 'degraded'
        }
    })


@status_bp.route('/ready', methods=['GET'])
def readiness_check():
    """Kubernetes-style readiness probe."""
    ai_ready = _roberta_detector is not None

    if ai_ready:
        return jsonify({'ready': True}), 200
    else:
        return jsonify({
            'ready': False,
            'reason': 'AI model still loading'
        }), 503


@status_bp.route('/metrics', methods=['GET'])
def metrics():
    """Basic metrics for monitoring."""
    return jsonify({
        'success': True,
        'metrics': {
            'ai_model_loaded': _roberta_detector is not None,
            'embedding_model_loaded': _embedding_model is not None,
            'phase': '7',
            'features': {
                'bert_wsd': True,
                'spacy_parsing': False,  # Python 3.14 compatible
                'bertscore': True,
                'smart_transitions': True,
                'web_search': True
            }
        }
    })