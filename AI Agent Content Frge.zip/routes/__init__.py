# ============================================================
# ROUTES/__INIT__.PY - Blueprint Registration
# V6.0-PHASE4 - Updated with all blueprints
# ============================================================

from .analyze import analyze_bp
from .humanize import humanize_bp
from .file_process import file_bp
from .status import status_bp

all_blueprints = [analyze_bp, humanize_bp, file_bp, status_bp]