# -*- coding: utf-8 -*-
# ============================================================
# ROUTES/HUMANIZE.PY - Humanization API Endpoints
# V6.0-PHASE6 - SSE + Stream Support
# ============================================================

import json
from flask import Blueprint, request, jsonify, Response, stream_with_context

from models.database import db, AnalysisHistory
from services.humanizer import auto_humanize_pipeline, apply_humanization, compute_document_similarity
from services.ai_detector import detect_ai_content
from services.plagiarism import check_plagiarism
from services.grammar import get_grammar_errors
from utils.security import InputSanitizer
from utils.logging_config import app_logger
from config import Config

humanize_bp = Blueprint('humanize', __name__, url_prefix='/api')


@humanize_bp.route('/humanize-auto', methods=['POST'])
def humanize_auto():
    """Auto-humanize content with full pipeline."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', Config.APP.MAX_LOOPS_DEFAULT) if isinstance(data, dict) else Config.APP.MAX_LOOPS_DEFAULT

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        app_logger.info(f"Auto-humanize started: {len(content.split())} words")

        result = auto_humanize_pipeline(content, max_loops=max_loops, fast=False)

        # Update database if analysis exists
        try:
            latest = AnalysisHistory.query.order_by(AnalysisHistory.id.desc()).first()
            if latest:
                latest.is_humanized = True
                latest.humanized_content_preview = result['content'][:500]
                latest.humanization_loops = result['loops']
                db.session.commit()
        except Exception as e:
            app_logger.warning(f"Failed to update history: {e}")

        app_logger.info(f"Auto-humanize completed: {result['loops']} loops")

        return jsonify({
            'success': True,
            'original_content': content[:500] + '...' if len(content) > 500 else content,
            'humanized_content': result['content'],
            'final_scores': {
                'ai_score': result['ai_score'],
                'plagiarism': result['plag_score'],
                'grammar': result['grammar_score'],
                'status': 'Complete!' if result['converged'] else 'Needs improvement'
            },
            'history': result['history'],
            'total_loops': result['loops'],
            'word_count': len(result['content'].split())
        })

    except Exception as e:
        app_logger.error(f"Humanize error: {str(e)}")
        return jsonify({'error': 'Humanization processing failed'}), 500


@humanize_bp.route('/reduce-both-stream', methods=['POST'])
def reduce_both_stream():
    """Stream humanization progress for real-time updates (legacy fetch-based)."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', Config.APP.MAX_LOOPS_DEFAULT) if isinstance(data, dict) else Config.APP.MAX_LOOPS_DEFAULT

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        app_logger.info(f"Reduce-both stream started: {len(content.split())} words")

        def generate():
            current_content = content
            used_tracker = {}
            loop_count = 0
            stall_count = 0
            best_content = current_content
            best_ai = detect_ai_content(current_content)['ai_score']
            best_plag = check_plagiarism(current_content)['score']
            initial_ai = best_ai
            initial_plag = best_plag
            original_content = content

            while loop_count < max_loops:
                loop_count += 1
                ai_score = detect_ai_content(current_content)['ai_score']
                plag_score = check_plagiarism(current_content)['score']
                grammar_score = get_grammar_errors(current_content)['score']

                yield f"data: {json.dumps({'event': 'progress', 'loop': loop_count, 'ai_score': ai_score, 'plagiarism': plag_score, 'grammar': grammar_score, 'status': 'processing'})}\n\n"

                if ai_score <= 5 and plag_score <= 5 and grammar_score >= 95:
                    best_content = current_content
                    best_ai = ai_score
                    best_plag = plag_score
                    yield f"data: {json.dumps({'event': 'complete', 'loop': loop_count, 'ai_score': ai_score, 'plagiarism': plag_score, 'grammar': grammar_score, 'status': 'complete'})}\n\n"
                    break

                previous_content = current_content
                if loop_count <= 20:
                    intensity = 'light'
                elif loop_count <= 50:
                    intensity = 'medium'
                else:
                    intensity = 'deep'

                current_content = apply_humanization(current_content, intensity, used_tracker)

                # Global similarity check
                global_sim = compute_document_similarity(original_content, current_content)
                if global_sim < Config.AI.SIMILARITY_THRESHOLD:
                    current_content = best_content
                    yield f"data: {json.dumps({'event': 'stopped', 'loop': loop_count, 'ai_score': best_ai, 'plagiarism': best_plag, 'grammar': grammar_score, 'status': 'stopped', 'reason': 'global similarity < 0.85'})}\n\n"
                    break

                new_ai = detect_ai_content(current_content)['ai_score']
                new_plag = check_plagiarism(current_content)['score']
                improved = (new_ai < best_ai) or (new_ai <= best_ai and new_plag <= best_plag)

                if improved:
                    best_content, best_ai, best_plag = current_content, new_ai, new_plag
                    stall_count = 0
                else:
                    stall_count += 1

                if current_content == previous_content or stall_count >= 6:
                    yield f"data: {json.dumps({'event': 'stopped', 'loop': loop_count, 'ai_score': best_ai, 'plagiarism': best_plag, 'grammar': grammar_score, 'status': 'stopped', 'reason': 'no further improvement'})}\n\n"
                    break

            final_ai = detect_ai_content(best_content)['ai_score']
            final_plag = check_plagiarism(best_content)['score']
            final_grammar = get_grammar_errors(best_content)['score']
            yield f"data: {json.dumps({'event': 'final', 'ai_score': final_ai, 'plagiarism': final_plag, 'grammar': final_grammar, 'content': best_content, 'initial_ai': initial_ai, 'initial_plag': initial_plag, 'loops': loop_count})}\n\n"

        return Response(stream_with_context(generate()), mimetype='text/event-stream')

    except Exception as e:
        app_logger.error(f"Reduce-both stream error: {str(e)}")
        return jsonify({'error': 'Stream processing failed'}), 500


@humanize_bp.route('/reduce-plagiarism', methods=['POST'])
def reduce_plagiarism():
    """Reduce plagiarism score."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', 50) if isinstance(data, dict) else 50

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        current_content = content
        history = []
        loop_count = 0
        used_tracker = {}
        stall_count = 0
        best_content = current_content
        best_score = check_plagiarism(current_content)['score']

        while loop_count < max_loops:
            loop_count += 1
            current_score = check_plagiarism(current_content)['score']
            if current_score <= 5:
                history.append({'loop': loop_count, 'score': current_score, 'status': 'Complete!'})
                best_content = current_content
                break

            previous_content = current_content
            current_content = apply_humanization(current_content, 'medium', used_tracker)
            new_score = check_plagiarism(current_content)['score']

            if new_score < best_score:
                best_score = new_score
                best_content = current_content
                stall_count = 0
            else:
                stall_count += 1

            history.append({'loop': loop_count, 'score': new_score, 'status': 'Reducing...'})

            if current_content == previous_content or stall_count >= 6:
                history.append({'loop': loop_count, 'score': best_score, 'status': 'Stopped'})
                current_content = best_content
                break

        final_score = check_plagiarism(current_content)['score']

        return jsonify({
            'success': True,
            'humanized_content': current_content,
            'new_score': final_score,
            'history': history,
            'total_loops': loop_count,
            'status': 'Complete!' if final_score <= 5 else 'Needs more work'
        })

    except Exception as e:
        app_logger.error(f"Reduce plagiarism error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500


@humanize_bp.route('/reduce-ai', methods=['POST'])
def reduce_ai():
    """Reduce AI detection score."""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data else ''
        max_loops = data.get('max_loops', 50) if isinstance(data, dict) else 50

        content = InputSanitizer.sanitize_text_content(content)

        if not content:
            return jsonify({'error': 'No content provided'}), 400

        current_content = content
        history = []
        loop_count = 0
        used_tracker = {}
        stall_count = 0
        best_ai_score = 100
        best_content = current_content

        while loop_count < max_loops:
            loop_count += 1
            current_ai = detect_ai_content(current_content)['ai_score']

            if current_ai < best_ai_score:
                best_ai_score = current_ai
                best_content = current_content
                stall_count = 0
            else:
                stall_count += 1

            if current_ai <= 5:
                history.append({'loop': loop_count, 'ai_score': current_ai, 'status': 'Complete!'})
                break

            if stall_count >= 6:
                history.append({'loop': loop_count, 'ai_score': best_ai_score, 'status': 'Stopped'})
                break

            if loop_count <= 20:
                intensity = 'light'
            elif loop_count <= 50:
                intensity = 'medium'
            else:
                intensity = 'deep'

            current_content = apply_humanization(current_content, intensity, used_tracker)
            history.append({'loop': loop_count, 'ai_score': current_ai, 'status': 'Reducing AI...'})

        final_ai = detect_ai_content(best_content)['ai_score']

        return jsonify({
            'success': True,
            'humanized_content': best_content,
            'new_score': final_ai,
            'history': history,
            'total_loops': loop_count,
            'status': 'Complete!' if final_ai <= 5 else 'Needs more work'
        })

    except Exception as e:
        app_logger.error(f"Reduce AI error: {str(e)}")
        return jsonify({'error': 'Processing failed'}), 500