# ============================================================
# MODELS/DATABASE.PY - SQLite Database Models
# V6.0-PHASE5 - Plagiarism Source Attribution Support
# ============================================================

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from config import Config

db = SQLAlchemy()


class AnalysisHistory(db.Model):
    """Store analysis results for history tracking."""
    __tablename__ = 'analysis_history'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    content_preview = db.Column(db.Text, nullable=False)
    word_count = db.Column(db.Integer)
    char_count = db.Column(db.Integer)

    # Scores
    plagiarism_score = db.Column(db.Float)
    ai_score = db.Column(db.Float)
    human_score = db.Column(db.Float)
    grammar_score = db.Column(db.Float)
    flesch_score = db.Column(db.Float)
    fog_score = db.Column(db.Float)
    sentiment_category = db.Column(db.String(20))
    top_keyword = db.Column(db.String(100))

    # === PHASE 5: Plagiarism Source Attribution ===
    plagiarism_sources = db.Column(db.Text)  # JSON string of sources
    plagiarism_language = db.Column(db.String(10))  # Detected language
    plagiarism_engine = db.Column(db.String(50))  # Which engine was used

    # Humanization results
    is_humanized = db.Column(db.Boolean, default=False)
    humanized_content_preview = db.Column(db.Text)
    humanization_loops = db.Column(db.Integer)

    # File info
    original_filename = db.Column(db.String(255))
    file_type = db.Column(db.String(10))

    def to_dict(self):
        """Convert to dictionary for API responses."""
        return {
            'id': self.id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'content_preview': self.content_preview,
            'word_count': self.word_count,
            'plagiarism_score': self.plagiarism_score,
            'plagiarism_sources': self.plagiarism_sources,
            'plagiarism_language': self.plagiarism_language,
            'ai_score': self.ai_score,
            'human_score': self.human_score,
            'grammar_score': self.grammar_score,
            'sentiment': self.sentiment_category,
            'is_humanized': self.is_humanized,
            'original_filename': self.original_filename
        }


class FileUpload(db.Model):
    """Track uploaded files and processing status."""
    __tablename__ = 'file_uploads'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    job_id = db.Column(db.String(64), unique=True, nullable=False)
    original_filename = db.Column(db.String(255))
    secure_filename = db.Column(db.String(255))
    file_type = db.Column(db.String(10))
    file_size = db.Column(db.Integer)
    status = db.Column(db.String(20), default='pending')
    processed_filename = db.Column(db.String(255))
    error_message = db.Column(db.Text)

    def to_dict(self):
        return {
            'id': self.id,
            'job_id': self.job_id,
            'original_filename': self.original_filename,
            'file_type': self.file_type,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


# === PHASE 5: New Model for Plagiarism Sources ===
class PlagiarismSource(db.Model):
    """Store individual plagiarism matches with source URLs."""
    __tablename__ = 'plagiarism_sources'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Link to analysis
    analysis_id = db.Column(db.Integer, db.ForeignKey('analysis_history.id'))

    # Match details
    matched_text = db.Column(db.Text)
    source_title = db.Column(db.String(500))
    source_url = db.Column(db.String(1000))
    match_type = db.Column(db.String(50))  # 'exact_phrase', 'semantic_paraphrase'
    similarity_score = db.Column(db.Float)

    def to_dict(self):
        return {
            'id': self.id,
            'matched_text': self.matched_text,
            'source_title': self.source_title,
            'source_url': self.source_url,
            'match_type': self.match_type,
            'similarity_score': self.similarity_score,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


def init_db(app):
    """Initialize database with Flask app."""
    app.config['SQLALCHEMY_DATABASE_URI'] = Config.DATABASE.DATABASE_URL
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = Config.DATABASE.TRACK_MODIFICATIONS
    db.init_app(app)
    with app.app_context():
        db.create_all()