# -*- coding: utf-8 -*-
# models/__init__.py
# V6.0-PHASE5 - Updated with PlagiarismSource
from .database import db, AnalysisHistory, FileUpload, PlagiarismSource, init_db

__all__ = ['db', 'AnalysisHistory', 'FileUpload', 'PlagiarismSource', 'init_db']