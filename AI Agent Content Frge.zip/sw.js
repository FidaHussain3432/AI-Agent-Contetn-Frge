// ================================================
// SW.JS - Service Worker for PWA
// V6.0-PHASE6 - Offline Cache & Background Sync
// ================================================

const CACHE_NAME = 'contentpro-v6-cache-v1';
const STATIC_ASSETS = [
    '/',
    '/templates/index.html',
    '/static/css/style.css',
    '/static/js/main.js',
    '/static/js/modules/state.js',
    '/static/js/modules/api.js',
    '/static/js/modules/ui.js',
    '/static/js/modules/charts.js',
    '/static/js/modules/sse.js',
    // CDN resources (cached via opaque responses)
    'https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
    'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js',
    'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap'
];

// Install - Cache static assets
self.addEventListener('install', (event) => {
    console.log('🔧 Service Worker installing...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('📦 Caching static assets...');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                console.log('✅ Static assets cached');
                return self.skipWaiting();
            })
            .catch(err => {
                console.warn('⚠️ Cache failed:', err);
            })
    );
});

// Activate - Clean old caches
self.addEventListener('activate', (event) => {
    console.log('🚀 Service Worker activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames
                    .filter(name => name !== CACHE_NAME)
                    .map(name => {
                        console.log('🗑️ Deleting old cache:', name);
                        return caches.delete(name);
                    })
            );
        }).then(() => {
            console.log('✅ Service Worker activated');
            return self.clients.claim();
        })
    );
});

// Fetch - Cache strategies
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET requests
    if (request.method !== 'GET') return;

    // Skip API calls (don't cache API responses)
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(networkFirst(request));
        return;
    }

    // Cache-first for static assets
    if (isStaticAsset(url)) {
        event.respondWith(cacheFirst(request));
        return;
    }

    // Stale-while-revalidate for everything else
    event.respondWith(staleWhileRevalidate(request));
});

// Cache strategies
async function cacheFirst(request) {
    const cached = await caches.match(request);
    if (cached) return cached;

    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, response.clone());
        }
        return response;
    } catch (error) {
        console.warn('⚠️ Fetch failed, no cache:', request.url);
        return new Response('Offline - Resource not cached', {
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        const cached = await caches.match(request);
        if (cached) return cached;
        throw error;
    }
}

async function staleWhileRevalidate(request) {
    const cached = await caches.match(request);

    const fetchPromise = fetch(request).then(response => {
        if (response.ok) {
            const cache = caches.open(CACHE_NAME);
            cache.then(c => c.put(request, response.clone()));
        }
        return response;
    }).catch(() => cached);

    return cached || fetchPromise;
}

function isStaticAsset(url) {
    const staticPaths = ['.css', '.js', '.png', '.jpg', '.svg', '.woff', '.woff2', '.ttf'];
    return staticPaths.some(ext => url.pathname.endsWith(ext));
}

// Background Sync for offline form submissions
self.addEventListener('sync', (event) => {
    if (event.tag === 'analysis-sync') {
        event.waitUntil(syncAnalysis());
    }
});

async function syncAnalysis() {
    // Placeholder for background sync logic
    console.log('🔄 Background sync triggered');
}

// Push notifications (future enhancement)
self.addEventListener('push', (event) => {
    if (event.data) {
        const data = event.data.json();
        self.registration.showNotification(data.title || 'ContentPro', {
            body: data.body || 'Analysis complete!',
            icon: '/static/icons/icon-192x192.png',
            badge: '/static/icons/icon-72x72.png'
        });
    }
});

// Message handling from main thread
self.addEventListener('message', (event) => {
    if (event.data === 'skipWaiting') {
        self.skipWaiting();
    }
});