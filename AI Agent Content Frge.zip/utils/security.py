# ============================================================
# UTILS/SECURITY.PY - Input Sanitization & Validation
# V6.0-PHASE2 (FIXED - libmagic fallback for Windows)
# ============================================================

import re
import os
import uuid
import time
import bleach
from pathlib import Path

# FIX: python-magic ko optional banao
try:
    import magic
    MAGIC_AVAILABLE = True
except ImportError:
    MAGIC_AVAILABLE = False
    magic = None

from config import Config


class InputSanitizer:
    """Sanitize all user inputs to prevent injection attacks."""

    @staticmethod
    def sanitize_filename(filename):
        """Remove path traversal and dangerous characters from filename."""
        if not filename:
            return None

        filename = os.path.basename(filename)
        filename = filename.replace('\x00', '')
        filename = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', filename)
        filename = re.sub(r'[<>:"|?*]', '', filename)

        if len(filename) > 255:
            name, ext = os.path.splitext(filename)
            filename = name[:250] + ext

        if not filename or filename in ('.', '..'):
            return None

        return filename

    @staticmethod
    def validate_extension(filename):
        """Check if file extension is in allowed list."""
        if not filename or '.' not in filename:
            return False
        ext = filename.rsplit('.', 1)[1].lower()
        return ext in Config.SECURITY.ALLOWED_EXTENSIONS

    @staticmethod
    def validate_mime_type(file_path, expected_ext):
        """Validate file content using magic bytes."""
        # FIX: Agar magic available nahi hai to skip karo
        if not MAGIC_AVAILABLE:
            return True  # Fallback: rely on extension only
        
        try:
            mime = magic.from_file(file_path, mime=True)
            expected_mimes = Config.SECURITY.ALLOWED_MIME_TYPES.get(expected_ext, [])
            return mime in expected_mimes
        except Exception as e:
            # Fallback: if magic fails, rely on extension
            return True

    @staticmethod
    def sanitize_text_content(text):
        """Sanitize text content to prevent XSS."""
        if not text:
            return ''

        text = bleach.clean(text, tags=[], strip=True)

        words = text.split()
        if len(words) > Config.SECURITY.MAX_TEXT_LENGTH:
            text = ' '.join(words[:Config.SECURITY.MAX_TEXT_LENGTH])

        return text

    @staticmethod
    def generate_secure_filename(original_filename):
        """Generate a secure random filename while preserving extension."""
        if not original_filename:
            return None

        ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else 'txt'
        secure_name = f"{uuid.uuid4().hex}_{int(time.time())}.{ext}"
        return secure_name


class PathValidator:
    """Validate file paths to prevent directory traversal."""

    @staticmethod
    def is_safe_path(base_path, target_path):
        """Check if target path is within base path."""
        try:
            base = Path(base_path).resolve()
            target = Path(target_path).resolve()
            return target.startswith(base)
        except Exception:
            return False