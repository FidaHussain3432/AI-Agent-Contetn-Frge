# -*- coding: utf-8 -*-
# ============================================================
# UTILS/LOGGING_CONFIG.PY - Structured Logging Setup
# V6.0-PHASE2
# ============================================================

import logging
import sys
from pathlib import Path

from config import Config


def setup_logging():
    """Configure structured logging for the application."""
    log_format = Config.LOGGING.LOG_FORMAT
    log_level = getattr(logging, Config.LOGGING.LOG_LEVEL.upper(), logging.INFO)

    # Ensure logs directory exists
    Path(Config.LOGGING.LOG_FILE).parent.mkdir(exist_ok=True)

    # Root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[
            logging.FileHandler(Config.LOGGING.LOG_FILE),
            logging.StreamHandler(sys.stdout)
        ]
    )

    # Security logger
    security_logger = logging.getLogger('security')
    security_handler = logging.FileHandler(Config.LOGGING.SECURITY_LOG)
    security_handler.setFormatter(logging.Formatter(log_format))
    security_logger.addHandler(security_handler)
    security_logger.setLevel(logging.INFO)

    # App logger
    app_logger = logging.getLogger('app')
    app_logger.setLevel(log_level)

    return app_logger, security_logger


# Initialize on import
app_logger, security_logger = setup_logging()