# -*- coding: utf-8 -*-
# ============================================================
# UTILS/CACHE.PY - Score Caching System
# V6.0-PHASE2
# ============================================================

import hashlib


class ScoreCache:
    """Thread-safe score caching with MD5 hashing."""

    def __init__(self):
        self._cache = {}

    def _get_key(self, text, func_name):
        """Generate cache key from text and function name."""
        text_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        return f"{func_name}:{text_hash}"

    def get(self, text, func_name):
        """Retrieve cached score if exists."""
        key = self._get_key(text, func_name)
        return self._cache.get(key)

    def set(self, text, func_name, result):
        """Store score in cache."""
        key = self._get_key(text, func_name)
        self._cache[key] = result

    def cached_score(self, text, func, func_name):
        """Get score with caching - main interface."""
        cached = self.get(text, func_name)
        if cached is not None:
            return cached
        result = func(text)
        self.set(text, func_name, result)
        return result

    def clear(self):
        """Clear all cached scores."""
        self._cache.clear()

    def size(self):
        """Return current cache size."""
        return len(self._cache)


# Global cache instance
score_cache = ScoreCache()