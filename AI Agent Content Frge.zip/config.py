# ============================================================
# CONFIG.PY - Centralized Configuration
# V6.0-PHASE5 - Plagiarism Detection Upgrade
# ============================================================

import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_FOLDER = BASE_DIR / 'uploads'
PROCESSED_FOLDER = BASE_DIR / 'processed'
TEMPLATES_FOLDER = BASE_DIR / 'templates'
LOGS_FOLDER = BASE_DIR / 'logs'

# Ensure folders exist
for folder in [UPLOAD_FOLDER, PROCESSED_FOLDER, TEMPLATES_FOLDER, LOGS_FOLDER]:
    folder.mkdir(exist_ok=True)

class SecurityConfig:
    """Security-related configuration."""
    ALLOWED_ORIGINS = ['http://localhost:5000', 'http://127.0.0.1:5000']
    ALLOWED_EXTENSIONS = {'txt', 'docx', 'pdf'}
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB
    MAX_TEXT_LENGTH = 25000  # words
    ALLOWED_MIME_TYPES = {
        'txt': ['text/plain'],
        'docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'pdf': ['application/pdf']
    }
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True

class AppConfig:
    """Application configuration."""
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    HOST = os.environ.get('FLASK_HOST', '0.0.0.0')
    PORT = int(os.environ.get('FLASK_PORT', 5000))
    MAX_LOOPS_DEFAULT = 100
    MAX_LOOPS_FILE_PROCESS = 10

class DatabaseConfig:
    """Database configuration."""
    DATABASE_URL = os.environ.get('DATABASE_URL', f'sqlite:///{BASE_DIR / "contentpro.db"}')
    TRACK_MODIFICATIONS = False

class AIConfig:
    """AI/ML model configuration — PHASE 4 + 5."""
    MODEL_NAME = 'roberta-base-openai-detector'
    SENTENCE_TRANSFORMER_MODEL = 'all-MiniLM-L6-v2'

    # === PHASE 4: Sliding Window Settings ===
    MAX_ROBERTA_LENGTH = 512
    ROBERTA_STRIDE = 256

    # === PHASE 4: Perplexity Settings ===
    PERPLEXITY_WINDOW_SIZE = 512
    PERPLEXITY_STRIDE = 256
    HUMAN_PERPLEXITY_BASELINE = 80.0
    AI_PERPLEXITY_BASELINE = 25.0

    # === PHASE 4: Ensemble Weights ===
    ROBERTA_WEIGHT = 1.5
    PERPLEXITY_WEIGHT = 1.0
    HEURISTIC_WEIGHT = 0.7

    # === PHASE 4: Confidence Thresholds ===
    HIGH_CONFIDENCE_THRESHOLD = 0.8
    MEDIUM_CONFIDENCE_THRESHOLD = 0.5

    SIMILARITY_THRESHOLD = 0.85
    # FIX: HF_TOKEN hardcoded - works on any machine
    HF_TOKEN = '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'

# === PHASE 5: Plagiarism Configuration ===
class PlagiarismConfig:
    """Plagiarism detection configuration."""
    WEB_SEARCH_TIMEOUT = 10  # seconds
    MAX_WEB_RESULTS = 5
    SEMANTIC_THRESHOLD = 0.75  # Cosine similarity threshold
    MIN_SENTENCE_LENGTH = 15  # Characters
    MAX_SOURCES_STORE = 10  # Max sources to save in DB
    ENABLE_WEB_SEARCH = True  # Default setting
    DUCKDUCKGO_RATE_LIMIT = 0.5  # Seconds between requests
    MULTILINGUAL_MODEL = 'paraphrase-multilingual-MiniLM-L12-v2'
    EMBEDDING_MODEL = 'all-MiniLM-L6-v2'

class LoggingConfig:
    """Logging configuration."""
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s | %(levelname)s | %(name)s | %(message)s'
    LOG_FILE = LOGS_FOLDER / 'app.log'
    SECURITY_LOG = LOGS_FOLDER / 'security.log'

# Export all configs
class Config:
    """Master config class combining all settings."""
    SECURITY = SecurityConfig
    APP = AppConfig
    DATABASE = DatabaseConfig
    AI = AIConfig
    PLAGIARISM = PlagiarismConfig
    LOGGING = LoggingConfig
    BASE_DIR = BASE_DIR
    UPLOAD_FOLDER = str(UPLOAD_FOLDER)
    PROCESSED_FOLDER = str(PROCESSED_FOLDER)
    TEMPLATES_FOLDER = str(TEMPLATES_FOLDER)
    
    # PHASE 6: Static folder for modular JS
    STATIC_FOLDER = str(BASE_DIR / 'static')